#include<opencv2/objdetect/objdetect.hpp>  
#include<opencv2/highgui/highgui.hpp>  
#include<opencv2/imgproc/imgproc.hpp>  
  
using namespace cv;  
  
//����������  
CascadeClassifier faceCascade;  
  
int main()  
{  
    faceCascade.load("E:/opencv/sources/data/haarcascade_frontalface_alt.xml");   //���ط�������ע���ļ�·��  
  
    Mat img = imread("1.jpg");  
    Mat imgGray;  
    vector<Rect> faces;  
  
    if(img.empty())  
    {  
      return 1;  
    }  
  
    if(img.channels() ==3)  
    {  
       cvtColor(img, imgGray, CV_RGB2GRAY);  
    }  
    else  
    {  
       imgGray = img;  
    }  
  
    faceCascade.detectMultiScale(imgGray, faces, 1.2, 6, 0, Size(0, 0));   //�������  
  
    if(faces.size()>0)  
    {  
       for(int i =0; i<faces.size(); i++)  
       {  
           rectangle(img, Point(faces[i].x, faces[i].y), Point(faces[i].x + faces[i].width, faces[i].y + faces[i].height),   
                           Scalar(0, 255, 0), 1, 8);    //�������λ��  
       }  
    }  
  
    imshow("FacesOfPrettyGirl", img);  
  
    waitKey(0);  
    return 0;  
}  
