#include "opencv2\video\tracking.hpp"
#include "opencv2\imgproc\imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2\core\core.hpp"
#include "opencv2/opencv.hpp"
#include <iostream>

#include "cv.h"
#include "highgui.h"

#include <ctype.h>
#include <string.h>


using namespace cv;
using namespace std;

Mat image;

bool backprojMode = false;
bool selectObject = false;
int trackObject = 0;
bool showHist = true;
Point origin;
Rect selection;
int vmin = 10, vmax = 256, smin = 30;

int openCamera_or_Video;

static void onMouse(int event, int x, int y, int, void*)
{
	if (selectObject)
	{
		selection.x = MIN(x, origin.x);
		selection.y = MIN(y, origin.y);
		selection.width = std::abs(x - origin.x);
		selection.height = std::abs(y - origin.y);

		selection &= Rect(0, 0, image.cols, image.rows);
	}

	switch (event)
	{
	case CV_EVENT_LBUTTONDOWN:
		origin = Point(x, y);
		selection = Rect(x, y, 0, 0);
		selectObject = true;
		break;
	case CV_EVENT_LBUTTONUP:
		selectObject = false;
		if (selection.width > 0 && selection.height > 0)
			trackObject = -1;
		break;
	}
}

void help()
{
	cout << "\nThis is a test of face tracking\n"
		"This reads from video camera or from exsit video file.\n";
	cout << "\nAt first,you must select open camera or exsit video\n"
		"\t1 - open camera\n"
		"\t2 - open exsit video\n";
	while ((openCamera_or_Video <1) || (openCamera_or_Video>2))
		cin >> openCamera_or_Video;
	cout << "\n\nHot keys: \n"
		"\tESC - quit the program\n"
		"\tc - redetect the face\n"
		"\tb - show/hide backprojection view\n"
		"\th - show/hide object histogram\n"
		"\tp - pause video\n"
		"You can also select the face with mouse\n";
}
//////����ʶ��/////
static CvMemStorage* storage = 0;
static CvHaarClassifierCascade* cascade = 0;
//////////����ģ��/////////////////
const char* cascade_name ="haarcascade.xml";
//const char* cascade_name ="haarcascade_frontalface_alt.xml"; //  --ZLF
//////////////�������/////////////
void detect_and_draw(IplImage* img)
{
	static CvScalar colors[] =
	{
		{ { 0, 0, 255 } },
		{ { 0, 128, 255 } },
		{ { 0, 255, 255 } },
		{ { 0, 255, 0 } },
		{ { 255, 128, 0 } },
		{ { 255, 255, 0 } },
		{ { 255, 0, 0 } },
		{ { 255, 0, 255 } }
	};

	double scale = 1.3;
	IplImage* gray = cvCreateImage(cvSize(img->width, img->height), 8, 1);
	IplImage* small_img = cvCreateImage(cvSize(cvRound(img->width / scale),
		cvRound(img->height / scale)),
		8, 1);
	int i;

	cvCvtColor(img, gray, CV_BGR2GRAY);
	cvResize(gray, small_img, CV_INTER_LINEAR);
	cvEqualizeHist(small_img, small_img);
	cvClearMemStorage(storage);

	int radius;
	CvPoint center;


	if (cascade)
	{
		double t = (double)cvGetTickCount();
		CvSeq* faces = cvHaarDetectObjects(small_img, cascade, storage,
			1.1, 2, 0/*CV_HAAR_DO_CANNY_PRUNING*/,
			cvSize(30, 30));
		t = (double)cvGetTickCount() - t;
		printf("detection time = %gms\n", t / ((double)cvGetTickFrequency()*1000.));
		for (i = 0; i < (faces ? faces->total : 0); i++)
		{
			CvRect* r = (CvRect*)cvGetSeqElem(faces, i);


			center.x = cvRound((r->x + r->width*0.5)*scale);
			center.y = cvRound((r->y + r->height*0.5)*scale);
			radius = cvRound((r->width + r->height)*0.25*scale);
			//cvCircle( img, center, radius, colors[i%8], 3, 8, 0 );
			trackObject = -1;
		}
	}

	//cvShowImage( "result", img );
	cvReleaseImage(&gray);
	cvReleaseImage(&small_img);

	if (trackObject)
		selection = Rect(center.x - radius, center.y - radius, radius * 2, radius * 2);


}
////////////�Զ��������///////////////
int faceDetect(Mat image)
{
	//CvCapture* capture = 0;
	IplImage frame, *frame_copy = 0;
	
	//cascade_name = "E:\\opencv\\sources\\data\\haarcascades\\haarcascade_frontalface_alt2.xml";  //--������
	cascade_name = "E:\\opencv\\sources\\data\\haarcascades\\haarcascadexinxin.xml";

	//opencvװ�ú�haarcascade_frontalface_alt2.xml��·��,
	//Ҳ���԰�����ļ�������Ĺ����ļ�����Ȼ����д·����cascade_name= "haarcascade_frontalface_alt2.xml";  
	

	cascade = (CvHaarClassifierCascade*)cvLoad(cascade_name, 0, 0, 0);

	if (!cascade)
	{
		fprintf(stderr, "ERROR: Could not load classifier cascade\n");
		fprintf(stderr,
			"Usage: facedetect --cascade=\"<cascade_path>\" [filename|camera_index]\n");
		return -1;
	}
	storage = cvCreateMemStorage(0);


	if (!trackObject)
	{

		//if( !cvGrabFrame( capture ))////////////Ҫ�ĵ�
		//break;
		frame = image;
		//if( frame != 0 )
		//return -1;
		if (!frame_copy)
			frame_copy = cvCreateImage(cvSize(frame.width, frame.height),
			IPL_DEPTH_8U, frame.nChannels);
		if (frame.origin == IPL_ORIGIN_TL)
			cvCopy(&frame, frame_copy, 0);
		else
			cvFlip(&frame, frame_copy, 0);

		detect_and_draw(frame_copy);
		//Point op(trackWindow.br().x-trackWindow.width,trackWindow.br().y-trackWindow.height);
		//rectangle (Mat(frame),trackWindow.br(),op,Scalar(0,255,0));




		cvReleaseImage(&frame_copy);

	}



	return 0;
}


int main()
{
	
	
	help();
	
	cv::VideoCapture cap;
	switch (openCamera_or_Video)
	{
	case 1:
		cap.open(0);
		break;
	case 2:
		cap.open("first.mp4");//move2		person_dog	��׿�����	test1a	Laboratory_raw	��Ƶ_00005
		break;
	}

	Rect trackWindow;
	int hsize = 16;
	float hranges[] = { 0, 180 };
	const float* phranges = hranges;




	
	if (!cap.isOpened())
	{
		help();
		cout << "***Could not initialize capturing...***\n";
		cout << "Current parameter's value: \n";
		return -1;
	}
	
	namedWindow("Histogram", 0);
	namedWindow("CamShift Demo", 0);
	setMouseCallback("CamShift Demo", onMouse, 0);
	createTrackbar("Vmin", "CamShift Demo", &vmin, 256, 0);
	createTrackbar("Vmax", "CamShift Demo", &vmax, 256, 0);
	createTrackbar("Smin", "CamShift Demo", &smin, 256, 0);

	Mat frame, hsv, hue, mask, hist, histimg = Mat::zeros(200, 320, CV_8UC3), backproj;
	bool paused = false;

	for (;;)
	{
		if (!paused)
		{
			cap >> frame;
			if (frame.empty())
				break;
		}

		frame.copyTo(image);

		if (!paused)
		{
			cvtColor(image, hsv, COLOR_BGR2HSV);

			if (!trackObject)
				faceDetect(image);
			else
			{
				int _vmin = vmin, _vmax = vmax;

				inRange(hsv, Scalar(0, smin, MIN(_vmin, _vmax)),
					Scalar(180, 256, MAX(_vmin, _vmax)), mask);
				int ch[] = { 0, 0 };
				hue.create(hsv.size(), hsv.depth());
				mixChannels(&hsv, 1, &hue, 1, ch, 1);

				if (trackObject < 0)
				{
					Mat roi(hue, selection), maskroi(mask, selection);
					calcHist(&roi, 1, 0, maskroi, hist, 1, &hsize, &phranges);
					normalize(hist, hist, 0, 255, CV_MINMAX);

					trackWindow = selection;
					trackObject = 1;

					histimg = Scalar::all(0);
					int binW = histimg.cols / hsize;
					Mat buf(1, hsize, CV_8UC3);
					for (int i = 0; i < hsize; i++)
						buf.at<Vec3b>(i) = Vec3b(saturate_cast<uchar>(i*180. / hsize), 255, 255);
					cvtColor(buf, buf, CV_HSV2BGR);

					for (int i = 0; i < hsize; i++)
					{
						int val = saturate_cast<int>(hist.at<float>(i)*histimg.rows / 255);
						rectangle(histimg, Point(i*binW, histimg.rows),
							Point((i + 1)*binW, histimg.rows - val),
							Scalar(buf.at<Vec3b>(i)), -1, 8);
					}
				}

				calcBackProject(&hue, 1, 0, hist, backproj, &phranges);
				backproj &= mask;
				RotatedRect trackBox = CamShift(backproj, trackWindow,
					TermCriteria(CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 1));
				if (trackWindow.area() <= 1)
				{
					int cols = backproj.cols, rows = backproj.rows, r = (MIN(cols, rows) + 5) / 6;
					trackWindow = Rect(trackWindow.x - r, trackWindow.y - r,
						trackWindow.x + r, trackWindow.y + r) &
						Rect(0, 0, cols, rows);
				}

				if (backprojMode)
					cvtColor(backproj, image, COLOR_GRAY2BGR);
				ellipse(image, trackBox, Scalar(0, 0, 255), 3, CV_AA);
			}
		}
		else if (trackObject < 0)
			paused = false;

		if (selectObject && selection.width > 0 && selection.height > 0)
		{
			Mat roi(image, selection);
			bitwise_not(roi, roi);
		}

		imshow("CamShift Demo", image);
		imshow("Histogram", histimg);

		char c = (char)waitKey(10);
		if (c == 27)
			break;
		switch (c)
		{
		case 'b':
			backprojMode = !backprojMode;
			break;
		case 'c':
			trackObject = 0;
			histimg = Scalar::all(0);
			break;
		case 'h':
			showHist = !showHist;
			if (!showHist)
				destroyWindow("Histogram");
			else
				namedWindow("Histogram", 1);
			break;
		case 'p':
			paused = !paused;
			break;
		default:
			;
		}
	}

	return 0;
}
