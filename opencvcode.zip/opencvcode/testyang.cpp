#include <iostream>
#include "opencv2/opencv.hpp"
using namespace std;
using namespace cv;









int main()
{
Mat img,img1;
img=imread("1.bmp");
cv::cvtColor(img,img1,CV_RGB2GRAY);
imwrite("10.png",img1);
waitKey(20);
return 0;
}

