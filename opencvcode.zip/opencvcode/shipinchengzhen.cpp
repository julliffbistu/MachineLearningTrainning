//#include "stdafx.h"
#include <opencv2/highgui/highgui.hpp> 
#include <iostream> 
#include <stdio.h> 
#include <cv.h>
using namespace std;


int main(int argc, char *argv[]) 
{ 
CvCapture* capture = cvCaptureFromAVI("3445.mp4"); 
int i = 0; 
IplImage* img = 0; 
char image_name[25]; 
cvNamedWindow( "vivi"); 
//��ȡ����ʾ 
while(1) 
{ 
img = cvQueryFrame(capture); //��ȡһ֡ͼƬ 
if(img == NULL) 
break; 

cvShowImage( "vivi", img ); //������ʾ 
char key = cvWaitKey(20); 
sprintf(image_name, "%s%d%s", "D:", ++i, ".jpg");//�����ͼƬ�� 
cout<<"111111111111111111111"<<endl;
cvSaveImage( image_name, img); //����һ֡ͼƬ 
} 

cvReleaseCapture(&capture); 
cvDestroyWindow("vivi"); 

return 0; 
}