#ifndef TRANSPLANT_H
#define TRANSPLANT_H

#define		Uint16 			INT16U
#define		Byte			INT8U
#define		Uint32 			INT32U
#define		Bool			BOOLEAN
#define		int16			INT16S
#define		int32			INT32S			

#endif

