#ifndef ROBOT_VIEW_H
#define ROBOT_VIEW_H

class CRobotView
{
public:
	CRobotView();
	CRobotView(CString &viewName,UINT imageID,UINT Num);
	~CRobotView();

protected:
	CString viewName;
	CPoint *pJoint;
	CString *pJointName;
	unsigned int *pJointID;
	unsigned int jointNumber;
	UINT imageID;

public:
	bool LoadView(UINT bitmapID);
	
	UINT GetImageID(){return imageID;}

	CString GetViewName(){return viewName;}

	unsigned int GetJointNumber(){return jointNumber;}
	CString GetJointName(unsigned int id);
	unsigned int GetJointID(unsigned int id);
	int FindJointID(unsigned int jid);
	CPoint GetAbsolutePoint(unsigned int id,CWnd *src,CWnd *tgt);
};

#endif