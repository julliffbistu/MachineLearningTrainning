// SingleGait.cpp: implementation of the CSingleGait class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MotionDebug40.h"
#include "SingleGait.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSingleGait::CSingleGait()
{
	JointNumber=MOS2007_JOINT_NUMBER;
	mechZeroList=new int[MOS2007_JOINT_NUMBER];
	memset(mechZeroList,0,sizeof(int)*MOS2007_JOINT_NUMBER);
	gid=1;
	robotDesc.LoadString(IDS_STRING_ROBOT_1);
	gaitDesc.LoadString(IDS_STRING_INITIAL_STAND);
}

CSingleGait::~CSingleGait()
{
	if(mechZeroList!=NULL)
		delete []mechZeroList;
}

unsigned int CSingleGait::GetJointNum()
{
	return JointNumber;
}

void CSingleGait::SetJointNum(unsigned int num)
{
	int *newList=NULL;
	if(JointNumber==num)
		return ;
	newList=new int[num];
	memset(newList,0,sizeof(int)*num);
	if(JointNumber>=num)
		memcpy(newList,mechZeroList,sizeof(int)*num);
	else
		memcpy(newList,mechZeroList,sizeof(int)*JointNumber);
	delete mechZeroList;
	mechZeroList=newList;
	JointNumber=num;
}

int CSingleGait::GetZeroList(int *pList)
{
	memcpy(pList,mechZeroList,JointNumber*sizeof(int));
	return 0;
}

void CSingleGait::SetZeroList(int *pList)
{
	memcpy(mechZeroList,pList,JointNumber*sizeof(int));
}

int CSingleGait::GetJointZeroPoint(unsigned int joint)
{
	if(joint<JointNumber)
		return mechZeroList[joint];
	else
		return 0;
}

unsigned int CSingleGait::GetGaitID()
{
	return gid;
}

void CSingleGait::SetGaitID(unsigned int id)
{
	gid=id;
}

CString CSingleGait::GetGaitDesc()
{
	return gaitDesc;
}

void CSingleGait::SetGaitDesc(CString &desc)
{
	gaitDesc=desc;
}

CString CSingleGait::GetRobotDesc()
{
	return robotDesc;
}

void CSingleGait::SetRobotDesc(CString &desc)
{
	robotDesc=desc;
}

CString CSingleGait::MakeTitle()
{
	CString title;
	title.Format("%d-%s-%s.txt",gid,gaitDesc,robotDesc);
	return title;
}

void CSingleGait::InitializeToDefault()
{
	JointNumber=MOS2007_JOINT_NUMBER;
	if(mechZeroList!=NULL)
		delete []mechZeroList;
	mechZeroList=new int[MOS2007_JOINT_NUMBER];
	memset(mechZeroList,0,sizeof(int)*MOS2007_JOINT_NUMBER);
	gid=1;
	robotDesc.LoadString(IDS_STRING_ROBOT_1);
	gaitDesc.LoadString(IDS_STRING_INITIAL_STAND);
}

