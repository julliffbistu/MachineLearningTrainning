#include "stdafx.h"
#include "Resource.h"
#include "GaitSettingsMemory.h"
#include "Utilities.h"

GaitSettingsMemory::GaitSettingsMemory()
{
	robot_type_length=0;
	robot_walking_length=0;
	frame_step=0;
	frame_number=0;
	mech_zero_length=0;

	probot_type_parameter=NULL;
	probot_walking_parameter=NULL;
	pframe_data=NULL;
	pmechanical_zero_point=NULL;
}

int GaitSettingsMemory::operator =(GaitSettingsMemory &tgt)
{
	robot_type_length=tgt.robot_type_length;
	robot_walking_length=tgt.robot_walking_length;
	frame_step=tgt.frame_step;
	frame_number=tgt.frame_number;
	mech_zero_length=tgt.mech_zero_length;
	
	robot_type_description=tgt.robot_type_description;
	robot_walking_description=tgt.robot_walking_description;
	frame_description=tgt.frame_description;
	single_robot_description=tgt.single_robot_description;

	if(probot_type_parameter!=NULL)
		delete probot_type_parameter;
	probot_type_parameter=NULL;
	probot_type_parameter=new int[robot_type_length];
	memcpy(probot_type_parameter,tgt.probot_type_parameter,robot_type_length*sizeof(int));

	if(probot_walking_parameter!=NULL)
		delete probot_walking_parameter;
	probot_walking_parameter=NULL;
	probot_walking_parameter=new int[robot_walking_length];
	memcpy(probot_walking_parameter,tgt.probot_walking_parameter,robot_walking_length*sizeof(int));

	if(pframe_data!=NULL)
		delete pframe_data;
	pframe_data=NULL;
	pframe_data=new int[frame_step*frame_number];
	memcpy(pframe_data,tgt.pframe_data,frame_step*frame_number*sizeof(int));

	if(pmechanical_zero_point!=NULL)
		delete pmechanical_zero_point;
	pmechanical_zero_point=NULL;
	pmechanical_zero_point=new int[mech_zero_length];
	memcpy(pmechanical_zero_point,tgt.pmechanical_zero_point,mech_zero_length*sizeof(int));

	return 0;
}

BOOL GaitSettingsMemory::StoreToFile(CStdioFile &file)
{
	CString temp;
	
	if(robot_type_length!=0&&probot_type_parameter!=NULL)
	{
		temp.Format("robot_type_description='%s';\r\n",robot_type_description);
		file.WriteString(temp);
		
		temp.Format("robot_type_length=%d;\r\n",robot_type_length);
		file.WriteString(temp);
		
		CString temp2;
		temp="robot_type_parameter=[";
		for(unsigned int i=0;i<robot_type_length;i++)
		{
			temp2.Format("%d",probot_type_parameter[i]);
			temp+=temp2;
			if(i!=robot_type_length-1)
				temp+=",";
		}
		temp+="];\r\n";
		file.WriteString(temp);
	}

	if(robot_walking_length!=0&&probot_walking_parameter!=NULL)
	{
		temp.Format("robot_walking_description='%s';\r\n",robot_walking_description);
		file.WriteString(temp);
		
		temp.Format("robot_walking_length=%d;\r\n",robot_walking_length);
		file.WriteString(temp);
		
		CString temp2;
		temp="robot_walking_parameter=[";
		for(unsigned int i=0;i<robot_walking_length;i++)
		{
			temp2.Format("%d",probot_walking_parameter[i]);
			temp+=temp2;
			if(i!=robot_walking_length-1)
				temp+=",";
		}
		temp+="];\r\n";
		file.WriteString(temp);
	}

	if(mech_zero_length!=0&&pmechanical_zero_point!=NULL)
	{
		temp.Format("single_robot_description='%s';\r\n",single_robot_description);
		file.WriteString(temp);
		
		temp.Format("mech_zero_length=%d;\r\n",mech_zero_length);
		file.WriteString(temp);

		//write zero point list
		CString temp2;
		temp="mechanical_zero_point=[";
		for(unsigned int i=0;i<mech_zero_length;i++)
		{
			if(pmechanical_zero_point[i]>=0)
				temp2.Format("%d.%d",INTEGER(pmechanical_zero_point[i]),DECIMAL(pmechanical_zero_point[i]));
			else
				temp2.Format("-%d.%d",INTEGER(-pmechanical_zero_point[i]),DECIMAL(-pmechanical_zero_point[i]));
			temp+=temp2;
			if(i!=mech_zero_length-1)
				temp+=",";
		}
		temp+="];\r\n";
		file.WriteString(temp);
	}

	if(frame_step!=0&&frame_number!=0&&pframe_data!=NULL)
	{
		temp.Format("frame_description='%s';\r\n",frame_description);
		file.WriteString(temp);
		
		temp.Format("frame_step=%d;\r\n",frame_step);
		file.WriteString(temp);

		temp.Format("frame_number=%d;\r\n",frame_number);
		file.WriteString(temp);

		file.WriteString("frame_data=[\r\n");
		for(int j=0;j<frame_number;j++)
		{
			int i;
			CString temp2;
			temp.Empty();
			for(i=0;i<frame_step-1;i++)
			{
				temp2.Format("%d",pframe_data[j*frame_step+i]);
				temp+=temp2;
				temp+=",";
			}
			temp2.Format("%d",pframe_data[j*frame_step+i]);
			temp+=temp2;
			temp+=";\r\n";
			file.WriteString(temp);
		}
		file.WriteString("];\r\n");
	}

	return TRUE;
}

BOOL GaitSettingsMemory::LoadFromFile(CStdioFile &file)
{
	CString temp;
	CHAR var[64];
	while(file.ReadString(temp))
	{
		sscanf(temp,"%63[^=^ ]",var);
		if(0==strcmp(var,"robot_type_length"))
			sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&robot_type_length);
		else if(0==strcmp(var,"robot_walking_length"))
			sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&robot_walking_length);
		else if(0==strcmp(var,"frame_step"))
			sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&frame_step);
		else if(0==strcmp(var,"frame_number"))
			sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&frame_number);
		else if(0==strcmp(var,"mech_zero_length"))
			sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&mech_zero_length);
		else if(0==strcmp(var,"robot_type_description"))
		{
			char *pstr=new char[temp.GetLength()];
			sscanf(temp,"%*[^=]%*[^']'%[^']",pstr);
			robot_type_description=pstr;
			delete pstr;
		}else if(0==strcmp(var,"robot_walking_description"))
		{
			char *pstr=new char[temp.GetLength()];
			sscanf(temp,"%*[^=]%*[^']'%[^']",pstr);
			robot_walking_description=pstr;
			delete pstr;
		}else if(0==strcmp(var,"frame_description"))
		{
			char *pstr=new char[temp.GetLength()];
			sscanf(temp,"%*[^=]%*[^']'%[^']",pstr);
			frame_description=pstr;
			delete pstr;
		}else if(0==strcmp(var,"single_robot_description"))
		{
			char *pstr=new char[temp.GetLength()];
			sscanf(temp,"%*[^=]%*[^']'%[^']",pstr);
			frame_description=pstr;
			delete pstr;
		}else if(0==strcmp(var,"mechanical_zero_point"))
		{
			char *pstr=NULL;
			int *pList=NULL;
			float fdata=0;
			int cntr=0;
			int start=0;
			
			if(mech_zero_length==0)
			{
				AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
				return FALSE;
			}
			pstr=new char[temp.GetLength()];
			memset(pstr,0,temp.GetLength());
			sscanf(temp,"%*[^=]%*[^[][%[^]]",pstr);
			CString temp2=pstr;
			delete pstr;
			
			while(-1!=temp2.Find(',',start))
			{
				cntr++;
				start=temp2.Find(',',start)+1;
			}
			if(temp2.GetLength()!=start)
				cntr++;
			
			pList=new int[cntr];
			memset(pList,0,cntr*sizeof(int));
			cntr=0;
			while(temp2.GetLength())
			{
				sscanf(temp2,"%f",&fdata);
				pList[cntr]=FtoI(fdata*10);
				if(-1!=temp2.Find(','))
					temp2.Delete(0,temp2.Find(',')+1);
				else
					temp2.Empty();
				cntr++;
			}
			if(pmechanical_zero_point!=NULL)
				delete pmechanical_zero_point;
			pmechanical_zero_point=pList;
		}else if(0==strcmp(var,"robot_type_parameter"))
		{
			char *pstr=NULL;
			int *pList=NULL;
			int fdata=0;
			int cntr=0;
			int start=0;
			
			if(robot_type_length==0)
			{
				AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
				return FALSE;
			}
			pstr=new char[temp.GetLength()];
			memset(pstr,0,temp.GetLength());
			sscanf(temp,"%*[^=]%*[^[][%[^]]",pstr);
			CString temp2=pstr;
			delete pstr;
			
			while(-1!=temp2.Find(',',start))
			{
				cntr++;
				start=temp2.Find(',',start)+1;
			}
			if(temp2.GetLength()!=start)
				cntr++;
			
			pList=new int[cntr];
			memset(pList,0,cntr*sizeof(int));
			cntr=0;
			while(temp2.GetLength())
			{
				sscanf(temp2,"%d",&fdata);
				pList[cntr]=fdata;
				if(-1!=temp2.Find(','))
					temp2.Delete(0,temp2.Find(',')+1);
				else
					temp2.Empty();
				cntr++;
			}
			
			if(probot_type_parameter!=NULL)
				delete probot_type_parameter;
			probot_type_parameter=pList;
		}else if(0==strcmp(var,"robot_walking_parameter"))
		{
			char *pstr=NULL;
			int *pList=NULL;
			int fdata=0;
			int cntr=0;
			int start=0;
			
			if(robot_walking_length==0)
			{
				AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
				return FALSE;
			}
			pstr=new char[temp.GetLength()];
			memset(pstr,0,temp.GetLength());
			sscanf(temp,"%*[^=]%*[^[][%[^]]",pstr);
			CString temp2=pstr;
			delete pstr;
			
			while(-1!=temp2.Find(',',start))
			{
				cntr++;
				start=temp2.Find(',',start)+1;
			}
			if(temp2.GetLength()!=start)
				cntr++;
			
			pList=new int[cntr];
			memset(pList,0,cntr*sizeof(int));
			cntr=0;
			while(temp2.GetLength())
			{
				sscanf(temp2,"%d",&fdata);
				pList[cntr]=fdata;
				if(-1!=temp2.Find(','))
					temp2.Delete(0,temp2.Find(',')+1);
				else
					temp2.Empty();
				cntr++;
			}
			
			if(probot_walking_parameter!=NULL)
				delete probot_walking_parameter;
			probot_walking_parameter=pList;
		}else if(0==strcmp(var,"frame_data"))
		{
			if(frame_step==0||frame_number==0)
			{
				AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
				return FALSE;
			}
			if(pframe_data!=NULL)
				delete pframe_data;
			pframe_data=new int[frame_step*frame_number];
			
			for(unsigned int i=0;i<frame_number;i++)
			{
				file.ReadString(temp);
				for(unsigned int j=0;j<frame_step;j++)
				{
					sscanf(temp,"%d",pframe_data+i*frame_step+j);
					temp.Delete(0,temp.Find(',')+1);
				}
			}
		}
	}
	return TRUE;
}

int GaitSettingsMemory::GetMechanicalZeroPoint(int **pList)
{
	if(pList!=NULL)
	{
		if(mech_zero_length!=0)
			*pList=pmechanical_zero_point;
		else
			*pList=NULL;
	}
	return mech_zero_length;
}

int GaitSettingsMemory::GetRobotTypeParameter(int **pList)
{
	if(pList!=NULL)
	{
		if(robot_type_length!=0)
			*pList=probot_type_parameter;
		else
			*pList=NULL;
	}
	return robot_type_length;
}

int GaitSettingsMemory::GetRobotWalkingParameter(int **pList)
{
	if(pList!=NULL)
	{
		if(robot_walking_length!=0)
			*pList=probot_walking_parameter;
		else
			*pList=NULL;
	}
	return robot_walking_length;
}

int GaitSettingsMemory::GetFrameData(int **pList,int *step,int *frame)
{
	if(pList!=NULL)
	{
		if(frame_step*frame_number!=0)
			*pList=pframe_data;
		else
			*pList=NULL;
	}
	if(step!=NULL)
		*step=frame_step;
	if(frame!=NULL)
		*frame=frame_number;
	return frame_step*frame_number;
}

GaitSettingsMemory::~GaitSettingsMemory()
{
	robot_type_length=0;
	robot_walking_length=0;
	frame_step=0;
	frame_number=0;
	mech_zero_length=0;

	if(probot_type_parameter!=NULL)
		delete probot_type_parameter;
	probot_type_parameter=NULL;

	if(probot_walking_parameter!=NULL)
		delete probot_walking_parameter;
	probot_walking_parameter=NULL;

	if(pframe_data!=NULL)
		delete pframe_data;
	pframe_data=NULL;

	if(pmechanical_zero_point!=NULL)
		delete pmechanical_zero_point;
	pmechanical_zero_point=NULL;
}
