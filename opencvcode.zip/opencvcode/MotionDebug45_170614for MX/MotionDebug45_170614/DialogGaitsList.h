#if !defined(AFX_DIALOGGAITSLIST_H__27A9285E_59EF_4B8D_9EB9_A0C0CB5D480A__INCLUDED_)
#define AFX_DIALOGGAITSLIST_H__27A9285E_59EF_4B8D_9EB9_A0C0CB5D480A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogGaitsList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogGaitsList dialog

struct SensorsRaw
{
	SHORT gyro[3];
	SHORT accel[3];
	SHORT mag[3];
};

class CDialogGaitsList : public CDialog
{
// Construction
public:
	CDialogGaitsList(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogGaitsList)
	enum { IDD = IDD_DIALOG_RUN_GAITLIST };
	CEdit	m_editInclinometerY;
	CEdit	m_editInclinometerX;
	CEdit	m_editRecordFile;
	CListBox	m_listGaitList;
	CButton	m_buttonEditC;
	CButton	m_buttonDeleteC;
	CButton	m_buttonInsertT;
	CButton	m_buttonInsertB;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogGaitsList)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogGaitsList)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonEditCurrent();
	afx_msg void OnButtonInsertBottom();
	afx_msg void OnButtonInsertTop();
	afx_msg void OnButtonDeleteCurrent();
	afx_msg void OnButtonRunGaitlist();
	afx_msg void OnButtonNewFile();
	afx_msg void OnButtonStartFeedback();
	afx_msg void OnButtonStartRecord();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	CStdioFile m_recordFile;
	bool enableRecording;
	bool recvThreadRunning;
	bool gaitListRunning;
	int gaitCounter;
	DWORD feedBackStartTime;
	CRITICAL_SECTION cs;

protected:
	static DWORD RecvThread(LPVOID lpThreadParameter);
	bool SendCurrentGait(CMotionDebug40View *view);
	bool SendFeedback(CMotionDebug40View *view,bool start);
	bool CheckTaskComplete();
	bool LckForThread();
public:
//	afx_msg void OnBnClickedCancel();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGGAITSLIST_H__27A9285E_59EF_4B8D_9EB9_A0C0CB5D480A__INCLUDED_)
