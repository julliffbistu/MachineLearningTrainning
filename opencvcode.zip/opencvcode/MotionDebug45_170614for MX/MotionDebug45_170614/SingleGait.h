// SingleGait.h: interface for the CSingleGait class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SINGLEGAIT_H__7D71DEA8_0706_4069_9A0B_B77A4F09B3C6__INCLUDED_)
#define AFX_SINGLEGAIT_H__7D71DEA8_0706_4069_9A0B_B77A4F09B3C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MOS2007_JOINT_NUMBER 19
class CSingleGait : public CObject  
{
public:
	CSingleGait();
	virtual ~CSingleGait();
	unsigned int GetJointNum();
	void SetJointNum(unsigned int num);
	int GetZeroList(int *pList);
	void SetZeroList(int *pList);
	int GetJointZeroPoint(unsigned int joint);
	unsigned int GetGaitID();
	void SetGaitID(unsigned int id);
	CString GetRobotDesc();
	void SetRobotDesc(CString &desc);
	CString GetGaitDesc();
	void SetGaitDesc(CString &desc);
	CString MakeTitle();
	void InitializeToDefault();

protected:
	unsigned int JointNumber;
	int *mechZeroList;
	unsigned int gid;
	CString robotDesc;
	CString gaitDesc;
};

#endif // !defined(AFX_SINGLEGAIT_H__7D71DEA8_0706_4069_9A0B_B77A4F09B3C6__INCLUDED_)
