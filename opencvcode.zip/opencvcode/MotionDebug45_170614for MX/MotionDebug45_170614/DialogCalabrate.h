//{{AFX_INCLUDES()
#include "msflexgrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_DIALOGCALABRATE_H__9FDD1F60_319D_48BE_BFB2_4627148802D4__INCLUDED_)
#define AFX_DIALOGCALABRATE_H__9FDD1F60_319D_48BE_BFB2_4627148802D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogCalabrate.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogCalabrate dialog

class CDialogCalabrate : public CDialog
{
// Construction
public:
	CDialogCalabrate(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogCalabrate)
	enum { IDD = IDD_DIALOG_CALABRATE };
	CMSFlexGrid	m_calabrateList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogCalabrate)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogCalabrate)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnRadioReadZero();
	afx_msg void OnRadioTuningZero();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnClickMsflexgridCalabrate();
	afx_msg void OnLeaveCellMsflexgridCalabrate();
	afx_msg void OnScrollMsflexgridCalabrate();
	afx_msg void OnButtonTorqueControl();
	afx_msg void OnButtonReadZero();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void ConstructFrameData(PBYTE pbuf);

protected:
	unsigned int jointNumber;
	bool allowEdit;
	bool actionEnable;
	CEdit *m_pEdit;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGCALABRATE_H__9FDD1F60_319D_48BE_BFB2_4627148802D4__INCLUDED_)
