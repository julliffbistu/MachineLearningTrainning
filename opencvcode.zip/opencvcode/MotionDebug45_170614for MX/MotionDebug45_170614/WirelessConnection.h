#if !defined(AFX_WIRELESSCONNECTION_H__3AC7A436_55D3_4F53_915D_E0B693E26517__INCLUDED_)
#define AFX_WIRELESSCONNECTION_H__3AC7A436_55D3_4F53_915D_E0B693E26517__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WirelessConnection.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CWirelessConnection command target

class CWirelessConnection : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	CWirelessConnection();
	virtual ~CWirelessConnection();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWirelessConnection)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CWirelessConnection)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
	SOCKET sock;
protected:
	BOOL isConnectionOpen;
	DWORD ipAddress;
	WORD port;
public:
	BOOL GetConnectionOpen();
	void SetConnectionOpen(BOOL bNewValue);
	void SetConnectionPort(DWORD ip,WORD pt);
	void SetSettings();
	void SetOutput(CByteArray &buf);
	int GetInput(CByteArray &buf,int timeoutMs);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WIRELESSCONNECTION_H__3AC7A436_55D3_4F53_915D_E0B693E26517__INCLUDED_)
