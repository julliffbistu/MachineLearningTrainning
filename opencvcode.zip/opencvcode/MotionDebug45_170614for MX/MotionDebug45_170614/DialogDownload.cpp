// DialogDownload.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "RobotView.h"
#include "DspControl.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "DialogDownload.h"
#include "SingleGait.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogDownload dialog


CDialogDownload::CDialogDownload(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogDownload::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogDownload)
	m_editGaitDesc = _T("");
	m_editRobotDesc = _T("");
	//}}AFX_DATA_INIT
}


void CDialogDownload::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogDownload)
	DDX_Control(pDX, IDC_STATIC_DOWNLOAD_NOTIFICATION, m_staticDownloadNotification);
	DDX_Control(pDX, IDC_PROGRESS_DOWNLOAD_PROCESS, m_ProgressDownload);
	DDX_Control(pDX, IDC_COMBO_GAIT_ID, m_comboGaitID);
	DDX_Text(pDX, IDC_EDIT_GAIT_DESC, m_editGaitDesc);
	DDX_Text(pDX, IDC_EDIT_ROBOT_DESC, m_editRobotDesc);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogDownload, CDialog)
	//{{AFX_MSG_MAP(CDialogDownload)
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD_GAIT, OnButtonDownloadGait)
	ON_BN_CLICKED(IDC_BUTTON_CONTINUOUS_RUN, OnButtonContinuousRun)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogDownload message handlers

BOOL CDialogDownload::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString temp;
	for(int i=0;i<255;i++)
	{
		temp.Format("%d",i+1);
		m_comboGaitID.InsertString(i,temp);
	}

	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	CSingleGait *pGait=view->GetGaitInfo();
	m_comboGaitID.SetCurSel(pGait->GetGaitID()-1);
	m_editGaitDesc=pGait->GetGaitDesc();
	m_editRobotDesc=pGait->GetRobotDesc();
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogDownload::OnOK() 
{
	// TODO: Add extra validation here
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	CMotionDebug40Doc *doc=view->GetDocument();
	CSingleGait *pGait=view->GetGaitInfo();
	UpdateData();
	if(
		m_comboGaitID.GetCurSel()!=pGait->GetGaitID()-1||
		m_editGaitDesc!=pGait->GetGaitDesc()||
		m_editRobotDesc!=pGait->GetRobotDesc()
		)
		doc->SetModifiedFlag();
	pGait->SetGaitID(m_comboGaitID.GetCurSel()+1);
	pGait->SetGaitDesc(m_editGaitDesc);
	pGait->SetRobotDesc(m_editRobotDesc);
	doc->SetTitle(pGait->MakeTitle());

	CDialog::OnOK();
}

struct DownloadParameter
{
	CMotionDebug40View *parent;
	CDialogDownload *child;
};

void CDialogDownload::OnButtonDownloadGait() 
{
	// TODO: Add your control notification handler code here
	DWORD nThreadId1;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());

	struct DownloadParameter *para=NULL;
	para=new struct DownloadParameter;
	para->parent=view;
	para->child=this;

	::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(DownLoad),
		para,
		0,
		&nThreadId1
		);
	return;
}

DWORD CDialogDownload::DownLoad(LPVOID lpThreadParameter)
{
	struct DownloadParameter *para=(struct DownloadParameter *)lpThreadParameter;
	CDialogDownload *dlg=para->child;
	CMotionDebug40View *view=para->parent;
	delete para;
	
	PacketTransformer packet;
	int frameNum=view->m_MotionList.GetRows()-2;
	int jointNum=view->m_MotionList.GetCols()-2;
	int periodNum=view->GetGaitPeriod();
	int i=0;
	CString preStr;
	CString tgtStr;

	if(frameNum>50||periodNum>0x0000ffff)
	{
		AfxMessageBox(IDS_STRING_GAIT_ILLIGAL);
		goto failed_exit;
	}

	dlg->m_ProgressDownload.SetRange(0,frameNum);
	dlg->m_staticDownloadNotification.GetWindowText(preStr);
	tgtStr.LoadString(IDS_STRING_DOWNLOAD_RAM);
	dlg->m_staticDownloadNotification.SetWindowText(tgtStr);

	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_GAIT_MEMORY_START;
	//add by zhangjiwen in 2010.9.29 for dsp with rtos
	//packet.dspInst->length=5;
	packet.dspInst->length=10;
	packet.dspInst->parameter[0]=dlg->m_comboGaitID.GetCurSel()+1;
	packet.dspInst->parameter[1]=frameNum;
	packet.dspInst->parameter[2]=view->m_MotionList.GetCols()-1;
	//add by zhangjiwen in 2010.9.29 for dsp with rtos
	packet.dspInst->parameter[3]=periodNum&0xff;
	packet.dspInst->parameter[4]=(periodNum>>8)&0xff;
	packet.dspInst->parameter[5]=0;
	packet.dspInst->parameter[6]=0;
	packet.dspInst->parameter[7]=0;
	packet.ConstructPacket();
	
	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
		goto failed_exit;

	for(i=0;i<frameNum;i++)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_ADD_SINGLE_GAIT;
		packet.dspInst->length=2+1+jointNum*2;
		view->ConstructFrameData(packet.dspInst->parameter,i+1);
		packet.ConstructPacket();
		if(
			!view->SendAndRecv(packet,1,100)||
			!packet.DestructPacket()
			)
			goto failed_exit;
		dlg->m_ProgressDownload.SetPos(i+1);
	}

	tgtStr.LoadString(IDS_STRING_FLASH_PROGRAM);
	dlg->m_staticDownloadNotification.SetWindowText(tgtStr);

	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_FLASH_PROGRAM;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
		goto failed_exit;
	
	Sleep(100);
	AfxMessageBox(IDS_STRING_DOWNLOAD_SUCCESS);
	dlg->m_ProgressDownload.SetPos(0);
	dlg->m_staticDownloadNotification.SetWindowText(preStr);
	return 0;

failed_exit:
	AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
	dlg->m_ProgressDownload.SetPos(0);
	dlg->m_staticDownloadNotification.SetWindowText(preStr);

	return 0;
}


void CDialogDownload::OnButtonContinuousRun() 
{
	// TODO: Add your control notification handler code here
	CString currStr;
	CString runStr;
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_CONTINUOUS_RUN);
	cwnd->GetWindowText(currStr);
	runStr.LoadString(IDS_STRING_CONTINOUS_RUN);
	if(currStr!=runStr)
	{
		cwnd->SetWindowText(runStr);
		runEnable=false;
		return;
	}
	currStr.LoadString(IDS_STRING_CONTINOUS_STOP);
	cwnd->SetWindowText(currStr);
	runEnable=true;

	DWORD nThreadId1;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());

	struct DownloadParameter *para=NULL;
	para=new struct DownloadParameter;
	para->parent=view;
	para->child=this;

	::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(RunGait),
		para,
		0,
		&nThreadId1
		);

	return;
}

DWORD CDialogDownload::RunGait(LPVOID lpThreadParameter)
{
	struct DownloadParameter *para=(struct DownloadParameter *)lpThreadParameter;
	CDialogDownload *dlg=para->child;
	CMotionDebug40View *view=para->parent;
	delete para;
	PacketTransformer packet;

	while(dlg->runEnable)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_GAIT_COMMAND;
		packet.dspInst->length=4;
		packet.dspInst->parameter[0]=dlg->m_comboGaitID.GetCurSel()+1;
		packet.dspInst->parameter[1]=1;
		packet.ConstructPacket();
		
		if(!view->SendUntilWait(packet,INFO_GAIT_EXECUTED,10000))
		{
			AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
			return 0;
		}
	}
	return 0;
}