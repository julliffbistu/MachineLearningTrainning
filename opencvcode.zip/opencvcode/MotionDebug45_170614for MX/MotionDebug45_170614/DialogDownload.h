#if !defined(AFX_DIALOGDOWNLOAD_H__EC8ADA14_6DC5_4049_88F5_CD64C9CF9D9A__INCLUDED_)
#define AFX_DIALOGDOWNLOAD_H__EC8ADA14_6DC5_4049_88F5_CD64C9CF9D9A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogDownload.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogDownload dialog

class CDialogDownload : public CDialog
{
// Construction
public:
	CDialogDownload(CWnd* pParent = NULL);   // standard constructor

public:
	bool runEnable;
// Dialog Data
	//{{AFX_DATA(CDialogDownload)
	enum { IDD = IDD_DIALOG_DOWNLOAD };
	CStatic	m_staticDownloadNotification;
	CProgressCtrl	m_ProgressDownload;
	CComboBox	m_comboGaitID;
	CString	m_editGaitDesc;
	CString	m_editRobotDesc;
	//}}AFX_DATA

public:
	static DWORD DownLoad(LPVOID lpThreadParameter);
	static DWORD RunGait(LPVOID lpThreadParameter);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogDownload)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogDownload)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnButtonDownloadGait();
	afx_msg void OnButtonContinuousRun();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGDOWNLOAD_H__EC8ADA14_6DC5_4049_88F5_CD64C9CF9D9A__INCLUDED_)
