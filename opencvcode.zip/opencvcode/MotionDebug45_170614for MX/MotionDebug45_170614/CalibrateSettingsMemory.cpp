#include "stdafx.h"
#include "Resource.h"
#include "CalibrateSettingsMemory.h"
#include "Utilities.h"

CalibrateSettingsMemory::CalibrateSettingsMemory()
{
	memset(&sensorCalibration,0,sizeof(sensorCalibration));
}

int CalibrateSettingsMemory::operator =(CalibrateSettingsMemory &tgt)
{
	memcpy(&sensorCalibration,&tgt.sensorCalibration,sizeof(sensorCalibration));
	return 0;
}

BOOL CalibrateSettingsMemory::StoreToFile(CStdioFile &file)
{
	//not implemented yet
	return TRUE;
}

BOOL CalibrateSettingsMemory::LoadFromFile(CStdioFile &file)
{
	CString temp;
	CHAR var[64];
	int data;
	while(file.ReadString(temp))
	{
		sscanf(temp,"%63[^=^ ]%*[^0-9^-]%d[^\r^\n]",var,&data);
		if(0==strcmp(var,"gyro_offsetx"))
			sensorCalibration.gyro[0].offset=(SHORT)data;
		else if(0==strcmp(var,"gyro_scalex"))
			sensorCalibration.gyro[0].scale=(SHORT)data;
		if(0==strcmp(var,"gyro_offsety"))
			sensorCalibration.gyro[1].offset=(SHORT)data;
		else if(0==strcmp(var,"gyro_scaley"))
			sensorCalibration.gyro[1].scale=(SHORT)data;
		if(0==strcmp(var,"gyro_offsetz"))
			sensorCalibration.gyro[2].offset=(SHORT)data;
		else if(0==strcmp(var,"gyro_scalez"))
			sensorCalibration.gyro[2].scale=(SHORT)data;
		if(0==strcmp(var,"accel_offsetx"))
			sensorCalibration.accel[0].offset=(SHORT)data;
		else if(0==strcmp(var,"accel_scalex"))
			sensorCalibration.accel[0].scale=(SHORT)data;
		if(0==strcmp(var,"accel_offsety"))
			sensorCalibration.accel[1].offset=(SHORT)data;
		else if(0==strcmp(var,"accel_scaley"))
			sensorCalibration.accel[1].scale=(SHORT)data;
		if(0==strcmp(var,"accel_offsetz"))
			sensorCalibration.accel[2].offset=(SHORT)data;
		else if(0==strcmp(var,"accel_scalez"))
			sensorCalibration.accel[2].scale=(SHORT)data;
		if(0==strcmp(var,"mag_offsetx"))
			sensorCalibration.mag[0].offset=(SHORT)data;
		else if(0==strcmp(var,"mag_scalex"))
			sensorCalibration.mag[0].scale=(SHORT)data;
		if(0==strcmp(var,"mag_offsety"))
			sensorCalibration.mag[1].offset=(SHORT)data;
		else if(0==strcmp(var,"mag_scaley"))
			sensorCalibration.mag[1].scale=(SHORT)data;
		if(0==strcmp(var,"mag_offsetz"))
			sensorCalibration.mag[2].offset=(SHORT)data;
		else if(0==strcmp(var,"mag_scalez"))
			sensorCalibration.mag[2].scale=(SHORT)data;

		/*
		if(0==strcmp(var,"gyro_offsetx"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.gyro[0].offset);
		else if(0==strcmp(var,"gyro_scalex"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.gyro[0].scale);
		if(0==strcmp(var,"gyro_offsety"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.gyro[1].offset);
		else if(0==strcmp(var,"gyro_scaley"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.gyro[1].scale);
		if(0==strcmp(var,"gyro_offsetz"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.gyro[2].offset);
		else if(0==strcmp(var,"gyro_scalez"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.gyro[2].scale);
		if(0==strcmp(var,"accel_offsetx"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.accel[0].offset);
		else if(0==strcmp(var,"accel_scalex"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.accel[0].scale);
		if(0==strcmp(var,"accel_offsety"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.accel[1].offset);
		else if(0==strcmp(var,"accel_scaley"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.accel[1].scale);
		if(0==strcmp(var,"accel_offsetz"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.accel[2].offset);
		else if(0==strcmp(var,"accel_scalez"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.accel[2].scale);
		if(0==strcmp(var,"mag_offsetx"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.mag[0].offset);
		else if(0==strcmp(var,"mag_scalex"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.mag[0].scale);
		if(0==strcmp(var,"mag_offsety"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.mag[1].offset);
		else if(0==strcmp(var,"mag_scaley"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.mag[1].scale);
		if(0==strcmp(var,"mag_offsetz"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.mag[2].offset);
		else if(0==strcmp(var,"mag_scalez"))
			sscanf(temp,"%*[^=]%d[^\r^\n]",&sensorCalibration.mag[2].scale);
		*/
	}
	return TRUE;
}


int CalibrateSettingsMemory::GetSensorCalibration(struct SensorCalibration *ps)
{
	memcpy(ps,&sensorCalibration,sizeof(sensorCalibration));
	return sizeof(struct SensorCalibration);
}
