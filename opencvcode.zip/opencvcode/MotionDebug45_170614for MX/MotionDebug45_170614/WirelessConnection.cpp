// WirelessConnection.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "WirelessConnection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWirelessConnection

CWirelessConnection::CWirelessConnection()
{
	sock=INVALID_SOCKET;
	isConnectionOpen=FALSE;
	ipAddress=0;
	port=0;
}

CWirelessConnection::~CWirelessConnection()
{
	if(sock!=INVALID_SOCKET)
	{
		closesocket(sock);
		sock=INVALID_SOCKET;
	}
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CWirelessConnection, CAsyncSocket)
	//{{AFX_MSG_MAP(CWirelessConnection)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CWirelessConnection member functions

BOOL CWirelessConnection::GetConnectionOpen()
{
	return isConnectionOpen;
}

void CWirelessConnection::SetConnectionOpen(BOOL bNewValue)
{
	struct sockaddr_in robotAddress;
	int len=0;

	if(bNewValue==isConnectionOpen)
		return;
	
	if(bNewValue)
	{
		FD_SET rdfs;
		struct timeval tv;
		unsigned long ul=0;
		int ret=0;
		
		if(sock!=INVALID_SOCKET)
		{
			closesocket(sock);
			sock=INVALID_SOCKET;
		}

		if((sock=socket(AF_INET,SOCK_STREAM,0))==INVALID_SOCKET)
			return;
		memset(&robotAddress,0,sizeof(robotAddress));
		robotAddress.sin_family=AF_INET;
		robotAddress.sin_addr.s_addr=htonl(ipAddress);
		robotAddress.sin_port=htons(port);
		len=sizeof(robotAddress);

		ul=1;
		ioctlsocket(sock, FIONBIO, &ul);
		ret=connect(sock,(SOCKADDR *)&robotAddress,len);
		if(ret==-1)
		{
			//here we should first verify the conitinuing aquire is needed
			tv.tv_sec=5;
			tv.tv_usec=0;
			FD_ZERO(&rdfs);
			FD_SET(sock,&rdfs);
			if(0<select(sock+1,NULL,&rdfs,NULL,&tv))
			{
				//change to blocking state
				ul = 0;
				ioctlsocket(sock, FIONBIO, &ul);
			}else
			{
				closesocket(sock);
				sock=INVALID_SOCKET;
				return;
			}
		}else
		{
			//connection is successful immediately and change to blocking state
			ul = 0;
			ioctlsocket(sock, FIONBIO, &ul);
		}
	}else
	{
		if(sock!=INVALID_SOCKET)
		{
			shutdown(sock,1);
			closesocket(sock);
			sock=INVALID_SOCKET;
		}
	}
	isConnectionOpen=bNewValue;
	return;
}

void CWirelessConnection::SetConnectionPort(DWORD ip,WORD pt)
{
	ipAddress=ip;
	port=pt;
	return;
}

void CWirelessConnection::SetSettings()
{
	return;
}

void CWirelessConnection::SetOutput(CByteArray &buf)
{
	char *pbuf=(char *)(buf.GetData());
	int size=buf.GetSize();
	send(sock,pbuf,size,0);
	return;
}

/*
int CWirelessConnection::GetInput(CByteArray &buf,int timeoutMs)
{
	int len=0;
	char pbuf[1024];
	FD_SET rdfs;
	struct timeval tv;

	timeoutMs+=1000;
	tv.tv_sec=timeoutMs/1000;
	tv.tv_usec=timeoutMs%1000;

	FD_ZERO(&rdfs);
	FD_SET(sock,&rdfs);
	if(0<(len=select(sock+1,&rdfs,NULL,NULL,&tv)))
	{
		if(0<(len=recv(sock,pbuf,sizeof(pbuf),0)))
		{
			buf.RemoveAll();
			buf.SetSize(len);
			memcpy(buf.GetData(),pbuf,len);
		}
	}else
		len=0;
	return len;
}
*/

int CWirelessConnection::GetInput(CByteArray &buf,int timeoutMs)
{
	int len=0;
	char pbuf[1024];
	FD_SET rdfs;
	struct timeval tv;

	timeoutMs+=1000;
	tv.tv_sec=timeoutMs/1000;
	tv.tv_usec=timeoutMs%1000;

	FD_ZERO(&rdfs);
	FD_SET(sock,&rdfs);
	if(0<(len=select(sock+1,&rdfs,NULL,NULL,&tv)))
	{
		if(0<(len=recv(sock,pbuf,sizeof(pbuf),0)))
		{
			tv.tv_sec=0;
			tv.tv_usec=100000;
			
			FD_ZERO(&rdfs);
			FD_SET(sock,&rdfs);
			
			while(select(sock+1,&rdfs,NULL,NULL,&tv)>0)
			{
				int temp=0;
				temp=recv(sock,pbuf+len,sizeof(pbuf)-len,0);
				if(temp<=0)
					break;
				len+=temp;
				tv.tv_sec=0;
				tv.tv_usec=100000;
				
				FD_ZERO(&rdfs);
				FD_SET(sock,&rdfs);
			}
			
			buf.RemoveAll();
			buf.SetSize(len);
			memcpy(buf.GetData(),pbuf,len);
		}
	}else
		len=0;
	return len;
}
