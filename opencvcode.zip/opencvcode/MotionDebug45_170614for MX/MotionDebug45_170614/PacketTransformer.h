#ifndef PACKET_TRANSFORMER_H
#define PACKET_TRANSFORMER_H

#define MAX_BUFFER_LENGTH	1024
#define PACKET_TYPE_MASK	0x80

class PacketTransformer
{
public:
	DSP_INST_PACKET *dspInst;
public:
	PacketTransformer();
	PacketTransformer(PBYTE buf,int len);
	void SetRawPacket(PBYTE buf,int len);
	void SetRawPacket(CByteArray &recv);
	void Reset();
	void AppandArray(CByteArray &recv);

	bool ConstructPacket();
	bool DestructPacket();
	bool TryDestructOnePacket();
	CByteArray& GetByteArray();
	BYTE CheckSum();
	int GetLength()
	{
		return length;
	};

protected:
	CByteArray result;
	int length;
	BYTE buffer[MAX_BUFFER_LENGTH];
};

#endif