// DlgSelectConnection.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "Utilities.h"
#include "DspControl.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "RobotView.h"
#include "SingleGait.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "DlgSelectConnection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSelectConnection dialog


CDlgSelectConnection::CDlgSelectConnection(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSelectConnection::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSelectConnection)
	m_editTargetPort = 0;
	//}}AFX_DATA_INIT
		
	isUsingCom=TRUE;
	ipAddress=ntohl(inet_addr("192.168.1.101"));
	port=50001;
}


void CDlgSelectConnection::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSelectConnection)
	DDX_Control(pDX, IDC_IPADDRESS_TARGET_IP, m_targetIP);
	DDX_Text(pDX, IDC_EDIT_TARGET_PORT, m_editTargetPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSelectConnection, CDialog)
	//{{AFX_MSG_MAP(CDlgSelectConnection)
	ON_BN_CLICKED(IDC_RADIO_USE_COM, OnRadioSelectionType)
	ON_BN_CLICKED(IDC_RADIO_USE_NETWORK, OnRadioSelectionType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSelectConnection message handlers

BOOL CDlgSelectConnection::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	UpdateLayout();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgSelectConnection::OnOK() 
{
	int ret=0;
	// TODO: Add extra validation here
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	CButton *pButton=NULL;

	pButton=(CButton *)GetDlgItem(IDC_RADIO_USE_COM);
	ret=pButton->GetCheck();

	if(ret==BST_CHECKED)
		isUsingCom=TRUE;
	else
		isUsingCom=FALSE;

	UpdateData();
	m_targetIP.GetAddress(ipAddress);
	port=m_editTargetPort;
	CDialog::OnOK();
}

void CDlgSelectConnection::UpdateLayout(void)
{
	CButton *pButton=NULL;
	CWnd *cwnd=NULL;
	if(isUsingCom)
	{
		pButton=(CButton *)GetDlgItem(IDC_RADIO_USE_COM);
		pButton->SetCheck(BST_CHECKED);
		pButton=(CButton *)GetDlgItem(IDC_RADIO_USE_NETWORK);
		pButton->SetCheck(BST_UNCHECKED);

		m_targetIP.SetAddress(ipAddress);
		m_editTargetPort=port;
		UpdateData(FALSE);

		m_targetIP.EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_EDIT_TARGET_PORT);
		cwnd->EnableWindow(FALSE);
	}else
	{
		pButton=(CButton *)GetDlgItem(IDC_RADIO_USE_NETWORK);
		pButton->SetCheck(BST_CHECKED);
		pButton=(CButton *)GetDlgItem(IDC_RADIO_USE_COM);
		pButton->SetCheck(BST_UNCHECKED);

		m_targetIP.SetAddress(ipAddress);
		m_editTargetPort=port;
		UpdateData(FALSE);

		m_targetIP.EnableWindow(TRUE);
		cwnd=GetDlgItem(IDC_EDIT_TARGET_PORT);
		cwnd->EnableWindow(TRUE);
	}
}


void CDlgSelectConnection::OnRadioSelectionType() 
{
	// TODO: Add your control notification handler code here
	int ret=0;
	CButton *pButton=NULL;
	CWnd *cwnd=NULL;

	pButton=(CButton *)GetDlgItem(IDC_RADIO_USE_COM);
	ret=pButton->GetCheck();

	if(ret==BST_CHECKED)
	{
		m_targetIP.EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_EDIT_TARGET_PORT);
		cwnd->EnableWindow(FALSE);
	}else
	{
		m_targetIP.EnableWindow(TRUE);
		cwnd=GetDlgItem(IDC_EDIT_TARGET_PORT);
		cwnd->EnableWindow(TRUE);
	}
}
