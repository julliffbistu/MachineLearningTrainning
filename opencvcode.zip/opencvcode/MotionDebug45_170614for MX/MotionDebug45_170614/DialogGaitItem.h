#if !defined(AFX_DIALOGGAITITEM_H__D6728EBF_3E41_4A23_B228_30E1CDD4D76F__INCLUDED_)
#define AFX_DIALOGGAITITEM_H__D6728EBF_3E41_4A23_B228_30E1CDD4D76F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogGaitItem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogGaitItem dialog

class CDialogGaitItem : public CDialog
{
// Construction
public:
	CDialogGaitItem(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogGaitItem)
	enum { IDD = IDD_DIALOG_GAIT_ITEM };
	UINT	m_targetID;
	UINT	m_targetRepeat;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogGaitItem)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogGaitItem)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGGAITITEM_H__D6728EBF_3E41_4A23_B228_30E1CDD4D76F__INCLUDED_)
