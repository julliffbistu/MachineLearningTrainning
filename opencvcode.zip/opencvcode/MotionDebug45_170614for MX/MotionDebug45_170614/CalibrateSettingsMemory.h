#ifndef CALIBRATE_SETTINGS_MEMORY_H
#define CALIBRATE_SETTINGS_MEMORY_H

struct singleAxisCalibration
{
	SHORT offset;
	SHORT scale;
};

struct SensorCalibration
{
	struct singleAxisCalibration gyro[3];
	struct singleAxisCalibration accel[3];
	struct singleAxisCalibration mag[3];
};

class CalibrateSettingsMemory
{
public:
	CalibrateSettingsMemory();
	~CalibrateSettingsMemory(){};

public:
	BOOL LoadFromFile(CStdioFile &file);
	BOOL StoreToFile(CStdioFile &file);
	int operator =(CalibrateSettingsMemory &tgt);

public:
	int GetSensorCalibration(struct SensorCalibration *ps);

protected:
	struct SensorCalibration sensorCalibration;
};

#endif