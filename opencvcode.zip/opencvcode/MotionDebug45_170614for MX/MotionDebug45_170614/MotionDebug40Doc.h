// MotionDebug40Doc.h : interface of the CMotionDebug40Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MOTIONDEBUG40DOC_H__506FDDE7_DD9F_4704_8AE9_F2B73CFA32A1__INCLUDED_)
#define AFX_MOTIONDEBUG40DOC_H__506FDDE7_DD9F_4704_8AE9_F2B73CFA32A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMotionDebug40Doc : public CDocument
{
protected: // create from serialization only
	CMotionDebug40Doc();
	DECLARE_DYNCREATE(CMotionDebug40Doc)

// Attributes
public:

// Operations
public:
	CSingleGait *GetSingleGait();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMotionDebug40Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMotionDebug40Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CSingleGait singleGait;

// Generated message map functions
protected:
	//{{AFX_MSG(CMotionDebug40Doc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MOTIONDEBUG40DOC_H__506FDDE7_DD9F_4704_8AE9_F2B73CFA32A1__INCLUDED_)
