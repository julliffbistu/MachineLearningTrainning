// DialogCalabrate.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "Utilities.h"
#include "DspControl.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "RobotView.h"
#include "SingleGait.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "DialogCalabrate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogCalabrate dialog


CDialogCalabrate::CDialogCalabrate(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogCalabrate::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogCalabrate)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	jointNumber=0;
}


void CDialogCalabrate::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogCalabrate)
	DDX_Control(pDX, IDC_MSFLEXGRID_CALABRATE, m_calabrateList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogCalabrate, CDialog)
	//{{AFX_MSG_MAP(CDialogCalabrate)
	ON_BN_CLICKED(IDC_RADIO_READ_ZERO, OnRadioReadZero)
	ON_BN_CLICKED(IDC_RADIO_TUNING_ZERO, OnRadioTuningZero)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_TORQUE_CONTROL, OnButtonTorqueControl)
	ON_BN_CLICKED(IDC_BUTTON_READ_ZERO, OnButtonReadZero)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogCalabrate message handlers

BOOL CDialogCalabrate::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	int *pList=NULL;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	view->GetCalabrateInfo(jointNumber,&pList);
	if(pList==NULL)
	{
		AfxMessageBox(IDS_STRING_UNABLE_CALABRATE);
		return TRUE;
	}
	
	CString strName;
	COleVariant vt;

	m_calabrateList.SetCols(jointNumber);
	m_calabrateList.SetColWidth(-1,700);
	
	for(unsigned int nIndex=0; nIndex<jointNumber; nIndex++)
	{
		strName.Format( "%.2d", nIndex+1);
		m_calabrateList.SetTextMatrix( 0,nIndex, strName);
	}
	vt.lVal = 1;
	vt.vt = VT_I4;
	m_calabrateList.AddItem( "", vt );
	for(nIndex=0; nIndex<jointNumber; nIndex++ )
	{
		if(pList[nIndex]>=0)
			strName.Format("%d.%d",INTEGER(pList[nIndex]),DECIMAL(pList[nIndex]));
		else
			strName.Format("-%d.%d",INTEGER(-pList[nIndex]),DECIMAL(-pList[nIndex]));
		m_calabrateList.SetTextMatrix( 1, nIndex, strName );
	}
	delete []pList;
	pList=NULL;

	CWnd *cwnd=NULL;
	CButton *pButton=NULL;
	CString tgt;
	tgt.LoadString(IDS_STRING_WAKE_UP);
	cwnd=view->GetDlgItem(IDC_BUTTON_WAKE_UP);
	cwnd->GetWindowText(strName);
	if(strName==tgt)
	{
		pButton=(CButton *)GetDlgItem(IDC_RADIO_READ_ZERO);
		pButton->SetCheck(BST_CHECKED);
		allowEdit=false;
		actionEnable=false;
	}else
	{
		pButton=(CButton *)GetDlgItem(IDC_RADIO_TUNING_ZERO);
		pButton->SetCheck(BST_CHECKED);
		cwnd=GetDlgItem(IDC_BUTTON_TORQUE_CONTROL);
		cwnd->SetWindowText(strName);
		cwnd=GetDlgItem(IDC_BUTTON_READ_ZERO);
		cwnd->EnableWindow(FALSE);
		allowEdit=true;
		actionEnable=true;
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDialogCalabrate::OnOK() 
{
	// TODO: Add extra validation here
	int * pList=NULL;
	CString temp;
	float value=0;
	pList=new int[jointNumber];
	for(unsigned int nIndex=0; nIndex<jointNumber; nIndex++ )
	{
		temp=m_calabrateList.GetTextMatrix(1,nIndex);
		sscanf(temp,"%f",&value);
		pList[nIndex]=FtoI(value*10);
	}	
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	view->SetCalabrateInfo(jointNumber,pList);

	CString father,child;
	CWnd *cwnd1=view->GetDlgItem(IDC_BUTTON_WAKE_UP);
	cwnd1->GetWindowText(father);
	CWnd *cwnd2=GetDlgItem(IDC_BUTTON_TORQUE_CONTROL);
	cwnd2->GetWindowText(child);

	if(father!=child)
	{
		WPARAM wParam;
		LPARAM lParam;

		wParam=MAKELONG(IDC_BUTTON_WAKE_UP,0);
		lParam=0;
		view->PostMessage(WM_COMMAND,wParam,lParam);
	}

	delete []pList;
	pList=NULL;
	CDialog::OnOK();
}

void CDialogCalabrate::OnRadioReadZero() 
{
	// TODO: Add your control notification handler code here
	CWnd *cwnd=NULL;
	cwnd=GetDlgItem(IDC_BUTTON_READ_ZERO);
	cwnd->EnableWindow(TRUE);
	OnLeaveCellMsflexgridCalabrate();
	allowEdit=false;
}

void CDialogCalabrate::OnRadioTuningZero() 
{
	// TODO: Add your control notification handler code here
	CWnd *cwnd=NULL;
	cwnd=GetDlgItem(IDC_BUTTON_READ_ZERO);
	cwnd->EnableWindow(FALSE);
	allowEdit=true;
}

int CDialogCalabrate::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	m_pEdit=new CEdit();
	if(m_pEdit!=NULL)
		m_pEdit->Create(WS_CHILD|WS_BORDER|ES_AUTOHSCROLL,CRect(0,0,0,0),this,USER_EDIT_GRID_ID);
	else
		return -1;

	return 0;
}

void CDialogCalabrate::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	m_pEdit->DestroyWindow();
	delete m_pEdit;
	m_pEdit=NULL;
}

BEGIN_EVENTSINK_MAP(CDialogCalabrate, CDialog)
    //{{AFX_EVENTSINK_MAP(CDialogCalabrate)
	ON_EVENT(CDialogCalabrate, IDC_MSFLEXGRID_CALABRATE, -600 /* Click */, OnClickMsflexgridCalabrate, VTS_NONE)
	ON_EVENT(CDialogCalabrate, IDC_MSFLEXGRID_CALABRATE, 72 /* LeaveCell */, OnLeaveCellMsflexgridCalabrate, VTS_NONE)
	ON_EVENT(CDialogCalabrate, IDC_MSFLEXGRID_CALABRATE, 73 /* Scroll */, OnScrollMsflexgridCalabrate, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CDialogCalabrate::OnClickMsflexgridCalabrate() 
{
	// TODO: Add your control notification handler code here
	if(
		!allowEdit||
		m_calabrateList.GetRow()!=m_calabrateList.GetRowSel()||
		m_calabrateList.GetCol()!=m_calabrateList.GetColSel()||
		m_calabrateList.GetRow()==m_calabrateList.GetRows()-1||
		m_calabrateList.GetRow()==0
		)
		return;
	
	CDC* pDC = m_calabrateList.GetDC();
	
	long x = ( m_calabrateList.GetCellLeft() * pDC -> GetDeviceCaps ( LOGPIXELSX ) ) / 1440;
	
	long y = ( m_calabrateList.GetCellTop() * pDC -> GetDeviceCaps ( LOGPIXELSY ) ) / 1440;
	
	long cx = ( m_calabrateList.GetCellWidth() * pDC -> GetDeviceCaps ( LOGPIXELSX ) ) / 1440;
	
	long cy = ( m_calabrateList.GetCellHeight() * pDC -> GetDeviceCaps ( LOGPIXELSY ) )/ 1440;
	
	ReleaseDC ( pDC );
	
	CString strContent;
	CPoint pt(x,y);
	
	strContent = m_calabrateList.GetText();
	m_pEdit->SetWindowText(strContent);

	m_calabrateList.ClientToScreen(&pt);
	ScreenToClient(&pt);
	m_pEdit->MoveWindow(pt.x,pt.y,cx,cy,FALSE);
	m_pEdit->ShowWindow(SW_SHOW);
	m_pEdit->SetFocus();
}

void CDialogCalabrate::OnLeaveCellMsflexgridCalabrate() 
{
	// TODO: Add your control notification handler code here
	if (m_pEdit->IsWindowVisible())
	{
		int nCol;
		int nRow;
		
		CString strContent;
		nCol = m_calabrateList.GetCol();
		nRow = m_calabrateList.GetRow();
		m_pEdit->GetWindowText(strContent);
		if(actionEnable)
		{
			CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
			int value=view->StrToServo(strContent,0);
			PacketTransformer packet;
			
			packet.dspInst->id=ID_DSP;
			packet.dspInst->length=5;
			packet.dspInst->instruction=INST_SINGLE_ACTION;
			packet.dspInst->parameter[0]=nCol;
			packet.dspInst->parameter[1]=value&0x00ff;
			packet.dspInst->parameter[2]=(value&0xff00)>>8;
			packet.ConstructPacket();
			
			if(
				!view->SendAndRecv(packet,2,100)||
				!packet.DestructPacket()||
				packet.dspInst->instruction!=(INST_SINGLE_ACTION|PACKET_TYPE_MASK)
				)
				AfxMessageBox(IDS_STRING_NO_ECHO);
		}
		m_calabrateList.SetTextMatrix(nRow, nCol, strContent);
		m_pEdit->ShowWindow(SW_HIDE);
	}
}

void CDialogCalabrate::OnScrollMsflexgridCalabrate() 
{
	// TODO: Add your control notification handler code here
	if ( !m_pEdit->IsWindowVisible ( ) ) 
		 return;
	else
		OnLeaveCellMsflexgridCalabrate();
}

void CDialogCalabrate::OnButtonTorqueControl() 
{
	// TODO: Add your control notification handler code here
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	PacketTransformer packet;
	CString name;
	CString tgt;
	
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_TORQUE_CONTROL);
	cwnd->GetWindowText(name);
	tgt.LoadString(IDS_STRING_WAKE_UP);
	
	packet.dspInst->id=ID_DSP;
	if(name==tgt)
		packet.dspInst->instruction=INST_TORQUE_ON;
	else
		packet.dspInst->instruction=INST_TORQUE_OFF;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	
	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_NO_ECHO);
		return;
	}

	if(name==tgt)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_INITIAL_STATE;
		ConstructFrameData(packet.dspInst->parameter);
		packet.dspInst->length=2+1+m_calabrateList.GetCols()*2;
		packet.ConstructPacket();
		if(!view->SendUntilWait(packet,INFO_GAIT_EXECUTED,500))
			AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
		name.LoadString(IDS_STRING_FALL_ASLEEP);
		actionEnable=true;
	}else
	{
		name.LoadString(IDS_STRING_WAKE_UP);
		actionEnable=false;
	}
	cwnd->SetWindowText(name);
}

void CDialogCalabrate::ConstructFrameData(PBYTE pbuf)
{
	CString temp;
	UINT nValue=0;
	UINT i;
	PBYTE pNext=pbuf;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());

	*pNext=1;
	pNext++;
	
	for(i=0;i<m_calabrateList.GetCols();i++)
	{
		temp=m_calabrateList.GetTextMatrix(1,i);
		nValue=view->StrToServo(temp,0);
		*pNext=nValue&0x00ff;
		pNext++;
		*pNext=(nValue&0xff00)>>8;
		pNext++;
	}
}

void CDialogCalabrate::OnButtonReadZero() 
{
	// TODO: Add your control notification handler code here
	//send a message to aquire the data of the current turnning angle
}
