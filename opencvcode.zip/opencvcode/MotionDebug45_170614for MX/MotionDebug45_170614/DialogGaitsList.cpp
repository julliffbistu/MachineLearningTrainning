// DialogGaitsList.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "DialogGaitItem.h"
#include "DspControl.h"
#include "SingleGait.h"
#include "RobotView.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "DialogGaitsList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogGaitsList dialog


CDialogGaitsList::CDialogGaitsList(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogGaitsList::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogGaitsList)
	//}}AFX_DATA_INIT
	enableRecording=false;
	gaitCounter=0;
	gaitListRunning=false;
	recvThreadRunning=false;
	feedBackStartTime=0;
	InitializeCriticalSection(&cs);
}


void CDialogGaitsList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogGaitsList)
	DDX_Control(pDX, IDC_EDIT_INCLINOMETER_Y, m_editInclinometerY);
	DDX_Control(pDX, IDC_EDIT_INCLINOMETER_X, m_editInclinometerX);
	DDX_Control(pDX, IDC_EDIT_RECORD_FILE, m_editRecordFile);
	DDX_Control(pDX, IDC_LIST_GAIT_LIST, m_listGaitList);
	DDX_Control(pDX, IDC_BUTTON_EDIT_CURRENT, m_buttonEditC);
	DDX_Control(pDX, IDC_BUTTON_DELETE_CURRENT, m_buttonDeleteC);
	DDX_Control(pDX, IDC_BUTTON_INSERT_TOP, m_buttonInsertT);
	DDX_Control(pDX, IDC_BUTTON_INSERT_BOTTOM, m_buttonInsertB);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogGaitsList, CDialog)
	//{{AFX_MSG_MAP(CDialogGaitsList)
	ON_BN_CLICKED(IDC_BUTTON_EDIT_CURRENT, OnButtonEditCurrent)
	ON_BN_CLICKED(IDC_BUTTON_INSERT_BOTTOM, OnButtonInsertBottom)
	ON_BN_CLICKED(IDC_BUTTON_INSERT_TOP, OnButtonInsertTop)
	ON_BN_CLICKED(IDC_BUTTON_DELETE_CURRENT, OnButtonDeleteCurrent)
	ON_BN_CLICKED(IDC_BUTTON_RUN_GAITLIST, OnButtonRunGaitlist)
	ON_BN_CLICKED(IDC_BUTTON_NEW_FILE, OnButtonNewFile)
	ON_BN_CLICKED(IDC_BUTTON_START_FEEDBACK, OnButtonStartFeedback)
	ON_BN_CLICKED(IDC_BUTTON_START_RECORD, OnButtonStartRecord)
	//}}AFX_MSG_MAP
//	ON_BN_CLICKED(IDCANCEL, &CDialogGaitsList::OnBnClickedCancel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogGaitsList message handlers
struct RecvThreadParameter
{
	CMotionDebug40View *parent;
	CDialogGaitsList *child;
};

BOOL CDialogGaitsList::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	DWORD nThreadId1;
	HICON hlcon=AfxGetApp()->LoadIcon(IDI_ICON_INSERT_BOTTOM);
	m_buttonInsertB.SetIcon(hlcon);
	hlcon=AfxGetApp()->LoadIcon(IDI_ICON_INSERT_TOP);
	m_buttonInsertT.SetIcon(hlcon);
	hlcon=AfxGetApp()->LoadIcon(IDI_ICON_DELETE_CURRENT);
	m_buttonDeleteC.SetIcon(hlcon);
	hlcon=AfxGetApp()->LoadIcon(IDI_ICON_EDIT_CURRENT);
	m_buttonEditC.SetIcon(hlcon);

	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	struct RecvThreadParameter *para=NULL;
	para=new struct RecvThreadParameter;
	para->parent=view;
	para->child=this;
	recvThreadRunning=true;

	::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(RecvThread),
		para,
		0,
		&nThreadId1
		);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

DWORD CDialogGaitsList::RecvThread(LPVOID lpThreadParameter)
{
	PacketTransformer packet;
	struct SensorsRaw sensorsRaw;
	struct RecvThreadParameter *para=(struct RecvThreadParameter *)lpThreadParameter;
	CDialogGaitsList *dlg=para->child;
	CMotionDebug40View *view=para->parent;
	delete para;

	while(dlg->recvThreadRunning)
	{
		if(view->TryRecvPacket(packet))
		{
			switch(packet.dspInst->instruction&~PACKET_TYPE_MASK)
			{
			case INFO_GAIT_EXECUTED:
				if(dlg->gaitListRunning)
				{
					dlg->gaitCounter++;
					if(dlg->gaitCounter<dlg->m_listGaitList.GetCount())
					{
						//send the gait command to board
						dlg->SendCurrentGait(view);
					}else
					{
						WPARAM wParam;
						LPARAM lParam;
						
						wParam=MAKELONG(IDC_BUTTON_RUN_GAITLIST,0);
						lParam=0;
						dlg->SendMessage(WM_COMMAND,wParam,lParam);
					}
				}
				break;
			case INFO_INCLINOMETER_FEEDBACK:
				{
					CString str;
					WORD x,y;
					x=(WORD)packet.dspInst->parameter[0]+(WORD)packet.dspInst->parameter[1]*256;
					y=(WORD)packet.dspInst->parameter[2]+(WORD)packet.dspInst->parameter[3]*256;
					str.Format("%d",x);
					dlg->m_editInclinometerX.SetWindowText(str);
					str.Format("%d",y);
					dlg->m_editInclinometerY.SetWindowText(str);
					if(dlg->enableRecording)
					{
						DWORD thisTime=0;
						thisTime=GetTickCount()-dlg->feedBackStartTime;
						str.Format("%d,%d,%d\n",thisTime,x,y);
						dlg->m_recordFile.WriteString(str);
					}
				}
				break;
			case INST_START_INCLINOMETER_FEEDBACK:
				{
					PacketTransformer retPacket;
					retPacket.dspInst->id=ID_DSP;
					retPacket.dspInst->instruction=INST_INCLINOMETER_REQUIRED;
					retPacket.dspInst->length=2;
					retPacket.ConstructPacket();
					EnterCriticalSection(&(dlg->cs));
					if(!view->SendSinglePacket(retPacket))
					{
						LeaveCriticalSection(&(dlg->cs));
						return false;
					}
					LeaveCriticalSection(&(dlg->cs));
				}
				break;
			case INST_INCLINOMETER_REQUIRED:
				{
					short x,y;
					CString str;
					PacketTransformer retPacket;
					
					retPacket.dspInst->id=ID_DSP;
					retPacket.dspInst->instruction=INST_INCLINOMETER_REQUIRED;
					retPacket.dspInst->length=2;
					retPacket.ConstructPacket();
					EnterCriticalSection(&(dlg->cs));
					if(!view->SendSinglePacket(retPacket))
					{
						LeaveCriticalSection(&(dlg->cs));
						return false;
					}
					LeaveCriticalSection(&(dlg->cs));

					x=(short)packet.dspInst->parameter[0]+(short)packet.dspInst->parameter[1]*256;
					y=(short)packet.dspInst->parameter[2]+(short)packet.dspInst->parameter[3]*256;
					str.Format("%-6d",x);
					dlg->m_editInclinometerX.SetWindowText(str);
					str.Format("%-6d",y);
					dlg->m_editInclinometerY.SetWindowText(str);

					sensorsRaw.gyro[0]=(short)packet.dspInst->parameter[0]+(short)packet.dspInst->parameter[1]*256;
					sensorsRaw.gyro[1]=(short)packet.dspInst->parameter[2]+(short)packet.dspInst->parameter[3]*256;;
					sensorsRaw.gyro[2]=(short)packet.dspInst->parameter[4]+(short)packet.dspInst->parameter[5]*256;;

					sensorsRaw.accel[0]=(short)packet.dspInst->parameter[6]+(short)packet.dspInst->parameter[7]*256;;
					sensorsRaw.accel[1]=(short)packet.dspInst->parameter[8]+(short)packet.dspInst->parameter[9]*256;;
					sensorsRaw.accel[2]=(short)packet.dspInst->parameter[10]+(short)packet.dspInst->parameter[11]*256;;

					sensorsRaw.mag[0]=(short)packet.dspInst->parameter[12]+(short)packet.dspInst->parameter[13]*256;;
					sensorsRaw.mag[1]=(short)packet.dspInst->parameter[14]+(short)packet.dspInst->parameter[15]*256;;
					sensorsRaw.mag[2]=(short)packet.dspInst->parameter[16]+(short)packet.dspInst->parameter[17]*256;;
					if(dlg->enableRecording)
					{
						DWORD thisTime=0;
						thisTime=GetTickCount()-dlg->feedBackStartTime;
						str.Format("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
							thisTime,
							sensorsRaw.gyro[0],
							sensorsRaw.gyro[1],
							sensorsRaw.gyro[2],
							sensorsRaw.accel[0],
							sensorsRaw.accel[1],
							sensorsRaw.accel[2],
							sensorsRaw.mag[0],
							sensorsRaw.mag[1],
							sensorsRaw.mag[2]
						);
						dlg->m_recordFile.WriteString(str);
					}
					Sleep(50);
				}
				break;
			default:
				break;
			}
		}
	}
	return 0;
}

bool CDialogGaitsList::SendCurrentGait(CMotionDebug40View *view)
{
	PacketTransformer packet;
	CString itemStr;
	int id=0;
	int repeat=0;

	if(gaitCounter>=m_listGaitList.GetCount())
		return false;

	m_listGaitList.GetText(gaitCounter,itemStr);
	sscanf(itemStr,"%d%*[^*]*%d",&id,&repeat);
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_GAIT_COMMAND;
	packet.dspInst->length=4;
	packet.dspInst->parameter[0]=id;
	packet.dspInst->parameter[1]=repeat;
	packet.ConstructPacket();
	EnterCriticalSection(&cs);
	if(!view->SendSinglePacket(packet))
	{
		LeaveCriticalSection(&cs);
		return false;
	}
	LeaveCriticalSection(&cs);
	return true;
}

bool CDialogGaitsList::SendFeedback(CMotionDebug40View *view,bool start)
{
	PacketTransformer packet;
	packet.dspInst->id=ID_DSP;
	if(start)
		packet.dspInst->instruction=INST_START_INCLINOMETER_FEEDBACK;
	else
		packet.dspInst->instruction=INST_STOP_INCLINOMETER_FEEDBACK;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	EnterCriticalSection(&cs);
	if(!view->SendSinglePacket(packet))
	{
		LeaveCriticalSection(&cs);
		return false;
	}
	LeaveCriticalSection(&cs);
	return true;
}

void CDialogGaitsList::OnButtonEditCurrent() 
{
	// TODO: Add your control notification handler code here
	CDialogGaitItem dlg;
	CString itemStr;
	int cntr=m_listGaitList.GetCount();
	int sel=m_listGaitList.GetCurSel();
	
	if(sel!=-1&&sel<cntr)
	{
		int id=0;
		int repeat=0;
		m_listGaitList.GetText(sel,itemStr);
		sscanf(itemStr,"%d%*[^*]*%d",&id,&repeat);
		dlg.m_targetID=id;
		dlg.m_targetRepeat=repeat;
		if(dlg.DoModal()==IDOK)
		{
			itemStr.Format(_T("%-10d*%10d"),dlg.m_targetID,dlg.m_targetRepeat);
			m_listGaitList.DeleteString(sel);
			m_listGaitList.InsertString(sel,itemStr);
		}
	}else
	{
		if(dlg.DoModal()==IDOK)
		{
			itemStr.Format(_T("%-10d*%10d"),dlg.m_targetID,dlg.m_targetRepeat);
			m_listGaitList.InsertString(cntr,itemStr);
		}
	}
}

void CDialogGaitsList::OnButtonInsertBottom() 
{
	// TODO: Add your control notification handler code here
	CDialogGaitItem dlg;
	CString itemStr;
	int cntr=m_listGaitList.GetCount();
	int sel=m_listGaitList.GetCurSel();
	
	if(sel!=-1&&sel<cntr)
	{
		if(dlg.DoModal()==IDOK)
		{
			itemStr.Format(_T("%-10d*%10d"),dlg.m_targetID,dlg.m_targetRepeat);
			m_listGaitList.InsertString(sel,itemStr);
		}
	}else
		AfxMessageBox(IDS_STRING_INVALID_SELECTION);
}

void CDialogGaitsList::OnButtonInsertTop() 
{
	// TODO: Add your control notification handler code here
	CDialogGaitItem dlg;
	CString itemStr;
	int cntr=m_listGaitList.GetCount();
	int sel=m_listGaitList.GetCurSel();
	
	if(sel!=-1&&sel<cntr)
	{
		if(dlg.DoModal()==IDOK)
		{
			itemStr.Format(_T("%-10d*%10d"),dlg.m_targetID,dlg.m_targetRepeat);
			m_listGaitList.InsertString(sel+1,itemStr);
		}
	}else
		AfxMessageBox(IDS_STRING_INVALID_SELECTION);
}

void CDialogGaitsList::OnButtonDeleteCurrent() 
{
	// TODO: Add your control notification handler code here
	CDialogGaitItem dlg;
	CString itemStr;
	int cntr=m_listGaitList.GetCount();
	int sel=m_listGaitList.GetCurSel();
	
	if(sel!=-1&&sel<cntr)
		m_listGaitList.DeleteString(sel);
	else
		AfxMessageBox(IDS_STRING_INVALID_DELETE);
}

void CDialogGaitsList::OnButtonRunGaitlist() 
{
	// TODO: Add your control notification handler code here
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	CString str1;
	CString str2;
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_RUN_GAITLIST);
	cwnd->GetWindowText(str1);
	str2.LoadString(IDS_STRING_RUN_GAITLIST);
	if(str1!=str2)
	{
		gaitListRunning=false;
		cwnd->EnableWindow(false);
		Sleep(1000);
		cwnd->EnableWindow(true);
		cwnd->SetWindowText(str2);
		m_buttonDeleteC.EnableWindow(true);
		m_buttonEditC.EnableWindow(true);
		m_buttonInsertB.EnableWindow(true);
		m_buttonInsertT.EnableWindow(true);
		return;
	}

	gaitCounter=0;
	gaitListRunning=true;
	if(!SendCurrentGait(view))
	{
		AfxMessageBox(IDS_STRING_UNABLE_RUNLIST);
		gaitListRunning=false;
		return;
	}
	str1.LoadString(IDS_STRING_STOP_GAITLIST);
	cwnd->SetWindowText(str1);
	m_buttonDeleteC.EnableWindow(false);
	m_buttonEditC.EnableWindow(false);
	m_buttonInsertB.EnableWindow(false);
	m_buttonInsertT.EnableWindow(false);
	return;
}

void CDialogGaitsList::OnButtonNewFile() 
{
	// TODO: Add your control notification handler code here
	CString tempName;
	CString temp;
	CFileDialog dlg(FALSE, "txt", "Default",OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"text Files(*.txt)|*.txt||");
	GetDlgItem(IDC_BUTTON_NEW_FILE)->GetWindowText(tempName);
	temp.LoadString(IDS_STRING_CLOSE_FILE);
	if(tempName==temp)
	{
		if(enableRecording)
		{
			AfxMessageBox(IDS_STRING_ERROR_CLOSE);
			return;
		}
		m_recordFile.Close();
		temp.LoadString(IDS_STRING_OPEN_FILE);
		GetDlgItem(IDC_BUTTON_NEW_FILE)->SetWindowText(temp);
		m_editRecordFile.SetWindowText("");
		return;
	}
	
	if ( dlg.DoModal()!=IDOK) 
		return;
	tempName=dlg.GetFileTitle();
	if(tempName.GetLength()==0)
		return;
	tempName=dlg.GetPathName();
	if(!m_recordFile.Open(tempName, CFile::modeWrite|CFile::modeCreate))
	{
		AfxMessageBox(IDS_STRING_UNABLE_OPENFILE);
		return;
	}
	
	m_editRecordFile.SetWindowText(dlg.GetFileName());
	temp.LoadString(IDS_STRING_CLOSE_FILE);
	GetDlgItem(IDC_BUTTON_NEW_FILE)->SetWindowText(temp);
}

void CDialogGaitsList::OnButtonStartFeedback() 
{
	// TODO: Add your control notification handler code here
	CString str1;
	CString str2;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_START_FEEDBACK);
	cwnd->GetWindowText(str1);
	str2.LoadString(IDS_STRING_START_FEEDBACK);
	if(str1!=str2)
	{
		SendFeedback(view,false);
		cwnd->SetWindowText(str2);
		return;
	}
	if(!SendFeedback(view,true))
	{
		AfxMessageBox(IDS_STRING_UNABLE_FEEDBACK);
		return;
	}
	feedBackStartTime=GetTickCount();
	str2.LoadString(IDS_STRING_STOP_FEEDBACK);
	cwnd->SetWindowText(str2);
}

void CDialogGaitsList::OnButtonStartRecord() 
{
	// TODO: Add your control notification handler code here
	CString str1;
	CString str2;
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_START_RECORD);
	cwnd->GetWindowText(str1);
	str2.LoadString(IDS_STRING_START_RECORD);
	if(str1!=str2)
	{
		enableRecording=false;
		cwnd->SetWindowText(str2);
		return;
	}

	if(!m_recordFile.m_pStream)
	{
		enableRecording=false;
		AfxMessageBox(IDS_STRING_UNABLE_STARTRECORD);
		return;
	}
	enableRecording=true;
	str1.LoadString(IDS_STRING_STOP_RECORD);
	cwnd->SetWindowText(str1);
	return;
}

void CDialogGaitsList::OnOK() 
{
	// TODO: Add extra validation here
	if(!CheckTaskComplete())
	{
		AfxMessageBox(IDS_STRING_TASKCOMPLETE_FAILED);
		return;
	}
	recvThreadRunning=false;
	Sleep(500);
	CDialog::OnOK();
}

bool CDialogGaitsList::CheckTaskComplete()
{
	CString str1;
	CString str2;
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_START_FEEDBACK);
	cwnd->GetWindowText(str1);
	str2.LoadString(IDS_STRING_START_FEEDBACK);
	return !(str1!=str2||gaitListRunning||m_recordFile.m_pStream||enableRecording);
}

void CDialogGaitsList::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(!CheckTaskComplete())
	{
		AfxMessageBox(IDS_STRING_TASKCOMPLETE_FAILED);
		return;
	}
	recvThreadRunning=false;
	Sleep(500);	
	CDialog::OnCancel();
}

//void CDialogGaitsList::OnBnClickedCancel()
//{
//	// TODO: �ڴ����ӿؼ�֪ͨ�����������
//	OnCancel();
//}
