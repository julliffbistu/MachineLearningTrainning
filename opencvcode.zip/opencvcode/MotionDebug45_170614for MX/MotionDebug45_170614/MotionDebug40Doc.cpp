// MotionDebug40Doc.cpp : implementation of the CMotionDebug40Doc class
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "SingleGait.h"
#include "Utilities.h"
#include "DspControl.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "RobotView.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "DialogCalabrate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40Doc

IMPLEMENT_DYNCREATE(CMotionDebug40Doc, CDocument)

BEGIN_MESSAGE_MAP(CMotionDebug40Doc, CDocument)
	//{{AFX_MSG_MAP(CMotionDebug40Doc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40Doc construction/destruction

CMotionDebug40Doc::CMotionDebug40Doc()
{
	// TODO: add one-time construction code here

}

CMotionDebug40Doc::~CMotionDebug40Doc()
{
}

BOOL CMotionDebug40Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	singleGait.InitializeToDefault();
	SetTitle(singleGait.MakeTitle());

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40Doc serialization

void CMotionDebug40Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		//write basic infomation
		CString temp;
		temp.Format("gid=%d;\r\n",singleGait.GetGaitID());
		ar.WriteString(temp);
		temp.Format("joint_number=%d;\r\n",singleGait.GetJointNum());
		ar.WriteString(temp);
		temp.Format("gait_description='%s';\r\n",singleGait.GetGaitDesc());
		ar.WriteString(temp);
		temp.Format("robot_description='%s';\r\n",singleGait.GetRobotDesc());
		ar.WriteString(temp);
		//write zero point list
		int *pList=new int[singleGait.GetJointNum()];
		CString temp2;
		singleGait.GetZeroList(pList);
		temp="mechanical_zero_point=[";
		for(unsigned int i=0;i<singleGait.GetJointNum();i++)
		{
			if(pList[i]>=0)
				temp2.Format("%d.%d",INTEGER(pList[i]),DECIMAL(pList[i]));
			else
				temp2.Format("-%d.%d",INTEGER(-pList[i]),DECIMAL(-pList[i]));
			temp+=temp2;
			if(i!=singleGait.GetJointNum()-1)
				temp+=",";
		}
		temp+="];\r\n";
		ar.WriteString(temp);
		delete []pList;
		pList=NULL;
		//write gait data
		POSITION p=this->GetFirstViewPosition();
		CMotionDebug40View *view=(CMotionDebug40View *)this->GetNextView(p);
		temp.Format("frame_number=%d;\r\n",view->m_MotionList.GetRows()-2);
		ar.WriteString(temp);
		
		ar.WriteString("gait_data=[\r\n");
		long row=view->m_MotionList.GetRows()-2;
		long col=view->m_MotionList.GetCols()-1;
		for(int j=1;j<row+1;j++)
		{
			unsigned int i;
			temp.Empty();
			for(i=1;i<col;i++)
			{
				temp+=view->m_MotionList.GetTextMatrix(j,i);
				temp+=",";
			}
			temp+=view->m_MotionList.GetTextMatrix(j,i);
			temp+=";\r\n";
			ar.WriteString(temp);
		}
		ar.WriteString("];\r\n");
	}
	else
	{
		// TODO: add loading code here
		CString temp;
		char var[31];
		unsigned int jn=0;
		unsigned int fn=0;
		POSITION p=this->GetFirstViewPosition();
		CMotionDebug40View *view=(CMotionDebug40View *)this->GetNextView(p);

		while(ar.ReadString(temp))
		{
			sscanf(temp,"%30[^=^ ]",var);
			if(0==strcmp(var,"gid"))
			{
				unsigned int gid=0;
				sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&gid);
				singleGait.SetGaitID(gid);
			}else if(0==strcmp(var,"joint_number"))
			{
				sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&jn);
				singleGait.SetJointNum(jn);
			}else if(0==strcmp(var,"frame_number"))
			{
				sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&fn);
			}else if(0==strcmp(var,"gait_description"))
			{
				char *pstr=new char[temp.GetLength()];
				sscanf(temp,"%*[^=]%*[^']'%[^']",pstr);
				CString temp2;
				temp2=pstr;
				singleGait.SetGaitDesc(temp2);
				delete pstr;
			}else if(0==strcmp(var,"robot_description"))
			{
				char *pstr=new char[temp.GetLength()];
				sscanf(temp,"%*[^=]%*[^']'%[^']",pstr);
				CString temp2;
				temp2=pstr;
				singleGait.SetRobotDesc(temp2);
				delete pstr;
			}else if(0==strcmp(var,"gait_data"))
			{
				float fdata=0;
				CString strData;
				COleVariant vt;

				if(jn==0||fn==0)
				{
					AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
					return;
				}
				view->m_MotionList.SetCols(jn+2);
				while(view->m_MotionList.GetRows()>2)
					view->m_MotionList.RemoveItem(1);

				for(unsigned int i=0;i<fn;i++)
				{
					vt.lVal = i+1;
					vt.vt = VT_I4;
					view->m_MotionList.AddItem( "", vt );
					strData.Format("%d",i+1);
					view->m_MotionList.SetTextMatrix(i+1,0,strData);
					
					ar.ReadString(temp);
					sscanf(temp,"%f",&fdata);
					strData.Format("%d",FtoI(fdata));
					view->m_MotionList.SetTextMatrix(i+1,1,strData);
					temp.Delete(0,temp.Find(',')+1);
					for(unsigned int j=0;j<jn;j++)
					{
						sscanf(temp,"%f",&fdata);
						strData.Format("%1.1f",fdata);
						view->m_MotionList.SetTextMatrix(i+1,j+2,strData);
						temp.Delete(0,temp.Find(',')+1);
					}
				}
				view->SetNoDefault();
			}else if(0==strcmp(var,"mechanical_zero_point"))
			{
				char *pstr=NULL;
				int *pList=NULL;
				float fdata=0;
				int cntr=0;
				int start=0;
				
				if(jn==0)
				{
					AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
					return;
				}
				pstr=new char[temp.GetLength()];
				memset(pstr,0,temp.GetLength());
				sscanf(temp,"%*[^=]%*[^[][%[^]]",pstr);
				CString temp2=pstr;
				delete pstr;
				
				while(-1!=temp2.Find(',',start))
				{
					cntr++;
					start=temp2.Find(',',start)+1;
				}
				if(temp2.GetLength()!=start)
					cntr++;
				
				pList=new int[cntr];
				memset(pList,0,cntr*sizeof(int));
				cntr=0;
				while(temp2.GetLength())
				{
					sscanf(temp2,"%f",&fdata);
					pList[cntr]=FtoI(fdata*10);
					if(-1!=temp2.Find(','))
						temp2.Delete(0,temp2.Find(',')+1);
					else
						temp2.Empty();
					cntr++;
				}
				
				unsigned int previousNum=0;
				int *pCurrList=NULL;
				previousNum=singleGait.GetJointNum();
				pCurrList=new int[previousNum];
				singleGait.GetZeroList(pCurrList);
				if(
					(cntr!=previousNum||
					memcmp(pList,pCurrList,sizeof(int)*cntr)!=0)&&
					IDYES==AfxMessageBox(IDS_STRING_ZEROPOINT_INCOMPATIBAL,MB_YESNO)
					)
				{
					CDialogCalabrate dlg;
					singleGait.SetJointNum(cntr);
					singleGait.SetZeroList(pList);
					dlg.SetOwner(view);
					if(IDOK!=dlg.DoModal()&&IDYES==AfxMessageBox(IDS_STRING_REJECT_ZEROPOINT,MB_YESNO))
					{
						singleGait.SetJointNum(previousNum);
						singleGait.SetZeroList(pCurrList);
					}
				}
				delete pCurrList;
				delete pList;
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40Doc diagnostics

#ifdef _DEBUG
void CMotionDebug40Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMotionDebug40Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40Doc commands

CSingleGait *CMotionDebug40Doc::GetSingleGait()
{
	return &singleGait;
}
