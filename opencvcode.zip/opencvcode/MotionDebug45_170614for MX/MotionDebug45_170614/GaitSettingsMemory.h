#ifndef GAIT_SETTINGS_MEMORY_H
#define GAIT_SETTINGS_MEMORY_H

class GaitSettingsMemory
{
public:
	GaitSettingsMemory();
	~GaitSettingsMemory();

public:
	BOOL LoadFromFile(CStdioFile &file);
	BOOL StoreToFile(CStdioFile &file);
	int operator =(GaitSettingsMemory &tgt);

public:
	int GetMechanicalZeroPoint(int **pList);
	int GetRobotTypeParameter(int **pList);
	int GetRobotWalkingParameter(int **pList);
	int GetFrameData(int **pList,int *step,int *frame);

protected:
	unsigned int robot_type_length;
	unsigned int robot_walking_length;
	unsigned int frame_step;
	unsigned int frame_number;
	unsigned int mech_zero_length;

	int *probot_type_parameter;
	int *probot_walking_parameter;
	int *pframe_data;
	int *pmechanical_zero_point;

	CString robot_type_description;
	CString robot_walking_description;
	CString frame_description;
	CString single_robot_description;
};

#endif