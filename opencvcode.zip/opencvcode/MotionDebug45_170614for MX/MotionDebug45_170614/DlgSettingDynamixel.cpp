// DlgSettingDynamixel.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "DlgSettingDynamixel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSettingDynamixel dialog


CDlgSettingDynamixel::CDlgSettingDynamixel(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSettingDynamixel::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSettingDynamixel)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgSettingDynamixel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSettingDynamixel)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSettingDynamixel, CDialog)
	//{{AFX_MSG_MAP(CDlgSettingDynamixel)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSettingDynamixel message handlers
