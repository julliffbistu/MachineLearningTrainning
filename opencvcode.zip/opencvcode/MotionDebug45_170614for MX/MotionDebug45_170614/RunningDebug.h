#include "afxwin.h"
#if !defined(AFX_RUNNINGDEBUG_H__D15ECEA1_3242_4B9E_9DCF_23B02AD2698E__INCLUDED_)
#define AFX_RUNNINGDEBUG_H__D15ECEA1_3242_4B9E_9DCF_23B02AD2698E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RunningDebug.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRunningDebug dialog
struct SpecialGaitCommand
{
	USHORT id;
	USHORT times;
};

struct HeadMovingCommand
{
	SHORT pitch;
	SHORT yaw;
};

struct GaitEffect
{
	SHORT xOffset;
	SHORT yOffset;
	SHORT thetaOffset;
};

struct Sensors
{
	SHORT incline[3];
	SHORT omega[3];
};

//fast inverse kinematics related
struct RigidOffset_t
{
	SHORT x;
	SHORT y;
	SHORT z;
};

struct RigidPose_t
{
	SHORT alpha;
	SHORT beta;
	SHORT theta;
};

struct RigidBody_t
{
	struct RigidOffset_t offset;
	struct RigidPose_t pose;
};

#define INVALID_RIGIDBODY_VALUE	0xffff

struct StateSwapInput
{
	USHORT ctrReg1;
	USHORT ctrReg2;
	struct GaitEffect dirInst;
	struct SpecialGaitCommand spcInst;
	struct HeadMovingCommand headInst;
};
#define GAIT_DIRECTION_VALID	0x0001
#define SPECIAL_GAIT_VALID		0x0002
#define GAIT_RESET_VALID		0x0004
#define COPY_RESET_ODOMETER		0x0008
#define HEAD_MOVE_VALID			0x0010
#define TORQUE_ENABLE_VALID		0x0020
#define SENSOR_ENABLE_VALID		0x0040
#define WALK_KICK_LEFT			0x0080
#define WALK_KICK_RIGHT			0x0100

#define SPECIAL_GAIT_PENDING	0x0001
#define GAIT_RESET_PENDING		0x0002
#define RESET_ODOMETER_PENDING	0x0004
#define WALK_KICK_PENDING		0x0008

struct StateSwapOutput
{
	USHORT stsReg1;
	USHORT stsReg2;
	struct GaitEffect dirSts;
	struct SpecialGaitCommand spcSts;
	struct HeadMovingCommand headSts;
	struct GaitEffect odometer;
	struct Sensors sensors;
	USHORT isLeft;
	struct RigidBody_t torsoPose;
};

class CRunningDebug : public CDialog
{
// Construction
public:
	CRunningDebug(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRunningDebug)
	enum { IDD = IDD_DIALOG_RUNNING_DEBUG };
	CEdit	m_editInclinRoll;
	CEdit	m_editInclinPitch;
	CEdit	m_editOdometerTheta;
	CEdit	m_editOdometerY;
	CEdit	m_editOdometerX;
	CEdit	m_editHeadCmdy;
	CEdit	m_editHeadCmdx;
	CEdit	m_editRemainingTimes;
	CEdit	m_editRemainingID;
	CEdit	m_editVthetaFeed;
	CEdit	m_editVyFeed;
	CEdit	m_editVxFeed;
	CSliderCtrl	m_sliderVyCmd;
	CSliderCtrl	m_sliderVxCmd;
	CSliderCtrl	m_sliderVthetaCmd;
	int		m_editVxCmd;
	int		m_editVyCmd;
	int		m_editVthetaCmd;
	UINT	m_editSpecialID;
	UINT	m_editSpecialTimes;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRunningDebug)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRunningDebug)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnCheckStateBit();
	afx_msg void OnButtonClearZero();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnButtonKeyboardInput();
	afx_msg void OnButtonSpecialInput();
	afx_msg void OnButtonStartDebug();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
			
protected:
	struct StateSwapInput input;
	struct StateSwapOutput output;
	bool swapThreadRunning;
	HANDLE swapThreadHandle;
	CRITICAL_SECTION cs;

protected:
	static DWORD SwapThread(LPVOID lpThreadParameter);
	DWORD UpdateInput(struct StateSwapInput *pin);
	DWORD UpdateOuput(struct StateSwapOutput *pout);

public:
	CEdit m_editInclineYaw;
public:
	afx_msg void OnBnClickedRadioHeadNomal();
protected:
	bool specialGaitScheduleRequired;
	bool walkKickScheduleRequired;
public:
	afx_msg void OnBnClickedCheckSensorsEnable3();
public:
	afx_msg void OnBnClickedButtonWalkkickLeft();
public:
	afx_msg void OnBnClickedButtonWalkkickRight();
public:
	CButton m_checkWalkKickPending;
public:
	int m_editVxWalkKick;
public:
	int m_editVyWalkKick;
public:
	int m_editVthetaWalkKick;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RUNNINGDEBUG_H__D15ECEA1_3242_4B9E_9DCF_23B02AD2698E__INCLUDED_)
