#include "afxwin.h"
#if !defined(AFX_DLGSTATESWAP_H__2B0B1457_BAE9_4E22_B1AB_B81F01923262__INCLUDED_)
#define AFX_DLGSTATESWAP_H__2B0B1457_BAE9_4E22_B1AB_B81F01923262__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgStateSwap.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgStateSwap dialog
class GaitSettingsMemory;
struct RealAngle
{
	SHORT incline[3];
	SHORT omega[3];
};

struct RigidOffset
{
	SHORT x;
	SHORT y;
	SHORT z;
};

struct RigidPose
{
	SHORT alpha;
	SHORT beta;
	SHORT theta;
};

struct RigidBody
{
	struct RigidOffset offset;
	struct RigidPose pose;
};

struct FeedbackStatePiece
{
	USHORT isLeft;
	struct RigidBody hip;
	struct RealAngle sensors;
};

class CDlgStateSwap : public CDialog
{
// Construction
public:
	CDlgStateSwap(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgStateSwap)
	enum { IDD = IDD_DIALOG_STATE_SWAP };
	CProgressCtrl	m_ProgressDownload;
	short	m_motionCmdx;
	short	m_motionCmdy;
	short	m_motionCmdtheta;
	CString	m_editGtsPath;
	CString	m_editZeropointFile;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgStateSwap)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgStateSwap)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonSendMotioncmd();
	afx_msg void OnButtonGetGtspath();
	afx_msg void OnButtonGetGaitpath();
	afx_msg void OnRadioUseAny();
	afx_msg void OnButtonDownloadParameter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	BOOL UpdateGaitSettings();
	BOOL UpdateCalibrateSettings();
	static DWORD DownLoad(LPVOID lpThreadParameter);

protected:
	GaitSettingsMemory gaitSettingMemory;
	CalibrateSettingsMemory calibrateSettingMemory;
public:
	afx_msg void OnBnClickedButtonGetCalibratepath();
public:
	CString m_editCalibrateFile;
public:
	afx_msg void OnBnClickedButtonDownloadCalibration();
public:
	afx_msg void OnBnClickedButtonOpenFeedbackfile();
public:
	CEdit m_editFeedbackFile;
public:
	bool enableRecording;
	CStdioFile m_recordFile;
	HANDLE swapThreadHandle;
	CRITICAL_SECTION cs;
	DWORD feedBackStartTime;
public:
	afx_msg void OnBnClickedButtonStopMoving();
public:
	afx_msg void OnBnClickedButtonStartRecordfile();
protected:
	virtual void OnCancel();
	virtual void OnOK();
protected:
	bool CheckTaskComplete();
	static DWORD FeedbackThread(LPVOID lpThreadParameter);
public:
	DWORD UpdateOuput(struct FeedbackStatePiece *ppiece);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSTATESWAP_H__2B0B1457_BAE9_4E22_B1AB_B81F01923262__INCLUDED_)
