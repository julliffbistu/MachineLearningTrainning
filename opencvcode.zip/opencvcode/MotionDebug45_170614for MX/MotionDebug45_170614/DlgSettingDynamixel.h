#if !defined(AFX_DLGSETTINGDYNAMIXEL_H__AB885223_CBA3_4D5B_A812_FBC5CA917B9A__INCLUDED_)
#define AFX_DLGSETTINGDYNAMIXEL_H__AB885223_CBA3_4D5B_A812_FBC5CA917B9A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgSettingDynamixel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSettingDynamixel dialog

class CDlgSettingDynamixel : public CDialog
{
// Construction
public:
	CDlgSettingDynamixel(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgSettingDynamixel)
	enum { IDD = IDD_DIALOG_SETTING_DYNAMIXEL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSettingDynamixel)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSettingDynamixel)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSETTINGDYNAMIXEL_H__AB885223_CBA3_4D5B_A812_FBC5CA917B9A__INCLUDED_)
