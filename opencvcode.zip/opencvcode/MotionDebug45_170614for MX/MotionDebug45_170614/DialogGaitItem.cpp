// DialogGaitItem.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "DialogGaitItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogGaitItem dialog


CDialogGaitItem::CDialogGaitItem(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogGaitItem::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogGaitItem)
	m_targetID = 0;
	m_targetRepeat = 0;
	//}}AFX_DATA_INIT
}


void CDialogGaitItem::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogGaitItem)
	DDX_Text(pDX, IDC_EDIT_TARGET_ID, m_targetID);
	DDX_Text(pDX, IDC_EDIT_TARGET_REPEAT, m_targetRepeat);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogGaitItem, CDialog)
	//{{AFX_MSG_MAP(CDialogGaitItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogGaitItem message handlers

void CDialogGaitItem::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	if(m_targetID==0||m_targetRepeat==0)
	{
		AfxMessageBox(IDS_STRING_INVALID_GAITITEM);
		return;
	}

	CDialog::OnOK();
}
