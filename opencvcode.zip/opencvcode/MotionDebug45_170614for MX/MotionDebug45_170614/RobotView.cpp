#include "stdafx.h"
#include "Resource.h"
#include "RobotView.h"

CRobotView::CRobotView()
{
	int i=0;
	viewName.LoadString(IDS_STRING_DEFAULT_VIEW);
	pJoint=new CPoint[10];
	pJointName=new CString[10];
	pJointID=new unsigned int[10];
	for(i=0;i<10;i++)
	{
		pJoint[i].x=0;
		pJoint[i].y=0;
		pJointName[i].Format("�ؽ�%d",i+1);
		pJointID[i]=i+1;
	}
	jointNumber=10;
	imageID=0;
}

CRobotView::CRobotView(CString &name,UINT image,UINT num)
{
	viewName=name;
	imageID=image;
	jointNumber=num;
	if(num!=0)
	{
		pJoint=new CPoint[num];
		pJointName=new CString[num];
		pJointID=new unsigned int[num];
		for(UINT i=0;i<num;i++)
		{
			pJoint[i].x=0;
			pJoint[i].y=0;
			pJointName[i].Format("�ؽ�%d",i+1);
			pJointID[i]=i+1;
		}
	}
}

CRobotView::~CRobotView()
{
	if(pJoint!=NULL)
		delete []pJoint;
	if(pJointName!=NULL)
		delete []pJointName;
	if(pJointID!=NULL)
		delete []pJointID;
}

CString CRobotView::GetJointName(unsigned int id)
{
	if(id<jointNumber)
		return pJointName[id];
	return CString("NULL");
}

bool CRobotView::LoadView(UINT bitmapID)
{
	unsigned int i=0;
	switch(bitmapID)
	{
	case IDB_BITMAP_MAIN_VIEW:
		imageID=IDB_BITMAP_MAIN_VIEW;
		jointNumber=15;
		viewName.LoadString(IDS_STRING_MAIN_VIEW);
		delete []pJoint;
		delete []pJointName;
		delete []pJointID;
		pJoint=new CPoint[jointNumber];
		pJointName=new CString[jointNumber];
		pJointID=new unsigned int[jointNumber];
		//define joint coordinate in bitmap and name
		pJoint[0].x=20;
		pJoint[0].y=470;
		pJointName[0].LoadString(IDS_STRING_JOINT_ANGLESIDE);
		pJointID[0]=1;
		
		pJoint[1].x=20;
		pJoint[1].y=400;
		pJointName[1].LoadString(IDS_STRING_JOINT_KNEEFORWARD);
		pJointID[1]=3;
		
		pJoint[2].x=20;
		pJoint[2].y=300;
		pJointName[2].LoadString(IDS_STRING_ANGLE_WAISTSIDE);
		pJointID[2]=4;

		pJoint[3].x=20;
		pJoint[3].y=250;
		pJointName[3].LoadString(IDS_STRING_ANGLE_WAISTTURN);
		pJointID[3]=6;

		pJoint[4].x=160;
		pJoint[4].y=250;
		pJointName[4].LoadString(IDS_STRING_ANGLE_WAISTTURN);
		pJointID[4]=7;

		pJoint[5].x=160;
		pJoint[5].y=300;
		pJointName[5].LoadString(IDS_STRING_ANGLE_WAISTSIDE);
		pJointID[5]=9;
		
		pJoint[6].x=160;
		pJoint[6].y=400;
		pJointName[6].LoadString(IDS_STRING_JOINT_KNEEFORWARD);
		pJointID[6]=10;

		pJoint[7].x=160;
		pJoint[7].y=470;
		pJointName[7].LoadString(IDS_STRING_JOINT_ANGLESIDE);
		pJointID[7]=12;

		pJoint[8].x=90;
		pJoint[8].y=200;
		pJointName[8].LoadString(IDS_STRING_WAIST_CENTER);
		pJointID[8]=13;

		pJoint[9].x=5;
		pJoint[9].y=180;
		pJointName[9].LoadString(IDS_STRING_JOINT_BARM);
		pJointID[9]=14;

		pJoint[10].x=5;
		pJoint[10].y=80;
		pJointName[10].LoadString(IDS_STRING_JOINT_TARMSIDE);
		pJointID[10]=15;

		pJoint[11].x=55;
		pJoint[11].y=130;
		pJointName[11].LoadString(IDS_STRING_JOINT_TARM);
		pJointID[11]=16;

		pJoint[12].x=120;
		pJoint[12].y=130;
		pJointName[12].LoadString(IDS_STRING_JOINT_TARM);
		pJointID[12]=17;

		pJoint[13].x=175;
		pJoint[13].y=80;
		pJointName[13].LoadString(IDS_STRING_JOINT_TARMSIDE);
		pJointID[13]=18;

		pJoint[14].x=175;
		pJoint[14].y=180;
		pJointName[14].LoadString(IDS_STRING_JOINT_BARM);
		pJointID[14]=19;
		break;
	case IDB_BITMAP_SIDE_VIEW:
		imageID=IDB_BITMAP_SIDE_VIEW;
		jointNumber=10;
		viewName.LoadString(IDS_STRING_SIDE_VIEW);
		delete []pJoint;
		delete []pJointName;
		delete []pJointID;
		pJoint=new CPoint[jointNumber];
		pJointName=new CString[jointNumber];
		pJointID=new unsigned int[jointNumber];
		for(i=0;i<jointNumber;i++)
		{
			pJoint[i].x=100;
			pJoint[i].y=i*20+20;
			pJointName[i].Format("�ؽ�%d",i+1);
			pJointID[i]=i+1;
		}
		pJoint[0].x=25;
		pJoint[0].y=455;
		pJointName[0].LoadString(IDS_STRING_ANGLE_RIGHTSIDE);
		pJointID[0]=1;

		pJoint[1].x=5;
		pJoint[1].y=480;
		pJointName[1].LoadString(IDS_STRING_ANGLE_LEFTSIDE);
		pJointID[1]=12;

		pJoint[2].x=140;
		pJoint[2].y=455;
		pJointName[2].LoadString(IDS_STRING_ANGLE_RIGHTFORWARD);
		pJointID[2]=2;

		pJoint[3].x=120;
		pJoint[3].y=480;
		pJointName[3].LoadString(IDS_STRING_ANGLE_LEFTFORWARD);
		pJointID[3]=11;

		pJoint[4].x=140;
		pJoint[4].y=380;
		pJointName[4].LoadString(IDS_STRING_ANGLE_RIGHTFORWARD);
		pJointID[4]=3;

		pJoint[5].x=120;
		pJoint[5].y=405;
		pJointName[5].LoadString(IDS_STRING_ANGLE_LEFTFORWARD);
		pJointID[5]=10;

		pJoint[6].x=40;
		pJoint[6].y=290;
		pJointName[6].LoadString(IDS_STRING_ANGLE_RIGHTFORWARD);
		pJointID[6]=4;

		pJoint[7].x=20;
		pJoint[7].y=315;
		pJointName[7].LoadString(IDS_STRING_ANGLE_LEFTFORWARD);
		pJointID[7]=9;

		pJoint[8].x=140;
		pJoint[8].y=290;
		pJointName[8].LoadString(IDS_STRING_ANGLE_RIGHTSIDE);
		pJointID[8]=5;

		pJoint[9].x=120;
		pJoint[9].y=315;
		pJointName[9].LoadString(IDS_STRING_ANGLE_LEFTSIDE);
		pJointID[9]=8;
		break;
	default:
		break;
	}
	return true;
}

CPoint CRobotView::GetAbsolutePoint(unsigned int id,CWnd *src,CWnd *tgt)
{
	if(id<jointNumber)
	{
		CPoint pt(pJoint[id]);
		src->ClientToScreen(&pt);
		tgt->ScreenToClient(&pt);
		return pt;
	}
	return CPoint(0,0);
}

unsigned int CRobotView::GetJointID(unsigned int id)
{
	if(id<jointNumber)
		return pJointID[id];
	return 0;
}

int CRobotView::FindJointID(unsigned int jid)
{
	for(int i=0;i<jointNumber;i++)
	{
		if(jid==pJointID[i])
			return i;
	}
	return -1;
}