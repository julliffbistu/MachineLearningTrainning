// RunningDebug.cpp : implementation file
//

#include "stdafx.h"
#include "stdlib.h"
#include "math.h"
#include "MotionDebug40.h"
#include "DialogGaitItem.h"
#include "DspControl.h"
#include "SingleGait.h"
#include "RobotView.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "RunningDebug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRunningDebug dialog


CRunningDebug::CRunningDebug(CWnd* pParent /*=NULL*/)
: CDialog(CRunningDebug::IDD, pParent)
, m_editVxWalkKick(0)
, m_editVyWalkKick(0)
, m_editVthetaWalkKick(0)
{
	//{{AFX_DATA_INIT(CRunningDebug)
	m_editVxCmd = 0;
	m_editVyCmd = 0;
	m_editVthetaCmd = 0;
	m_editSpecialID = 0;
	m_editSpecialTimes = 0;
	specialGaitScheduleRequired=false;
	walkKickScheduleRequired=false;
	//}}AFX_DATA_INIT
	swapThreadRunning=false;
	InitializeCriticalSection(&cs);
	memset(&input,0,sizeof(input));
	memset(&output,0,sizeof(output));
}


void CRunningDebug::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRunningDebug)
	DDX_Control(pDX, IDC_EDIT_INCLINOMETER_ROLL, m_editInclinRoll);
	DDX_Control(pDX, IDC_EDIT_INCLINOMETER_PITCH, m_editInclinPitch);
	DDX_Control(pDX, IDC_EDIT_ODOMETER_THETA, m_editOdometerTheta);
	DDX_Control(pDX, IDC_EDIT_ODOMETER_Y, m_editOdometerY);
	DDX_Control(pDX, IDC_EDIT_ODOMETER_X, m_editOdometerX);
	DDX_Control(pDX, IDC_EDIT_HEAD_CMDY, m_editHeadCmdy);
	DDX_Control(pDX, IDC_EDIT_HEAD_CMDX, m_editHeadCmdx);
	DDX_Control(pDX, IDC_EDIT_REMAINING_TIMES, m_editRemainingTimes);
	DDX_Control(pDX, IDC_EDIT_REMAINING_ID, m_editRemainingID);
	DDX_Control(pDX, IDC_EDIT_VTHETA_FEEDBACK, m_editVthetaFeed);
	DDX_Control(pDX, IDC_EDIT_VY_FEEDBACK, m_editVyFeed);
	DDX_Control(pDX, IDC_EDIT_VX_FEEDBACK, m_editVxFeed);
	DDX_Control(pDX, IDC_SLIDER_VY_COMMAND, m_sliderVyCmd);
	DDX_Control(pDX, IDC_SLIDER_VX_COMMAND, m_sliderVxCmd);
	DDX_Control(pDX, IDC_SLIDER_VTHETA_COMMAND, m_sliderVthetaCmd);
	DDX_Text(pDX, IDC_EDIT_VX_COMMAND, m_editVxCmd);
	DDV_MinMaxInt(pDX, m_editVxCmd, -100, 100);
	DDX_Text(pDX, IDC_EDIT_VY_COMMAND, m_editVyCmd);
	DDV_MinMaxInt(pDX, m_editVyCmd, -100, 100);
	DDX_Text(pDX, IDC_EDIT_VTHETA_COMMAND, m_editVthetaCmd);
	DDV_MinMaxInt(pDX, m_editVthetaCmd, -270, 270);
	DDX_Text(pDX, IDC_EDIT_SPECIAL_ID, m_editSpecialID);
	DDV_MinMaxUInt(pDX, m_editSpecialID, 0, 255);
	DDX_Text(pDX, IDC_EDIT_SPECIAL_TIMES, m_editSpecialTimes);
	DDV_MinMaxUInt(pDX, m_editSpecialTimes, 0, 128);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_EDIT_INCLINOMETER_YAW, m_editInclineYaw);
	DDX_Control(pDX, IDC_CHECK_WALKKICK_PENDING, m_checkWalkKickPending);
	DDX_Text(pDX, IDC_EDIT_VX_WALKKICK, m_editVxWalkKick);
	DDV_MinMaxInt(pDX, m_editVxWalkKick, -100, 100);
	DDX_Text(pDX, IDC_EDIT_VY_WALKKICK, m_editVyWalkKick);
	DDV_MinMaxInt(pDX, m_editVyWalkKick, -100, 100);
	DDX_Text(pDX, IDC_EDIT_VTHETA_WALKKICK, m_editVthetaWalkKick);
	DDV_MinMaxInt(pDX, m_editVthetaWalkKick, -1000, 1000);
}


BEGIN_MESSAGE_MAP(CRunningDebug, CDialog)
	//{{AFX_MSG_MAP(CRunningDebug)
	ON_BN_CLICKED(IDC_CHECK_GAIT_DIRECTION, OnCheckStateBit)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_ZERO, OnButtonClearZero)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_KEYBOARD_INPUT, OnButtonKeyboardInput)
	ON_BN_CLICKED(IDC_BUTTON_SPECIAL_INPUT, OnButtonSpecialInput)
	ON_BN_CLICKED(IDC_BUTTON_START_DEBUG, OnButtonStartDebug)
	ON_BN_CLICKED(IDC_CHECK_SPECIAL_GAIT, OnCheckStateBit)
	ON_BN_CLICKED(IDC_CHECK_GAIT_RESET, OnCheckStateBit)
	ON_BN_CLICKED(IDC_CHECK_HEAD_MOVE, OnCheckStateBit)
	ON_BN_CLICKED(IDC_CHECK_ODOMETER_CLEAR, OnCheckStateBit)
	ON_BN_CLICKED(IDC_CHECK_TORQUE_ENABLE, OnCheckStateBit)
	ON_BN_CLICKED(IDC_CHECK_SENSORS_ENABLE, OnCheckStateBit)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_WALKKICK_LEFT, OnBnClickedButtonWalkkickLeft)
	ON_BN_CLICKED(IDC_BUTTON_WALKKICK_RIGHT, OnBnClickedButtonWalkkickRight)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRunningDebug message handlers
struct SwapThreadParameter
{
	CMotionDebug40View *parent;
	CRunningDebug *child;
};

BOOL CRunningDebug::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString temp;
	// TODO: Add extra initialization here
	m_sliderVxCmd.SetRange(-100,100);
	m_sliderVxCmd.SetTicFreq(1);
	m_sliderVyCmd.SetRange(-100,100);
	m_sliderVyCmd.SetTicFreq(1);
	m_sliderVthetaCmd.SetRange(-270,270);
	m_sliderVthetaCmd.SetTicFreq(1);

	CheckRadioButton(IDC_RADIO_HEAD_NOMAL,IDC_RADIO_HEAD_SCAN,IDC_RADIO_HEAD_NOMAL);

	m_editVxCmd=0;
	m_editVyCmd=0;
	m_editVthetaCmd=0;
	m_editSpecialID=0;
	m_editSpecialTimes=0;
	UpdateData(FALSE);

	temp.Format("%d",0);
	m_editVthetaFeed.SetWindowText(temp);
	m_editVxFeed.SetWindowText(temp);
	m_editVyFeed.SetWindowText(temp);
	m_editRemainingID.SetWindowText(temp);
	m_editRemainingTimes.SetWindowText(temp);
	m_editOdometerX.SetWindowText(temp);
	m_editOdometerY.SetWindowText(temp);
	m_editOdometerTheta.SetWindowText(temp);
	m_editInclinPitch.SetWindowText(temp);
	m_editInclinRoll.SetWindowText(temp);
	m_editInclineYaw.SetWindowText(temp);

	m_editHeadCmdx.SetWindowText(temp);
	m_editHeadCmdy.SetWindowText(temp);

	m_sliderVxCmd.SetPos(m_editVxCmd);
	m_sliderVyCmd.SetPos(m_editVyCmd);
	m_sliderVthetaCmd.SetPos(m_editVthetaCmd);

	GetDlgItem(IDC_EDIT_VX_COMMAND)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_VY_COMMAND)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_VTHETA_COMMAND)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_CLEAR_ZERO)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_KEYBOARD_INPUT)->EnableWindow(FALSE);
	GetDlgItem(IDC_SLIDER_VX_COMMAND)->EnableWindow(FALSE);
	GetDlgItem(IDC_SLIDER_VY_COMMAND)->EnableWindow(FALSE);
	GetDlgItem(IDC_SLIDER_VTHETA_COMMAND)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_WALKKICK_LEFT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_WALKKICK_RIGHT)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_VX_WALKKICK)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_VY_WALKKICK)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_VTHETA_WALKKICK)->EnableWindow(FALSE);

	GetDlgItem(IDC_EDIT_SPECIAL_ID)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_SPECIAL_TIMES)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_SPECIAL_INPUT)->EnableWindow(FALSE);

	GetDlgItem(IDC_RADIO_HEAD_NOMAL)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_HEAD_SCAN)->EnableWindow(FALSE);

	memset(&input,0,sizeof(input));
	memset(&output,0,sizeof(output));

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

#define PI 3.1415926
DWORD CRunningDebug::UpdateInput(struct StateSwapInput *pin)
{
	int sel;
	CString temp;
	static float pitchPhase=0;
	static float yawPhase=0;

	sel=GetCheckedRadioButton(IDC_RADIO_HEAD_NOMAL,IDC_RADIO_HEAD_SCAN);

	EnterCriticalSection(&cs);
	if(sel==IDC_RADIO_HEAD_NOMAL)
	{
		pitchPhase=0;
		yawPhase=0;
		input.headInst.pitch=(SHORT)(90*PI*512*(1-cos(pitchPhase))/360);
		input.headInst.yaw=(SHORT)(90*PI*512*sin(yawPhase)/180);
	}else
	{
		pitchPhase=pitchPhase+2*PI/20;
		yawPhase=yawPhase+2*PI/80;
		if(pitchPhase>2*PI)
			pitchPhase-=2*PI;
		if(yawPhase>2*PI)
			yawPhase-=2*PI;
		input.headInst.pitch=(SHORT)(90*PI*512*(1-cos(pitchPhase))/360);
		input.headInst.yaw=(SHORT)(90*PI*512*sin(yawPhase)/180);
	}
	memcpy(pin,&input,sizeof(input));
	LeaveCriticalSection(&cs);

	temp.Format("%d",input.headInst.pitch);
	m_editHeadCmdx.SetWindowText(temp);
	temp.Format("%d",input.headInst.yaw);
	m_editHeadCmdy.SetWindowText(temp);

	if(input.ctrReg1&SPECIAL_GAIT_VALID)
	{
		specialGaitScheduleRequired=true;
		output.stsReg2|=SPECIAL_GAIT_PENDING;
		input.ctrReg1&=~SPECIAL_GAIT_VALID;
	}
	if((input.ctrReg1&WALK_KICK_LEFT)||(input.ctrReg1&WALK_KICK_RIGHT))
	{
		walkKickScheduleRequired=true;
		output.stsReg2|=WALK_KICK_PENDING;
		input.ctrReg1&=~WALK_KICK_LEFT;
		input.ctrReg1&=~WALK_KICK_RIGHT;
	}

	if(input.ctrReg1&GAIT_RESET_VALID)
	{
		output.stsReg2|=GAIT_RESET_PENDING;
		input.ctrReg1&=~GAIT_RESET_VALID;
	}

	if(input.ctrReg1&COPY_RESET_ODOMETER)
	{
		output.stsReg2|=RESET_ODOMETER_PENDING;
		input.ctrReg1&=~COPY_RESET_ODOMETER;
	}
	return 0;
}

DWORD CRunningDebug::UpdateOuput(struct StateSwapOutput *pout)
{
	CString temp;
	EnterCriticalSection(&cs);
	memcpy(&output,pout,sizeof(output));
	LeaveCriticalSection(&cs);

	temp.Format("%d",output.dirSts.xOffset);
	m_editVxFeed.SetWindowText(temp);
	temp.Format("%d",output.dirSts.yOffset);
	m_editVyFeed.SetWindowText(temp);
	temp.Format("%d",output.dirSts.thetaOffset);
	m_editVthetaFeed.SetWindowText(temp);

	/*
	if(specialGaitScheduleRequired)
	{
	USHORT temp=0;
	specialGaitScheduleRequired=false;
	temp=output.stsReg1&SPECIAL_GAIT_VALID;
	input.ctrReg1&=~SPECIAL_GAIT_VALID;
	input.ctrReg1|=temp;
	}

	if(walkKickScheduleRequired)
	{
	USHORT temp=0;
	walkKickScheduleRequired=false;
	temp=(output.stsReg1&(WALK_KICK_LEFT|WALK_KICK_RIGHT));
	input.ctrReg1&=~(WALK_KICK_LEFT|WALK_KICK_RIGHT);
	input.ctrReg1|=temp;
	if(temp==0)
	{
	m_checkWalkKickPending.SetCheck(0);
	}
	}*/
	if(!(output.stsReg2&WALK_KICK_PENDING))
		m_checkWalkKickPending.SetCheck(0);

	if(!(output.stsReg2&GAIT_RESET_PENDING))
	{
		CButton *pbutton;
		pbutton=(CButton *)GetDlgItem(IDC_CHECK_GAIT_RESET);
		pbutton->SetCheck(0);
	}

	if(!(output.stsReg2&RESET_ODOMETER_PENDING))
	{
		CButton *pbutton;
		pbutton=(CButton *)GetDlgItem(IDC_CHECK_ODOMETER_CLEAR);
		pbutton->SetCheck(0);
	}


	temp.Format("%d",output.spcSts.id);
	m_editRemainingID.SetWindowText(temp);
	temp.Format("%d",output.spcSts.times);
	m_editRemainingTimes.SetWindowText(temp);

	if((input.ctrReg1&COPY_RESET_ODOMETER)&&
		output.odometer.xOffset==0&&
		output.odometer.yOffset==0&&
		output.odometer.thetaOffset==0
		)
	{
		;
	}else
	{
		temp.Format("%d",output.odometer.xOffset);
		m_editOdometerX.SetWindowText(temp);
		temp.Format("%d",output.odometer.yOffset);
		m_editOdometerY.SetWindowText(temp);
		temp.Format("%d",output.odometer.thetaOffset);
		m_editOdometerTheta.SetWindowText(temp);
	}

	temp.Format("%f",((float)output.sensors.incline[0])/512.0f/PI*180.0f);
	m_editInclinRoll.SetWindowText(temp);
	temp.Format("%f",((float)output.sensors.incline[1])/512.0f/PI*180.0f);
	m_editInclinPitch.SetWindowText(temp);
	temp.Format("%f",((float)output.sensors.incline[2])/512.0f/PI*180.0f);
	m_editInclineYaw.SetWindowText(temp);

	return 0;
}

DWORD CRunningDebug::SwapThread(LPVOID lpThreadParameter)
{
	int runningCntr=0;
	PacketTransformer packet;
	struct StateSwapInput in;
	struct StateSwapOutput out;
	PUSHORT pdata=NULL;
	int i=0;
	struct SwapThreadParameter *para=(struct SwapThreadParameter *)lpThreadParameter;
	CRunningDebug *dlg=para->child;
	CMotionDebug40View *view=para->parent;
	delete para;

	while(dlg->swapThreadRunning&&runningCntr<30)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_STATE_SWAP;
		packet.dspInst->length=sizeof(struct StateSwapInput)+2;
		dlg->UpdateInput(&in);
		pdata=(PUSHORT)&in;
		for(i=0;i<sizeof(struct StateSwapInput)/sizeof(USHORT);i++)
		{
			packet.dspInst->parameter[2*i]=pdata[i]&0xff;
			packet.dspInst->parameter[2*i+1]=(pdata[i]>>8)&0xff;
		}
		packet.ConstructPacket();

		if(
			!view->SendAndRecv(packet,1,300)||
			!packet.DestructPacket()
			)
		{
			runningCntr++;
			Sleep(1000);
			continue;
		}else
			runningCntr=0;

		pdata=(PUSHORT)&out;
		for(i=0;i<sizeof(struct StateSwapOutput)/sizeof(USHORT);i++)
			pdata[i]=packet.dspInst->parameter[2*i]+(packet.dspInst->parameter[2*i+1]<<8);
		if(out.spcSts.id>255)
			out.spcSts.id=0;
		dlg->UpdateOuput(&out);

		//Sleep(200);
	}
	if(runningCntr>=30)
		AfxMessageBox(IDS_STRING_STATE_SWAP_INTERRPUTED);
	return 0;
}

void CRunningDebug::OnOK() 
{
	// TODO: Add extra validation here
	if(swapThreadRunning)
	{
		AfxMessageBox(IDS_STRING_UNABLE_QUIT_DEBUG);
		return;
	}

	CDialog::OnOK();
}

void CRunningDebug::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(swapThreadRunning)
	{
		AfxMessageBox(IDS_STRING_UNABLE_QUIT_DEBUG);
		return;
	}

	CDialog::OnCancel();
}

void CRunningDebug::OnCheckStateBit() 
{
	// TODO: Add your control notification handler code here
	int flag=0;
	EnterCriticalSection(&cs);
	CButton *pbutton=(CButton *)GetDlgItem(IDC_CHECK_GAIT_DIRECTION);
	if((flag=pbutton->GetCheck())==1)
		input.ctrReg1|=GAIT_DIRECTION_VALID;
	else
		input.ctrReg1&=~GAIT_DIRECTION_VALID;

	GetDlgItem(IDC_EDIT_VX_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_VY_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_VTHETA_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_BUTTON_CLEAR_ZERO)->EnableWindow(flag);
	GetDlgItem(IDC_BUTTON_KEYBOARD_INPUT)->EnableWindow(flag);
	GetDlgItem(IDC_SLIDER_VX_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_SLIDER_VY_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_SLIDER_VTHETA_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_SLIDER_VTHETA_COMMAND)->EnableWindow(flag);
	GetDlgItem(IDC_BUTTON_WALKKICK_LEFT)->EnableWindow(flag);
	GetDlgItem(IDC_BUTTON_WALKKICK_RIGHT)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_VX_WALKKICK)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_VY_WALKKICK)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_VTHETA_WALKKICK)->EnableWindow(flag);

	pbutton=(CButton *)GetDlgItem(IDC_CHECK_SPECIAL_GAIT);
	/*
	if((flag=pbutton->GetCheck())==1)
	input.ctrReg1|=SPECIAL_GAIT_VALID;
	else
	input.ctrReg1&=~SPECIAL_GAIT_VALID;
	*/
	flag=pbutton->GetCheck();
	GetDlgItem(IDC_EDIT_SPECIAL_ID)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_SPECIAL_TIMES)->EnableWindow(flag);
	GetDlgItem(IDC_BUTTON_SPECIAL_INPUT)->EnableWindow(flag);

	pbutton=(CButton *)GetDlgItem(IDC_CHECK_GAIT_RESET);
	if(pbutton->GetCheck())
		input.ctrReg1|=GAIT_RESET_VALID;
	else
		input.ctrReg1&=~GAIT_RESET_VALID;

	pbutton=(CButton *)GetDlgItem(IDC_CHECK_HEAD_MOVE);
	if((flag=pbutton->GetCheck())==1)
		input.ctrReg1|=HEAD_MOVE_VALID;
	else
		input.ctrReg1&=~HEAD_MOVE_VALID;
	GetDlgItem(IDC_RADIO_HEAD_NOMAL)->EnableWindow(flag);
	GetDlgItem(IDC_RADIO_HEAD_SCAN)->EnableWindow(flag);

	pbutton=(CButton *)GetDlgItem(IDC_CHECK_ODOMETER_CLEAR);
	if(pbutton->GetCheck())
		input.ctrReg1|=COPY_RESET_ODOMETER;
	else
		input.ctrReg1&=~COPY_RESET_ODOMETER;

	pbutton=(CButton *)GetDlgItem(IDC_CHECK_TORQUE_ENABLE);
	if(pbutton->GetCheck())
		input.ctrReg1|=TORQUE_ENABLE_VALID;
	else
		input.ctrReg1&=~TORQUE_ENABLE_VALID;

	pbutton=(CButton *)GetDlgItem(IDC_CHECK_SENSORS_ENABLE);
	if(pbutton->GetCheck())
		input.ctrReg1|=SENSOR_ENABLE_VALID;
	else
		input.ctrReg1&=~SENSOR_ENABLE_VALID;
	LeaveCriticalSection(&cs);
}

/*
void CRunningDebug::OnCheckStateBit() 
{
// TODO: Add your control notification handler code here
int flag=0;
EnterCriticalSection(&cs);
CButton *pbutton=(CButton *)GetDlgItem(IDC_CHECK_GAIT_DIRECTION);
if((flag=pbutton->GetCheck())==1)
input.ctrReg1|=GAIT_DIRECTION_VALID;
else
input.ctrReg1&=~GAIT_DIRECTION_VALID;

GetDlgItem(IDC_EDIT_VX_COMMAND)->EnableWindow(flag);
GetDlgItem(IDC_EDIT_VY_COMMAND)->EnableWindow(flag);
GetDlgItem(IDC_EDIT_VTHETA_COMMAND)->EnableWindow(flag);
GetDlgItem(IDC_BUTTON_CLEAR_ZERO)->EnableWindow(flag);
GetDlgItem(IDC_BUTTON_KEYBOARD_INPUT)->EnableWindow(flag);
GetDlgItem(IDC_SLIDER_VX_COMMAND)->EnableWindow(flag);
GetDlgItem(IDC_SLIDER_VY_COMMAND)->EnableWindow(flag);
GetDlgItem(IDC_SLIDER_VTHETA_COMMAND)->EnableWindow(flag);


pbutton=(CButton *)GetDlgItem(IDC_CHECK_SPECIAL_GAIT);
if((flag=pbutton->GetCheck())==1)
input.ctrReg1|=SPECIAL_GAIT_VALID;
else
input.ctrReg1&=~SPECIAL_GAIT_VALID;

GetDlgItem(IDC_EDIT_SPECIAL_ID)->EnableWindow(flag);
GetDlgItem(IDC_EDIT_SPECIAL_TIMES)->EnableWindow(flag);
GetDlgItem(IDC_BUTTON_SPECIAL_INPUT)->EnableWindow(flag);

pbutton=(CButton *)GetDlgItem(IDC_CHECK_GAIT_RESET);
if(pbutton->GetCheck())
input.ctrReg1|=GAIT_RESET_VALID;
else
input.ctrReg1&=~GAIT_RESET_VALID;

pbutton=(CButton *)GetDlgItem(IDC_CHECK_HEAD_MOVE);
if((flag=pbutton->GetCheck())==1)
input.ctrReg1|=HEAD_MOVE_VALID;
else
input.ctrReg1&=~HEAD_MOVE_VALID;
GetDlgItem(IDC_RADIO_HEAD_NOMAL)->EnableWindow(flag);
GetDlgItem(IDC_RADIO_HEAD_SCAN)->EnableWindow(flag);

pbutton=(CButton *)GetDlgItem(IDC_CHECK_ODOMETER_CLEAR);
if(pbutton->GetCheck())
input.ctrReg1|=COPY_RESET_ODOMETER;
else
input.ctrReg1&=~COPY_RESET_ODOMETER;

pbutton=(CButton *)GetDlgItem(IDC_CHECK_TORQUE_ENABLE);
if(pbutton->GetCheck())
input.ctrReg1|=TORQUE_ENABLE_VALID;
else
input.ctrReg1&=~TORQUE_ENABLE_VALID;

pbutton=(CButton *)GetDlgItem(IDC_CHECK_SENSORS_ENABLE);
if(pbutton->GetCheck())
input.ctrReg1|=SENSOR_ENABLE_VALID;
else
input.ctrReg1&=~SENSOR_ENABLE_VALID;
LeaveCriticalSection(&cs);
}
*/


void CRunningDebug::OnButtonClearZero() 
{
	// TODO: Add your control notification handler code here
	m_editVxCmd=0;
	m_editVyCmd=0;
	m_editVthetaCmd=0;
	UpdateData(FALSE);

	m_sliderVxCmd.SetPos(m_editVxCmd);
	m_sliderVyCmd.SetPos(m_editVyCmd);
	m_sliderVthetaCmd.SetPos(m_editVthetaCmd);

	EnterCriticalSection(&cs);
	input.ctrReg1|=GAIT_DIRECTION_VALID;
	input.dirInst.xOffset=m_editVxCmd;
	input.dirInst.yOffset=m_editVyCmd;
	input.dirInst.thetaOffset=m_editVthetaCmd;
	LeaveCriticalSection(&cs);
}

void CRunningDebug::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	m_editVxCmd=m_sliderVxCmd.GetPos();
	m_editVyCmd=m_sliderVyCmd.GetPos();
	m_editVthetaCmd=m_sliderVthetaCmd.GetPos();
	UpdateData(FALSE);

	EnterCriticalSection(&cs);
	input.ctrReg1|=GAIT_DIRECTION_VALID;
	input.dirInst.xOffset=m_editVxCmd;
	input.dirInst.yOffset=m_editVyCmd;
	input.dirInst.thetaOffset=m_editVthetaCmd;
	LeaveCriticalSection(&cs);

	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CRunningDebug::OnButtonKeyboardInput() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	m_sliderVxCmd.SetPos(m_editVxCmd);
	m_sliderVyCmd.SetPos(m_editVyCmd);
	m_sliderVthetaCmd.SetPos(m_editVthetaCmd);

	EnterCriticalSection(&cs);
	input.ctrReg1|=GAIT_DIRECTION_VALID;
	input.dirInst.xOffset=m_editVxCmd;
	input.dirInst.yOffset=m_editVyCmd;
	input.dirInst.thetaOffset=m_editVthetaCmd;
	LeaveCriticalSection(&cs);
}

void CRunningDebug::OnButtonSpecialInput() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	EnterCriticalSection(&cs);
	input.spcInst.id=m_editSpecialID;
	input.spcInst.times=m_editSpecialTimes;
	input.ctrReg1|=SPECIAL_GAIT_VALID;
	LeaveCriticalSection(&cs);
}

void CRunningDebug::OnButtonStartDebug() 
{
	// TODO: Add your control notification handler code here
	DWORD nThreadId1;
	CString temp;
	CString temp2;
	GetDlgItem(IDC_BUTTON_START_DEBUG)->GetWindowText(temp);
	temp2.LoadString(IDS_STRING_START_DEBUG);
	if(temp==temp2)
	{
		CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
		struct SwapThreadParameter *para=NULL;
		para=new struct SwapThreadParameter;
		para->parent=view;
		para->child=this;
		swapThreadRunning=true;

		swapThreadHandle=::CreateThread(
			(LPSECURITY_ATTRIBUTES)NULL,
			0,
			(LPTHREAD_START_ROUTINE)(SwapThread),
			para,
			0,
			&nThreadId1
			);
		temp.LoadString(IDS_STRING_STOP_DEBUG);
		GetDlgItem(IDC_BUTTON_START_DEBUG)->SetWindowText(temp);
	}else
	{
		swapThreadRunning=false;
		//WaitForSingleObject(swapThreadHandle,INFINITE);
		temp.LoadString(IDS_STRING_START_DEBUG);
		GetDlgItem(IDC_BUTTON_START_DEBUG)->SetWindowText(temp);
	}
}

void CRunningDebug::OnBnClickedCheckSensorsEnable3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CRunningDebug::OnBnClickedButtonWalkkickLeft()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);

	EnterCriticalSection(&cs);
	input.dirInst.xOffset=m_editVxWalkKick;
	input.dirInst.yOffset=m_editVyWalkKick;
	input.dirInst.thetaOffset=m_editVthetaWalkKick;
	input.ctrReg1|=WALK_KICK_LEFT;
	input.ctrReg1&=~WALK_KICK_RIGHT;
	input.ctrReg1&=~GAIT_DIRECTION_VALID;
	m_checkWalkKickPending.SetCheck(1);
	LeaveCriticalSection(&cs);
}

void CRunningDebug::OnBnClickedButtonWalkkickRight()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);

	EnterCriticalSection(&cs);
	input.dirInst.xOffset=m_editVxWalkKick;
	input.dirInst.yOffset=m_editVyWalkKick;
	input.dirInst.thetaOffset=m_editVthetaWalkKick;
	input.ctrReg1|=WALK_KICK_RIGHT;
	input.ctrReg1&=~WALK_KICK_LEFT;
	input.ctrReg1&=~GAIT_DIRECTION_VALID;
	m_checkWalkKickPending.SetCheck(1);
	LeaveCriticalSection(&cs);
}
