#include "stdafx.h"
#include "DspControl.h"
#include "PacketTransformer.h"

PacketTransformer::PacketTransformer()
{
	dspInst=(DSP_INST_PACKET *)buffer;
	length=0;
}

PacketTransformer::PacketTransformer(PBYTE buf,int len)
{
	dspInst=(DSP_INST_PACKET *)buffer;
	memcpy(PBYTE(&buffer),buf,length);
	length=len;
}

void PacketTransformer::SetRawPacket(PBYTE buf,int len)
{
	result.RemoveAll();
	memcpy(PBYTE(&buffer),buf,length);
	length=len;
}

void PacketTransformer::SetRawPacket(CByteArray &recv)
{
	result.RemoveAll();
	result.Copy(recv);
}

CByteArray& PacketTransformer::GetByteArray()
{
	return result;
}

bool PacketTransformer::ConstructPacket()
{
	int i=0;

	result.RemoveAll();
	result.SetSize(dspInst->length+4);
	result.SetAt(0,0xff);
	result.SetAt(1,0xff);
	for(i=0;i<dspInst->length+1;i++)
		result.SetAt(i+2, buffer[i]);
	result.SetAt(i+2,CheckSum());
	return true;

}

bool PacketTransformer::DestructPacket()
{
	PBYTE pbuf=NULL;
	if(result.GetSize()<6)
		return false;
	pbuf=result.GetData();
	if(
		0xff!=pbuf[0]||
		0xff!=pbuf[1]
		)
		return false;
	memcpy(buffer,pbuf+2,result.GetSize()-3);
	if(
		dspInst->id!=ID_DSP||
		dspInst->length!=result.GetSize()-4||
		pbuf[result.GetSize()-1]!=CheckSum()
		)
		return false;
	return true;
}

bool PacketTransformer::TryDestructOnePacket()
{
	PBYTE pbuf=NULL;
	DSP_INST_PACKET *ppacket=NULL;
	
	while(result.GetSize()>=6)
	{
		pbuf=result.GetData();
		if(pbuf[0]!=0xff)
		{
			result.RemoveAt(0,1);
			continue;
		}
		if(pbuf[1]!=0xff)
		{
			result.RemoveAt(0,2);
			continue;
		}
		ppacket=(DSP_INST_PACKET *)(pbuf+2);
		if(ppacket->id!=ID_DSP)
		{
			result.RemoveAt(0,3);
			continue;
		}
		if(result.GetSize()<ppacket->length+4)
			return false;
		memcpy(buffer,ppacket,ppacket->length+2);
		result.RemoveAt(0,dspInst->length+4);
		if(buffer[ppacket->length+1]!=CheckSum())
			continue;
		return true;
	}
	return false;
}

BYTE PacketTransformer::CheckSum()
{
	BYTE checkSum=0;
	for(int i=0;i<dspInst->length+1;i++)
		checkSum+=buffer[i];
	checkSum=~checkSum;
	return checkSum;
}

void PacketTransformer::Reset()
{
	result.RemoveAll();
	result.SetSize(0);
}

void PacketTransformer::AppandArray(CByteArray &recv)
{
	result.Append(recv);
}