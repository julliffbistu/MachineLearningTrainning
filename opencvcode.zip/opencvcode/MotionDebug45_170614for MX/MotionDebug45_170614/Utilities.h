#ifndef UTILITY_H
#define UTILITY_H

#define INTEGER(x)	((x)/10)
#define DECIMAL(x)	((x)%10)
#define FtoI(in) (in<0?((int)((in)-0.5)):((int)((in)+0.5)))
//#define FtoI(in) ((int)((in)+0.5))

#endif