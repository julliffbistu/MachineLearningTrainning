// MotionDebug40View.h : interface of the CMotionDebug40View class
//
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()
#include "mscomm.h"
#include "msflexgrid.h"
//}}AFX_INCLUDES

#if !defined(AFX_MOTIONDEBUG40VIEW_H__4ADB1F74_1AC9_4092_9834_C6466B470BCD__INCLUDED_)
#define AFX_MOTIONDEBUG40VIEW_H__4ADB1F74_1AC9_4092_9834_C6466B470BCD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define USER_CONTROL_RESOUCE_BASE	10000
#define USER_EDIT_GRID_ID			(USER_CONTROL_RESOUCE_BASE+1)
#define USER_CBUTTON_JOINT_BASE		(USER_CONTROL_RESOUCE_BASE+100)

class CMotionDebug40View : public CFormView
{
protected: // create from serialization only
	CMotionDebug40View();
	DECLARE_DYNCREATE(CMotionDebug40View)

public:
	//{{AFX_DATA(CMotionDebug40View)
	enum { IDD = IDD_MOTIONDEBUG40_FORM };
	CSliderCtrl	m_sliderTuningAngle;
	CEdit	m_editStaticTuning;
	CStatic	m_staticRobotImage;
	CComboBox	m_comboSelectView;
	CComboBox	m_comboComBaudrate;
	CComboBox	m_comboComPort;
	CMSComm	m_Comm;
	CMSFlexGrid	m_MotionList;
	CString	m_editJointID;
	//}}AFX_DATA

// Attributes
public:
	CMotionDebug40Doc* GetDocument();

// Operations
public:
	int GetCalabrateInfo(unsigned int &num,int **list);
	int SetCalabrateInfo(unsigned int num,int *list);
	CSingleGait *GetGaitInfo();
	void SetNoDefault();
	bool SendAndRecv(PacketTransformer &rpacket,int times,int msec);
	bool SendUntilWait(PacketTransformer &rpacket,unsigned char inst,int timeout);
	bool TryRecvPacket(PacketTransformer &rpacket);
	bool SendSinglePacket(PacketTransformer &rpacket);
	UINT StrToServo(const char * str,unsigned int joint=0);
	float ServoTof(UINT ser,unsigned int joint=0);
	bool ConstructFrameData(PBYTE buffer, unsigned int frame);
	DWORD GetGaitPeriod();

protected:
	bool binitializeOnce;
	bool binitializeDefault;
	CString clip;
	CEdit *m_pEdit;
	CRobotView robotView;
	CButton *pJoint;
	unsigned int nGaitPointer;
	int stepDirection;
	bool actionEnable;

private:
	bool interLock;

protected:
	CWirelessConnection wirelessConnect;
	BOOL isUsingCom;
	DWORD ipAddress;
	DWORD port;

public:
	BOOL GetPortOpen(void);
	void SetPortOpen(BOOL bNewValue);
	void OpenPortWithSettings(void);
	void EnablePortSetting(BOOL bNewValue);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMotionDebug40View)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMotionDebug40View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void CheckCOM();
	void InitCOMBaudrate();
	void InitSerialPort();
	void UpdateMotionListOrder();
	void ResetMotionListRow(long row);
	BOOL UpdateImageDisplay();
	void UpdateButtons(UINT newImage);

	int GetCommData(CByteArray& byteArray);
	bool SetGaitPointer(unsigned int pos);
	static DWORD StepThread(LPVOID lpThreadParameter);
	void EnableMachineOperation(bool enable=true);
	void SetUninterruptOn(bool enable=true);
	bool RegisterActiveX(bool isRegistered);
	bool RegisterActiveX2(bool isRegistered);

protected:
	afx_msg void OnEditGridID();
	afx_msg void OnCbuttonJoint(UINT uID);

// Generated message map functions
protected:
	//{{AFX_MSG(CMotionDebug40View)
	afx_msg void OnButtonConnectEstablish();
	afx_msg void OnToolsCalibrate();
	afx_msg void OnToolsDownload();
	afx_msg void OnToolsRunList();
	afx_msg void OnEditInsertTop();
	afx_msg void OnEditInsertBottom();
	afx_msg void OnEditDeleteCurrent();
	afx_msg void OnEditCut();
	afx_msg void OnEditPasteTop();
	afx_msg void OnEditPasteBottom();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnClickMsflexgrid();
	afx_msg void OnLeaveCellMsflexgrid();
	afx_msg void OnScrollMsflexgrid();
	afx_msg void OnCloseupComboSelectView();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnChangeEditStaticTunning();
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnButtonWakeUp();
	afx_msg void OnButtonReset();
	afx_msg void OnButtonForwardStep();
	afx_msg void OnButtonBackStep();
	afx_msg void OnButtonForward();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonBackward();
	afx_msg void OnToolsStateCmdSwap();
	afx_msg void OnToolsRunningDebug();
	afx_msg void OnToolsNetworkDebug();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MotionDebug40View.cpp
inline CMotionDebug40Doc* CMotionDebug40View::GetDocument()
   { return (CMotionDebug40Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MOTIONDEBUG40VIEW_H__4ADB1F74_1AC9_4092_9834_C6466B470BCD__INCLUDED_)
