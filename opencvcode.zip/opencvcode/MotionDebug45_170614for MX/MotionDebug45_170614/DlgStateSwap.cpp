// DlgStateSwap.cpp : implementation file
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "RobotView.h"
#include "DspControl.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "DialogDownload.h"
#include "SingleGait.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "GaitSettingsMemory.h"
#include "CalibrateSettingsMemory.h"
#include "DlgStateSwap.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgStateSwap dialog

struct StateSwapThreadParameter
{
	CMotionDebug40View *parent;
	CDlgStateSwap *child;
};

CDlgStateSwap::CDlgStateSwap(CWnd* pParent /*=NULL*/)
: CDialog(CDlgStateSwap::IDD, pParent)
, m_editCalibrateFile(_T(""))
{
	//{{AFX_DATA_INIT(CDlgStateSwap)
	m_motionCmdx = 0;
	m_motionCmdy = 0;
	m_motionCmdtheta = 0;
	m_editGtsPath = _T("");
	m_editZeropointFile = _T("");
	//}}AFX_DATA_INIT
	InitializeCriticalSection(&cs);
}


void CDlgStateSwap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgStateSwap)
	DDX_Control(pDX, IDC_PROGRESS_DOWNLOAD_CONFIG, m_ProgressDownload);
	DDX_Text(pDX, IDC_EDIT_MOTIONCMD_X, m_motionCmdx);
	DDX_Text(pDX, IDC_EDIT_MOTIONCMD_Y, m_motionCmdy);
	DDX_Text(pDX, IDC_EDIT_MOTIONCMD_THETA, m_motionCmdtheta);
	DDX_Text(pDX, IDC_EDIT_GTS_PATH, m_editGtsPath);
	DDX_Text(pDX, IDC_EDIT_ZEROPOINT_FILE, m_editZeropointFile);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_EDIT_CALIBRATE_FILE, m_editCalibrateFile);
	DDX_Control(pDX, IDC_EDIT_FEEDBACK_FILE, m_editFeedbackFile);
}


BEGIN_MESSAGE_MAP(CDlgStateSwap, CDialog)
	//{{AFX_MSG_MAP(CDlgStateSwap)
	ON_BN_CLICKED(IDC_BUTTON_SEND_MOTIONCMD, OnButtonSendMotioncmd)
	ON_BN_CLICKED(IDC_BUTTON_GET_GTSPATH, OnButtonGetGtspath)
	ON_BN_CLICKED(IDC_BUTTON_GET_GAITPATH, OnButtonGetGaitpath)
	ON_BN_CLICKED(IDC_RADIO_USE_GAIT, OnRadioUseAny)
	ON_BN_CLICKED(IDC_RADIO_USE_GTS, OnRadioUseAny)
	ON_BN_CLICKED(IDC_RADIO_USE_CURRENT, OnRadioUseAny)
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD_PARAMETER, OnButtonDownloadParameter)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_GET_CALIBRATEPATH, OnBnClickedButtonGetCalibratepath)
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD_CALIBRATION, OnBnClickedButtonDownloadCalibration)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_FEEDBACKFILE, OnBnClickedButtonOpenFeedbackfile)
	ON_BN_CLICKED(IDC_BUTTON_STOP_MOVING, OnBnClickedButtonStopMoving)
	ON_BN_CLICKED(IDC_BUTTON_START_RECORDFILE, OnBnClickedButtonStartRecordfile)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgStateSwap message handlers

BOOL CDlgStateSwap::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	m_motionCmdx=0;
	m_motionCmdy=0;
	m_motionCmdtheta=0;
	CheckRadioButton(IDC_RADIO_USE_GAIT,IDC_RADIO_USE_CURRENT,IDC_RADIO_USE_GAIT);
	UpdateData(TRUE);
	enableRecording=false;
	feedBackStartTime=0;
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgStateSwap::OnButtonSendMotioncmd() 
{
	// TODO: Add your control notification handler code here
	PacketTransformer packet;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());

	UpdateData();
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_GAIT_DIRECTION_EXT;
	packet.dspInst->length=8;
	packet.dspInst->parameter[0]=m_motionCmdx&0xff;
	packet.dspInst->parameter[1]=(m_motionCmdx>>8)&0xff;
	packet.dspInst->parameter[2]=m_motionCmdy&0xff;
	packet.dspInst->parameter[3]=(m_motionCmdy>>8)&0xff;
	packet.dspInst->parameter[4]=m_motionCmdtheta&0xff;
	packet.dspInst->parameter[5]=(m_motionCmdtheta>>8)&0xff;

	packet.ConstructPacket();

	EnterCriticalSection(&cs);
	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		LeaveCriticalSection(&cs);
		AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
	}else
		LeaveCriticalSection(&cs);
}

void CDlgStateSwap::OnButtonGetGtspath() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString tempFileName;
	CFileDialog dlg(TRUE, NULL, NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"GTS Files(*.gts)|*.gts||"); 

	if ( dlg.DoModal()!=IDOK ) 
		return;

	tempFileName=dlg.GetPathName();
	m_editGtsPath = tempFileName;
	UpdateData(FALSE);
	if(!UpdateGaitSettings())
		AfxMessageBox(IDS_STRING_GAIT_SETTINGS_ILLIGAL);
}

void CDlgStateSwap::OnButtonGetGaitpath() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString tempFileName;
	CFileDialog dlg(TRUE, NULL, NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"txt Files(*.txt)|*.txt||"); 

	if ( dlg.DoModal()!=IDOK ) 
		return;

	tempFileName=dlg.GetPathName();
	m_editZeropointFile = tempFileName;
	UpdateData(FALSE);	
}

BOOL CDlgStateSwap::UpdateCalibrateSettings()
{
	CStdioFile file;
	CalibrateSettingsMemory tempMem;

	//open file
	if(!file.Open(m_editCalibrateFile, CFile::modeRead))
	{
		AfxMessageBox(IDS_STRING_UNABLE_OPENFILE);
		return FALSE;
	}

	if(!tempMem.LoadFromFile(file))
		return FALSE;

	calibrateSettingMemory=tempMem;

	file.Close();
	return TRUE;
}

BOOL CDlgStateSwap::UpdateGaitSettings()
{
	CStdioFile file;
	GaitSettingsMemory tempMem;

	//open file
	if(!file.Open(m_editGtsPath, CFile::modeRead))
	{
		AfxMessageBox(IDS_STRING_UNABLE_OPENFILE);
		return FALSE;
	}

	if(!tempMem.LoadFromFile(file))
		return FALSE;

	gaitSettingMemory=tempMem;

	file.Close();
	return TRUE;
}


void CDlgStateSwap::OnRadioUseAny() 
{
	// TODO: Add your control notification handler code here
	int sel;
	sel=GetCheckedRadioButton(IDC_RADIO_USE_GAIT,IDC_RADIO_USE_CURRENT);
	if(sel==IDC_RADIO_USE_GAIT)
		GetDlgItem(IDC_BUTTON_GET_GAITPATH)->EnableWindow(TRUE);
	else
		GetDlgItem(IDC_BUTTON_GET_GAITPATH)->EnableWindow(FALSE);
}

struct DownloadConfig
{
	CMotionDebug40View *parent;
	CDlgStateSwap *child;
};

void CDlgStateSwap::OnButtonDownloadParameter() 
{
	// TODO: Add your control notification handler code here
	DWORD nThreadId1;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());

	if(m_editGtsPath.IsEmpty())
	{
		AfxMessageBox(IDS_STRING_GAIT_SETTINGS_ILLIGAL);
		return;
	}
	struct DownloadConfig *para=NULL;
	para=new struct DownloadConfig;
	para->parent=view;
	para->child=this;

	::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(DownLoad),
		para,
		0,
		&nThreadId1
		);
	return;
}

DWORD CDlgStateSwap::DownLoad(LPVOID lpThreadParameter)
{
	struct DownloadConfig *para=(struct DownloadConfig *)lpThreadParameter;
	CDlgStateSwap *dlg=para->child;
	CMotionDebug40View *view=para->parent;
	delete para;

	int progess=0;
	PacketTransformer packet;
	int i=0;
	int sel;
	int joint_number=0;
	int *pmechanical_zero_point=NULL;
	int *probot=NULL;
	int robot_parameter_len=0;
	int rythm_step;
	int rythm_frame;

	dlg->gaitSettingMemory.GetFrameData(NULL,NULL,&rythm_frame);
	dlg->m_ProgressDownload.SetRange(0,rythm_frame+3);
	//first we set progess and download zero point list
	sel=dlg->GetCheckedRadioButton(IDC_RADIO_USE_GAIT,IDC_RADIO_USE_CURRENT);
	switch(sel)
	{
	case IDC_RADIO_USE_GAIT:
		{
			CStdioFile file;
			if(dlg->m_editZeropointFile.IsEmpty())
			{
				AfxMessageBox(IDS_STRING_ZEROPOINT_UNSPECIFIED);
				goto failed_exit;
			}
			if(!file.Open(dlg->m_editZeropointFile, CFile::modeRead))
			{
				AfxMessageBox(IDS_STRING_UNABLE_OPENFILE);
				goto failed_exit;
			}
			// we read mechanical zero point from a gait file
			// length is stored in joint_number
			// and data is stored in pmechanical_zero_point
			CString temp;
			CHAR var[64];
			while(file.ReadString(temp))
			{
				sscanf(temp,"%63[^=^ ]",var);
				if(0==strcmp(var,"joint_number"))
				{
					sscanf(temp,"%*[^=]%*[^0-9]%d[^\r^\n]",&joint_number);
				}else if(0==strcmp(var,"mechanical_zero_point"))
				{
					char *pstr=NULL;
					int *pList=NULL;
					float fdata=0;
					int cntr=0;
					int start=0;

					if(joint_number==0)
					{
						AfxMessageBox(IDS_STRING_ILLIGLE_FILE);
						file.Close();
						goto failed_exit;
					}
					pstr=new char[temp.GetLength()];
					memset(pstr,0,temp.GetLength());
					sscanf(temp,"%*[^=]%*[^[][%[^]]",pstr);
					CString temp2=pstr;
					delete pstr;

					while(-1!=temp2.Find(',',start))
					{
						cntr++;
						start=temp2.Find(',',start)+1;
					}
					if(temp2.GetLength()!=start)
						cntr++;

					pList=new int[cntr];
					memset(pList,0,cntr*sizeof(int));
					cntr=0;
					while(temp2.GetLength())
					{
						sscanf(temp2,"%f",&fdata);
						pList[cntr]=FtoI(fdata*10);
						if(-1!=temp2.Find(','))
							temp2.Delete(0,temp2.Find(',')+1);
						else
							temp2.Empty();
						cntr++;
					}
					if(pmechanical_zero_point!=NULL)
						delete pmechanical_zero_point;
					pmechanical_zero_point=pList;
					break;
				}
			}
			file.Close();
		}
		break;
	case IDC_RADIO_USE_CURRENT:
		{
			CMotionDebug40Doc *pdoc=view->GetDocument();
			CSingleGait *pGait=pdoc->GetSingleGait();
			joint_number=pGait->GetJointNum();
			pmechanical_zero_point=new int[joint_number];
			pGait->GetZeroList(pmechanical_zero_point);
		}
		break;
	case IDC_RADIO_USE_GTS:
		{
			joint_number=dlg->gaitSettingMemory.GetMechanicalZeroPoint(&pmechanical_zero_point);
			if(joint_number==0)
			{
				AfxMessageBox(IDS_STRING_GTSZEROPOINT_UNSPECIFIED);
				goto failed_exit;
			}
		}
		break;
	default:
		break;
	}
#define GAIT_ID_ONLINE_TRAJECTORY 254
	//start robot and walking parameter download
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_GAIT_MEMORY_START;
	packet.dspInst->length=10;
	packet.dspInst->parameter[0]=GAIT_ID_ONLINE_TRAJECTORY;
	packet.dspInst->parameter[1]=3;
	packet.dspInst->parameter[2]=joint_number;
	packet.dspInst->parameter[3]=0;
	packet.dspInst->parameter[4]=0;
	packet.dspInst->parameter[5]=0;
	packet.dspInst->parameter[6]=0;
	packet.dspInst->parameter[7]=0;
	packet.ConstructPacket();

	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}

	//download zero point infomation
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_ADD_DATA_PATCH;
	packet.dspInst->length=2+joint_number*2;
	for(i=0;i<joint_number;i++)
	{
		short temp=0;
		//temp=(short)(512+pmechanical_zero_point[i]*1024/3000);
		temp=(short)(2048+pmechanical_zero_point[i]*4096/3600);
		packet.dspInst->parameter[2*i]=temp&0xff;
		packet.dspInst->parameter[2*i+1]=(temp>>8)&0xff;
	}
	packet.ConstructPacket();
	if(
		!view->SendAndRecv(packet,1,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}
	dlg->m_ProgressDownload.SetPos(1);

	//start download of robot parameter
	robot_parameter_len=dlg->gaitSettingMemory.GetRobotTypeParameter(&probot);
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_ADD_DATA_PATCH;
	packet.dspInst->length=2+robot_parameter_len*2;
	for(i=0;i<robot_parameter_len;i++)
	{
		packet.dspInst->parameter[2*i]=probot[i]&0xff;
		packet.dspInst->parameter[2*i+1]=(probot[i]>>8)&0xff;
	}
	packet.ConstructPacket();
	if(
		!view->SendAndRecv(packet,1,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}
	dlg->m_ProgressDownload.SetPos(2);

	//start download of walking parameter
	robot_parameter_len=dlg->gaitSettingMemory.GetRobotWalkingParameter(&probot);
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_ADD_DATA_PATCH;
	packet.dspInst->length=2+robot_parameter_len*2;
	for(i=0;i<robot_parameter_len;i++)
	{
		packet.dspInst->parameter[2*i]=probot[i]&0xff;
		packet.dspInst->parameter[2*i+1]=(probot[i]>>8)&0xff;
	}
	packet.ConstructPacket();
	if(
		!view->SendAndRecv(packet,1,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}
	dlg->m_ProgressDownload.SetPos(3);

	//finish download of basic parameter
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_FLASH_PROGRAM;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}

	Sleep(100);

	//start robot and walking parameter download
	robot_parameter_len=dlg->gaitSettingMemory.GetFrameData(
		&probot,
		&rythm_step,
		&rythm_frame
		);

	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_GAIT_MEMORY_START;
	packet.dspInst->length=10;
	packet.dspInst->parameter[0]=GAIT_ID_ONLINE_TRAJECTORY+1;
	packet.dspInst->parameter[1]=rythm_frame;
	packet.dspInst->parameter[2]=rythm_step;
	packet.dspInst->parameter[3]=rythm_frame;
	packet.dspInst->parameter[4]=0;
	packet.dspInst->parameter[5]=0;
	packet.dspInst->parameter[6]=0;
	packet.dspInst->parameter[7]=0;
	packet.ConstructPacket();

	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}

	for(i=0;i<rythm_frame;i++)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_ADD_DATA_PATCH;
		packet.dspInst->length=2+rythm_step*2;
		for(int j=0;j<rythm_step;j++)
		{
			packet.dspInst->parameter[2*j]=probot[i*rythm_step+j]&0xff;
			packet.dspInst->parameter[2*j+1]=(probot[i*rythm_step+j]>>8)&0xff;
		}
		packet.ConstructPacket();
		if(
			!view->SendAndRecv(packet,1,100)||
			!packet.DestructPacket()
			)
		{
			AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
			goto failed_exit;
		}
		dlg->m_ProgressDownload.SetPos(4+i);
	}

	//finish download of basic parameter
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_FLASH_PROGRAM;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_DOWNLOAD_FAILED);
		goto failed_exit;
	}

	AfxMessageBox(IDS_STRING_DOWNLOAD_SUCCESS);
	dlg->m_ProgressDownload.SetPos(0);
	/*
	dlg->m_ProgressDownload.SetRange(0,frameNum);

	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_GAIT_MEMORY_START;
	packet.dspInst->length=10;
	packet.dspInst->parameter[0]=dlg->m_comboGaitID.GetCurSel()+1;
	packet.dspInst->parameter[1]=frameNum;
	packet.dspInst->parameter[2]=view->m_MotionList.GetCols()-1;
	packet.dspInst->parameter[3]=periodNum&0xff;
	packet.dspInst->parameter[4]=(periodNum>>8)&0xff;
	packet.dspInst->parameter[5]=0;
	packet.dspInst->parameter[6]=0;
	packet.dspInst->parameter[7]=0;
	packet.ConstructPacket();

	if(
	!view->SendAndRecv(packet,2,100)||
	!packet.DestructPacket()
	)
	goto failed_exit;

	for(i=0;i<frameNum;i++)
	{
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_ADD_DATA_PATCH;
	packet.dspInst->length=2+1+jointNum*2;
	view->ConstructFrameData(packet.dspInst->parameter,i+1);
	packet.ConstructPacket();
	if(
	!view->SendAndRecv(packet,1,100)||
	!packet.DestructPacket()
	)
	goto failed_exit;
	dlg->m_ProgressDownload.SetPos(i+1);
	}

	tgtStr.LoadString(IDS_STRING_FLASH_PROGRAM);
	dlg->m_staticDownloadNotification.SetWindowText(tgtStr);

	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_FLASH_PROGRAM;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	if(
	!view->SendAndRecv(packet,2,100)||
	!packet.DestructPacket()
	)
	goto failed_exit;

	Sleep(100);
	AfxMessageBox(IDS_STRING_DOWNLOAD_SUCCESS);
	dlg->m_ProgressDownload.SetPos(0);
	dlg->m_staticDownloadNotification.SetWindowText(preStr);
	return 0;
	*/
failed_exit:
	switch(sel)
	{
	case IDC_RADIO_USE_GAIT:
	case IDC_RADIO_USE_CURRENT:
		if(pmechanical_zero_point!=NULL)
			delete pmechanical_zero_point;
		pmechanical_zero_point=NULL;
		joint_number=0;
		break;
	default:
		break;
	}
	dlg->m_ProgressDownload.SetPos(0);

	return 0;
}

void CDlgStateSwap::OnBnClickedButtonGetCalibratepath()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString tempFileName;
	CFileDialog dlg(TRUE, NULL, NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"m Files(*.m)|*.m||"); 

	if ( dlg.DoModal()!=IDOK ) 
		return;

	tempFileName=dlg.GetPathName();
	m_editCalibrateFile = tempFileName;
	UpdateData(FALSE);
	if(!UpdateCalibrateSettings())
		AfxMessageBox(IDS_STRING_GAIT_SETTINGS_ILLIGAL);
}

void CDlgStateSwap::OnBnClickedButtonDownloadCalibration()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	DWORD nThreadId1;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());

	if(m_editCalibrateFile.IsEmpty())
	{
		AfxMessageBox(IDS_STRING_GAIT_SETTINGS_ILLIGAL);
		return;
	}

	//try to send messages to the board and receive success or failure
	PacketTransformer packet;
	struct SensorCalibration *ps;
	ps=(struct SensorCalibration *)packet.dspInst->parameter;

	packet.dspInst->id=ID_DSP;
	packet.dspInst->length=2+sizeof(struct SensorCalibration);
	packet.dspInst->instruction=INST_CALIBRATE_AHRS;
	calibrateSettingMemory.GetSensorCalibration(ps);
	packet.ConstructPacket();

	if(
		!view->SendAndRecv(packet,2,100)||
		!packet.DestructPacket()||
		packet.dspInst->instruction!=(INST_CALIBRATE_AHRS|PACKET_TYPE_MASK)
		)
		AfxMessageBox(IDS_STRING_NO_ECHO);
	else
		AfxMessageBox(IDS_STRING_DOWNLOAD_SUCCESS);
	return;
}

void CDlgStateSwap::OnBnClickedButtonOpenFeedbackfile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString tempName;
	CString temp;
	CFileDialog dlg(FALSE, "txt", "FeedbackDefault",OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"text Files(*.txt)|*.txt||");
	GetDlgItem(IDC_BUTTON_OPEN_FEEDBACKFILE)->GetWindowText(tempName);
	temp.LoadString(IDS_STRING_CLOSE_FILE);
	if(tempName==temp)
	{
		if(enableRecording)
		{
			AfxMessageBox(IDS_STRING_ERROR_CLOSE);
			return;
		}
		m_recordFile.Close();
		temp.LoadString(IDS_STRING_OPEN_FILE);
		GetDlgItem(IDC_BUTTON_OPEN_FEEDBACKFILE)->SetWindowText(temp);
		m_editFeedbackFile.SetWindowText("");
		return;
	}
	
	if ( dlg.DoModal()!=IDOK) 
		return;
	tempName=dlg.GetFileTitle();
	if(tempName.GetLength()==0)
		return;
	tempName=dlg.GetPathName();
	if(!m_recordFile.Open(tempName, CFile::modeWrite|CFile::modeCreate))
	{
		AfxMessageBox(IDS_STRING_UNABLE_OPENFILE);
		return;
	}
	
	m_editFeedbackFile.SetWindowText(dlg.GetFileName());
	temp.LoadString(IDS_STRING_CLOSE_FILE);
	GetDlgItem(IDC_BUTTON_OPEN_FEEDBACKFILE)->SetWindowText(temp);

}

void CDlgStateSwap::OnBnClickedButtonStopMoving()
{
}

DWORD CDlgStateSwap::FeedbackThread(LPVOID lpThreadParameter)
{
	int runningCntr=0;
	PacketTransformer packet;
	struct FeedbackStatePiece piece;
	PUSHORT pdata=NULL;
	int i=0;

	struct StateSwapThreadParameter *para=(struct StateSwapThreadParameter *)lpThreadParameter;
	CDlgStateSwap *dlg=para->child;
	CMotionDebug40View *view=para->parent;
	delete para;

	while(dlg->enableRecording&&runningCntr<30)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_GAIT_STABLIZATION_VISUALIZE;
		packet.dspInst->length=2;
		packet.ConstructPacket();

		EnterCriticalSection(&(dlg->cs));
		if(
			!view->SendAndRecv(packet,1,25)||
			!packet.DestructPacket()
			)
		{
			LeaveCriticalSection(&(dlg->cs));
			runningCntr++;
			Sleep(1000);
			continue;
		}else
		{
			LeaveCriticalSection(&(dlg->cs));
			runningCntr=0;
		}

		pdata=(PUSHORT)&piece;
		for(i=0;i<sizeof(struct FeedbackStatePiece)/sizeof(USHORT);i++)
			pdata[i]=packet.dspInst->parameter[2*i]+(packet.dspInst->parameter[2*i+1]<<8);
		dlg->UpdateOuput(&piece);

		//Sleep(200);
	}
	if(runningCntr>=30)
		AfxMessageBox(IDS_STRING_STATE_SWAP_INTERRPUTED);
	return 0;
}

DWORD CDlgStateSwap::UpdateOuput(struct FeedbackStatePiece *ppiece)
{
	CString str;
	DWORD thisTime=0;
	thisTime=GetTickCount()-feedBackStartTime;
	str.Format("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
		thisTime,
		ppiece->isLeft,
		ppiece->hip.offset.x,
		ppiece->hip.offset.y,
		ppiece->hip.offset.z,
		ppiece->hip.pose.alpha,
		ppiece->hip.pose.beta,
		ppiece->hip.pose.theta,
		ppiece->sensors.incline[0],
		ppiece->sensors.incline[1],
		ppiece->sensors.incline[2],
		ppiece->sensors.omega[0],
		ppiece->sensors.omega[1],
		ppiece->sensors.omega[2]
	);
	m_recordFile.WriteString(str);
	return 0;
}

void CDlgStateSwap::OnBnClickedButtonStartRecordfile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString str1;
	CString str2;
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_START_RECORDFILE);
	cwnd->GetWindowText(str1);
	str2.LoadString(IDS_STRING_START_RECORD);
	if(str1!=str2)
	{
		//the recording thread is stopped here
		enableRecording=false;
		cwnd->SetWindowText(str2);
		return;
	}

	if(!m_recordFile.m_pStream)
	{
		enableRecording=false;
		AfxMessageBox(IDS_STRING_UNABLE_STARTRECORD);
		return;
	}
	enableRecording=true;

	//start another thread to record motion file
	DWORD nThreadId1;
	CMotionDebug40View *view=(CMotionDebug40View *)(this->GetOwner());
	struct StateSwapThreadParameter *para=NULL;
	para=new struct StateSwapThreadParameter;
	para->parent=view;
	para->child=this;
	feedBackStartTime=GetTickCount();

	swapThreadHandle=::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(FeedbackThread),
		para,
		0,
		&nThreadId1
		);

	str1.LoadString(IDS_STRING_STOP_RECORD);
	cwnd->SetWindowText(str1);
}

bool CDlgStateSwap::CheckTaskComplete()
{
	return !(m_recordFile.m_pStream||enableRecording);
}

void CDlgStateSwap::OnCancel()
{
	// TODO: �ڴ�����ר�ô����/����û���
	if(!CheckTaskComplete())
	{
		AfxMessageBox(IDS_STRING_TASKCOMPLETE_FAILED);
		return;
	}	
	CDialog::OnCancel();
}

void CDlgStateSwap::OnOK()
{
	// TODO: �ڴ�����ר�ô����/����û���
	if(!CheckTaskComplete())
	{
		AfxMessageBox(IDS_STRING_TASKCOMPLETE_FAILED);
		return;
	}	
	CDialog::OnOK();
}
