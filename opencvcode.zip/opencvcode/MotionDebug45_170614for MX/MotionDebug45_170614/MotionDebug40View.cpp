// MotionDebug40View.cpp : implementation of the CMotionDebug40View class
//

#include "stdafx.h"
#include "MotionDebug40.h"
#include "RobotView.h"
#include "DspControl.h"
#include "PacketTransformer.h"
#include "WirelessConnection.h"
#include "DialogCalabrate.h"
#include "DialogDownload.h"
#include "SingleGait.h"
#include "MotionDebug40Doc.h"
#include "MotionDebug40View.h"
#include "DialogGaitsList.h"
#include "GaitSettingsMemory.h"
#include "CalibrateSettingsMemory.h"
#include "DlgStateSwap.h"
#include "RunningDebug.h"
#include "DlgSelectConnection.h"
#include "Utilities.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40View

IMPLEMENT_DYNCREATE(CMotionDebug40View, CFormView)

BEGIN_MESSAGE_MAP(CMotionDebug40View, CFormView)
	//{{AFX_MSG_MAP(CMotionDebug40View)
	ON_BN_CLICKED(IDC_BUTTON_CONNECT_ESTABLISH, OnButtonConnectEstablish)
	ON_COMMAND(ID_TOOLS_CALIBRATE, OnToolsCalibrate)
	ON_COMMAND(ID_TOOLS_DOWNLOAD, OnToolsDownload)
	ON_COMMAND(ID_TOOLS_RUN_LIST, OnToolsRunList)
	ON_COMMAND(ID_EDIT_INSERT_TOP, OnEditInsertTop)
	ON_COMMAND(ID_EDIT_INSERT_BOTTOM, OnEditInsertBottom)
	ON_COMMAND(ID_EDIT_DELETE_CURRENT, OnEditDeleteCurrent)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE_TOP, OnEditPasteTop)
	ON_COMMAND(ID_EDIT_PASTE_BOTTOM, OnEditPasteBottom)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_CBN_CLOSEUP(IDC_COMBO_SELECT_VIEW, OnCloseupComboSelectView)
	ON_WM_HSCROLL()
	ON_EN_CHANGE(IDC_EDIT_STATIC_TUNNING, OnChangeEditStaticTunning)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_BN_CLICKED(IDC_BUTTON_WAKE_UP, OnButtonWakeUp)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_FORWARD_STEP, OnButtonForwardStep)
	ON_BN_CLICKED(IDC_BUTTON_BACK_STEP, OnButtonBackStep)
	ON_BN_CLICKED(IDC_BUTTON_FORWARD, OnButtonForward)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_BACKWARD, OnButtonBackward)
	ON_COMMAND(ID_TOOLS_STATE_CMD_SWAP, OnToolsStateCmdSwap)
	ON_COMMAND(ID_TOOLS_RUNNING_DEBUG, OnToolsRunningDebug)
	ON_COMMAND(ID_TOOLS_NETWORK_DEBUG, OnToolsNetworkDebug)
	//}}AFX_MSG_MAP
	ON_EN_CHANGE(USER_EDIT_GRID_ID, OnEditGridID)
	ON_CONTROL_RANGE(BN_CLICKED,USER_CBUTTON_JOINT_BASE,USER_CBUTTON_JOINT_BASE+200,OnCbuttonJoint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40View construction/destruction

CMotionDebug40View::CMotionDebug40View()
	: CFormView(CMotionDebug40View::IDD)
{
	//{{AFX_DATA_INIT(CMotionDebug40View)
	m_editJointID = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	binitializeDefault=false;
	binitializeOnce=false;
	interLock=false;
	pJoint=NULL;
	nGaitPointer=0;
	actionEnable=false;
		
	isUsingCom=TRUE;
	ipAddress=ntohl(inet_addr("192.168.1.101"));
	port=50001;
}

CMotionDebug40View::~CMotionDebug40View()
{
}

void CMotionDebug40View::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMotionDebug40View)
	DDX_Control(pDX, IDC_SLIDER_TUNING_ANGLE, m_sliderTuningAngle);
	DDX_Control(pDX, IDC_EDIT_STATIC_TUNNING, m_editStaticTuning);
	DDX_Control(pDX, IDC_STATIC_ROBOT_IMAGE, m_staticRobotImage);
	DDX_Control(pDX, IDC_COMBO_SELECT_VIEW, m_comboSelectView);
	DDX_Control(pDX, IDC_COMBO_COM_BAUDRATE, m_comboComBaudrate);
	DDX_Control(pDX, IDC_COMBO_COM_PORT, m_comboComPort);
	DDX_Control(pDX, IDC_MSCOMM, m_Comm);
	DDX_Control(pDX, IDC_MSFLEXGRID, m_MotionList);
	DDX_Text(pDX, IDC_EDIT_JOINT_ID, m_editJointID);
	//}}AFX_DATA_MAP
}

BOOL CMotionDebug40View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CMotionDebug40View::OnInitialUpdate()
{
	unsigned int jointNum;
	CString strName;
	COleVariant vt;
	WSADATA Ws;

	 if (WSAStartup(MAKEWORD(2,2), &Ws)!= 0 )
	 {
		 AfxMessageBox("network unable to work!");
	 }

	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	//initialization of RS232
	if(!binitializeOnce)
	{
		CheckCOM();
		InitCOMBaudrate();
		InitSerialPort();
		
		//initialization of motion list
		m_MotionList.SetColWidth(-1,600);
		m_MotionList.SetColWidth(0,600);
		
		CString temp;
		temp.LoadString(IDS_STRING_GAIT_COUNTER);
		m_MotionList.SetTextMatrix(0,0,temp);
		temp.LoadString(IDS_STRING_FRAME_NUMBER);
		m_MotionList.SetTextMatrix(0,1,temp);

		m_comboSelectView.Clear();
		robotView.LoadView(IDB_BITMAP_MAIN_VIEW);
		m_comboSelectView.InsertString(0,robotView.GetViewName());
		robotView.LoadView(IDB_BITMAP_SIDE_VIEW);
		m_comboSelectView.InsertString(1,robotView.GetViewName());
		
		m_comboSelectView.SetCurSel(0);
		UpdateButtons(IDB_BITMAP_MAIN_VIEW);

		binitializeOnce=true;
	}
	
	CMotionDebug40Doc *pDoc=GetDocument();
	CSingleGait *pSingleGait=pDoc->GetSingleGait();	
	jointNum=pSingleGait->GetJointNum();
	m_MotionList.SetCols(jointNum+2);
	for(long nIndex=2; nIndex<m_MotionList.GetCols(); nIndex++)
	{
		strName.Format( "%.2d", nIndex-1);
		m_MotionList.SetTextMatrix( 0,nIndex, strName );
	}
	
	//initialize gait data to default
	if(!binitializeDefault)
	{
		while(m_MotionList.GetRows()>2)
			m_MotionList.RemoveItem(1);
		vt.lVal = 1;
		vt.vt = VT_I4;
		m_MotionList.AddItem( "", vt );
		m_MotionList.SetTextMatrix(1,0,"1");
		m_MotionList.SetTextMatrix( 1, 1, "1" );
		for(long nIndex=2; nIndex<m_MotionList.GetCols(); nIndex++ )
		{
			m_MotionList.SetTextMatrix( 1, nIndex, "0" );
		}
	}else
		binitializeDefault=false;
	SetGaitPointer(1);
}

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40View diagnostics

#ifdef _DEBUG
void CMotionDebug40View::AssertValid() const
{
	CFormView::AssertValid();
}

void CMotionDebug40View::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CMotionDebug40Doc* CMotionDebug40View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMotionDebug40Doc)));
	return (CMotionDebug40Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMotionDebug40View message handlers

void CMotionDebug40View::OnButtonConnectEstablish() 
{
	// TODO: Add your control notification handler code here
	CString buttonCap,buttonStr;
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_CONNECT_ESTABLISH);
	cwnd->GetWindowText(buttonCap);
	buttonStr.LoadString(IDS_STRING_DISCONNECT);
	
	if(GetPortOpen()&&buttonCap==buttonStr)
	{
		buttonStr.LoadString(IDS_STRING_CONNECT);
		cwnd->SetWindowText(buttonStr);
		EnablePortSetting(TRUE);

		//send the message to indicate disconnecting of robot
		EnableMachineOperation(false);
		cwnd=GetDlgItem(IDC_BUTTON_WAKE_UP);
		buttonStr.LoadString(IDS_STRING_WAKE_UP);
		cwnd->SetWindowText(buttonStr);
		cwnd->EnableWindow(FALSE);
		
		SetPortOpen(FALSE);
		return;
	}
	
	buttonStr.LoadString(IDS_STRING_CONNECT);
	if(!GetPortOpen()&&buttonCap==buttonStr)
	{
		PacketTransformer packet;
		
		OpenPortWithSettings();
		//send packet to main board
		packet.dspInst->id=ID_DSP;
		packet.dspInst->length=2;
		packet.dspInst->instruction=INST_CONNECTION_VALID;
		packet.ConstructPacket();
		if(
			!SendAndRecv(packet,2,100)||
			!packet.DestructPacket()||
			packet.dspInst->instruction!=(INST_CONNECTION_VALID|PACKET_TYPE_MASK)
			)
		{
			SetPortOpen(FALSE);
			AfxMessageBox(IDS_STRING_CONNECT_ERROR);
			return;
		}

		buttonStr.LoadString(IDS_STRING_DISCONNECT);
		cwnd->SetWindowText(buttonStr);
		EnablePortSetting(FALSE);
		
		cwnd=GetDlgItem(IDC_BUTTON_WAKE_UP);
		buttonStr.LoadString(IDS_STRING_WAKE_UP);
		cwnd->SetWindowText(buttonStr);
		cwnd->EnableWindow();
		
		return;
	}
	AfxMessageBox(IDS_STRING_CONNECT_ERROR);
}

void CMotionDebug40View::CheckCOM()
{
	CString   strCom;
	int   nCom   =   0;   
	int   count   =   0;   
	HANDLE     hCom; 
	m_comboComPort.SetEditSel(0, -1);
	m_comboComPort.Clear();
	do   
	{   
		nCom++;  
		strCom.Format("COM%d",   nCom); 
		hCom   =   CreateFile(strCom,   0,   0,   0,     
			OPEN_EXISTING,   FILE_ATTRIBUTE_NORMAL,   0);   
		if(INVALID_HANDLE_VALUE   !=  hCom)  
		{
			m_comboComPort.AddString(strCom);	
		}
		count++;
		CloseHandle(hCom);
	}while(count<20);   	
	m_comboComPort.SetCurSel(0);
}

void CMotionDebug40View::InitCOMBaudrate()
{
	m_comboComBaudrate.SetEditSel(0,-1);
	m_comboComBaudrate.Clear();
	m_comboComBaudrate.InsertString(0,"9600");
	m_comboComBaudrate.InsertString(1,"19200");
	m_comboComBaudrate.InsertString(2,"115200");
	m_comboComBaudrate.SetCurSel(2);
}

void CMotionDebug40View::InitSerialPort()
{
	if(m_Comm.GetPortOpen()) //��������Ǵ򿪵ģ����йرմ���
	{
		m_Comm.SetPortOpen(FALSE);
	}

	m_Comm.SetInBufferSize(1024*3); //���ջ�����
	m_Comm.SetOutBufferSize(1024*3);//���ͻ�����	
	m_Comm.SetInputLen(0);//���õ�ǰ���������ݳ���Ϊ0,��ʾȫ����ȡ
	m_Comm.SetInputMode(1);//��2��д����
}


void CMotionDebug40View::OnDraw(CDC* pDC) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(!pDC->IsPrinting())
	{
		UpdateImageDisplay();
	}
}

BOOL CMotionDebug40View::UpdateImageDisplay()
{
	CBitmap bitmap;
	bitmap.LoadBitmap(robotView.GetImageID());
	m_staticRobotImage.SetBitmap(bitmap);
	return TRUE;
}

void CMotionDebug40View::OnToolsCalibrate() 
{
	// TODO: Add your command handler code here
	CDialogCalabrate dlg;
	dlg.SetOwner(this);
	dlg.DoModal();
}

int CMotionDebug40View::GetCalabrateInfo(unsigned int &num,int **list)
{
	CMotionDebug40Doc *doc=GetDocument();
	CSingleGait *pGait=doc->GetSingleGait();
	if((num=pGait->GetJointNum())!=0)
	{
		*list=new int[num];
		//read the calabrate value
		pGait->GetZeroList(*list);
	}else
		*list=NULL;
	return 0;
}

int CMotionDebug40View::SetCalabrateInfo(unsigned int num,int *list)
{
	CMotionDebug40Doc *doc=GetDocument();
	CSingleGait *pGait=doc->GetSingleGait();
	if(pGait->GetJointNum()!=num)
		doc->SetModifiedFlag();
	else
	{
		int *pTemp=NULL;
		pTemp=new int[num];
		pGait->GetZeroList(pTemp);
		if(memcmp(pTemp,list,sizeof(int)*num)!=0)
			doc->SetModifiedFlag();
		delete []pTemp;
		pTemp=NULL;
	}
	
	pGait->SetJointNum(num);
	//set the calabrate value
	pGait->SetZeroList(list);
	//update the motion list

	return 0;
}

void CMotionDebug40View::OnToolsDownload() 
{
	// TODO: Add your command handler code here
	CDialogDownload dlg;
	dlg.SetOwner(this);
	dlg.DoModal();
}

CSingleGait* CMotionDebug40View::GetGaitInfo()
{
	CMotionDebug40Doc *doc=GetDocument();
	return doc->GetSingleGait();
}

void CMotionDebug40View::OnToolsRunList() 
{
	// TODO: Add your command handler code here
	CDialogGaitsList dlg;
	dlg.SetOwner(this);
	dlg.DoModal();
}

void CMotionDebug40View::SetNoDefault()
{
	binitializeDefault=true;
}

void CMotionDebug40View::OnEditInsertTop() 
{
	// TODO: Add your command handler code here
	long currRow=0;
	CString strJointValue;
	COleVariant vt;

	currRow=m_MotionList.GetRow();
	if(currRow==0||currRow==m_MotionList.GetRows()-1||currRow!=m_MotionList.GetRowSel())
	{
		AfxMessageBox(IDS_STRING_UNABLE_INSERT);
		return;
	}

	vt.lVal = currRow;
	vt.vt = VT_I4;
	m_MotionList.AddItem( "", vt );
	UpdateMotionListOrder();
	ResetMotionListRow(currRow);
	if(currRow<=nGaitPointer)
		SetGaitPointer(nGaitPointer+1);
	m_MotionList.SetRow(currRow);
	m_MotionList.SetRowSel(currRow);
	m_MotionList.SetCol(1);
	m_MotionList.SetColSel(m_MotionList.GetCols()-1);
	GetDocument()->SetModifiedFlag();
}

void CMotionDebug40View::ResetMotionListRow(long row)
{
	CString str;
	if(row==0||row==m_MotionList.GetRows()-1)
		return;
	str="1";
	m_MotionList.SetTextMatrix(row,1,str);
	str="0";
	for(long i=2;i<m_MotionList.GetCols();i++)
		m_MotionList.SetTextMatrix(row,i,str);
}

void CMotionDebug40View::UpdateMotionListOrder()
{
	CString order;
	for (long i=1;i<m_MotionList.GetRows()-1;i++)
	{
		order.Format("%d",i);
		m_MotionList.SetTextMatrix(i,0,order);
	}
}

void CMotionDebug40View::OnEditInsertBottom() 
{
	// TODO: Add your command handler code here
	long currRow=0;
	CString strJointValue;
	COleVariant vt;

	currRow=m_MotionList.GetRow();
	if(currRow==0||currRow==m_MotionList.GetRows()-1||currRow!=m_MotionList.GetRowSel())
	{
		AfxMessageBox(IDS_STRING_UNABLE_INSERT);
		return;
	}

	vt.lVal = currRow+1;
	vt.vt = VT_I4;
	m_MotionList.AddItem( "", vt );
	UpdateMotionListOrder();
	ResetMotionListRow(currRow+1);
	if(currRow<nGaitPointer)
		SetGaitPointer(nGaitPointer+1);
	m_MotionList.SetRow(currRow+1);
	m_MotionList.SetRowSel(currRow+1);
	m_MotionList.SetCol(1);
	m_MotionList.SetColSel(m_MotionList.GetCols()-1);
	GetDocument()->SetModifiedFlag();
}

void CMotionDebug40View::OnEditDeleteCurrent() 
{
	// TODO: Add your command handler code here
	long currRow=0;
	CString strJointValue;
	COleVariant vt;

	currRow=m_MotionList.GetRow();
	if(
		currRow==0||
		currRow==m_MotionList.GetRows()-1||
		currRow!=m_MotionList.GetRowSel()||
		m_MotionList.GetRows()<=3
		)
	{
		AfxMessageBox(IDS_STRING_UNABLE_DELETE);
		return;
	}
	m_MotionList.RemoveItem(currRow);
	if(
		currRow<nGaitPointer||
		(currRow==nGaitPointer&&currRow==m_MotionList.GetRows()+1-2)
		)
		SetGaitPointer(nGaitPointer-1);
	else
		SetGaitPointer(nGaitPointer);
	UpdateMotionListOrder();
	GetDocument()->SetModifiedFlag();
}

void CMotionDebug40View::OnEditCut() 
{
	// TODO: Add your command handler code here
	long left=m_MotionList.GetCol();
	long right=m_MotionList.GetColSel();
	long top=m_MotionList.GetRow();
	long bottom=m_MotionList.GetRowSel();
	if(
		left!=1||
		right!=m_MotionList.GetCols()-1||
		top!=bottom||
		m_MotionList.GetRows()<=3||
		top==0||
		bottom==m_MotionList.GetRows()-1
		)
	{
		AfxMessageBox(IDS_STRING_UNABLE_CUT);
		return;
	}
	clip=m_MotionList.GetClip();
	OnEditDeleteCurrent();
	GetDocument()->SetModifiedFlag();
}

void CMotionDebug40View::OnEditPasteTop() 
{
	// TODO: Add your command handler code here
	long currRow;
	
	currRow=m_MotionList.GetRow();
	if(currRow==0||currRow==m_MotionList.GetRows()-1||currRow!=m_MotionList.GetRowSel())
	{
		AfxMessageBox(IDS_STRING_UNABLE_INSERT);
		return;
	}
	OnEditInsertTop();
	m_MotionList.SetRow(currRow);
	m_MotionList.SetRowSel(currRow);
	m_MotionList.SetCol(1);
	m_MotionList.SetColSel(m_MotionList.GetCols()-1);
	m_MotionList.SetClip(clip);
	GetDocument()->SetModifiedFlag();
}

void CMotionDebug40View::OnEditPasteBottom() 
{
	// TODO: Add your command handler code here
	long currRow;
	
	currRow=m_MotionList.GetRow();
	if(currRow==0||currRow==m_MotionList.GetRows()-1||currRow!=m_MotionList.GetRowSel())
	{
		AfxMessageBox(IDS_STRING_UNABLE_INSERT);
		return;
	}
	OnEditInsertBottom();
	m_MotionList.SetRow(currRow+1);
	m_MotionList.SetRowSel(currRow+1);
	m_MotionList.SetCol(1);
	m_MotionList.SetColSel(m_MotionList.GetCols()-1);
	m_MotionList.SetClip(clip);	
	GetDocument()->SetModifiedFlag();
}

int CMotionDebug40View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	RegisterActiveX(true);
	RegisterActiveX2(true);

	m_pEdit=new CEdit();
	if(m_pEdit!=NULL)
		m_pEdit->Create(WS_CHILD|WS_BORDER|ES_AUTOHSCROLL,CRect(0,0,0,0),this,USER_EDIT_GRID_ID);
	else
		return -1;

	return 0;
}

bool CMotionDebug40View::RegisterActiveX(bool isRegistered)
{
	//ActiveX�ؼ���·�����ļ���
	LPCTSTR pszDllName="mscomm32.ocx";
	//װ��ActiveX�ؼ�
	HINSTANCE hLib = LoadLibrary(pszDllName);
	if (hLib < (HINSTANCE)HINSTANCE_ERROR)
	{
		return false;
	}
	// ��ȡע�ắ��DllRegisterServer��ַ
	FARPROC lpDllEntryPoint;
	if(isRegistered)
		lpDllEntryPoint=GetProcAddress(hLib,_T("DllRegisterServer"));
	else
		lpDllEntryPoint=GetProcAddress(hLib,_T("DllUnregisterServer"));
	// ����ע�ắ��DllRegisterServer
	if(lpDllEntryPoint!=NULL)
	{
		if(FAILED((*lpDllEntryPoint)()))
		{
			FreeLibrary(hLib);
			return false;
		}
	}
	else
	{
		return false;
	}
	return true;
}

bool CMotionDebug40View::RegisterActiveX2(bool isRegistered)
{
	//ActiveX�ؼ���·�����ļ���
	LPCTSTR pszDllName="MSFLXGRD.OCX";
	//װ��ActiveX�ؼ�
	HINSTANCE hLib = LoadLibrary(pszDllName);
	if (hLib < (HINSTANCE)HINSTANCE_ERROR)
	{
		return false;
	}
	// ��ȡע�ắ��DllRegisterServer��ַ
	FARPROC lpDllEntryPoint;
	if(isRegistered)
		lpDllEntryPoint=GetProcAddress(hLib,_T("DllRegisterServer"));
	else
		lpDllEntryPoint=GetProcAddress(hLib,_T("DllUnregisterServer"));
	// ����ע�ắ��DllRegisterServer
	if(lpDllEntryPoint!=NULL)
	{
		if(FAILED((*lpDllEntryPoint)()))
		{
			FreeLibrary(hLib);
			return false;
		}
	}
	else
	{
		return false;
	}
	return true;
}

void CMotionDebug40View::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// TODO: Add your message handler code here
	m_pEdit->DestroyWindow();
	delete m_pEdit;
	m_pEdit=NULL;
	
	if(pJoint!=NULL)
	{
		for(unsigned int i=0;i<robotView.GetJointNumber();i++)
		{
			pJoint[i].DestroyWindow();
		}
		delete []pJoint;
		pJoint=NULL;
	}

	WSACleanup();
}

BEGIN_EVENTSINK_MAP(CMotionDebug40View, CFormView)
    //{{AFX_EVENTSINK_MAP(CMotionDebug40View)
	ON_EVENT(CMotionDebug40View, IDC_MSFLEXGRID, -600 /* Click */, OnClickMsflexgrid, VTS_NONE)
	ON_EVENT(CMotionDebug40View, IDC_MSFLEXGRID, 72 /* LeaveCell */, OnLeaveCellMsflexgrid, VTS_NONE)
	ON_EVENT(CMotionDebug40View, IDC_MSFLEXGRID, 73 /* Scroll */, OnScrollMsflexgrid, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CMotionDebug40View::OnClickMsflexgrid() 
{
	// TODO: Add your control notification handler code here
	if(
		m_MotionList.GetRow()!=m_MotionList.GetRowSel()||
		m_MotionList.GetCol()!=m_MotionList.GetColSel()||
		m_MotionList.GetRow()==m_MotionList.GetRows()-1||
		m_MotionList.GetRow()==0||
		m_MotionList.GetCol()==0
		)
		return;
		
	CDC* pDC = m_MotionList.GetDC();
	
	long x = ( m_MotionList.GetCellLeft() * pDC -> GetDeviceCaps ( LOGPIXELSX ) ) / 1440;
	
	long y = ( m_MotionList.GetCellTop() * pDC -> GetDeviceCaps ( LOGPIXELSY ) ) / 1440;
	
	long cx = ( m_MotionList.GetCellWidth() * pDC -> GetDeviceCaps ( LOGPIXELSX ) ) / 1440;
	
	long cy = ( m_MotionList.GetCellHeight() * pDC -> GetDeviceCaps ( LOGPIXELSY ) )/ 1440;
	
	ReleaseDC ( pDC );
	
	CString strContent;
	CPoint pt(x,y);
	
	strContent = m_MotionList.GetText();
	m_pEdit->SetWindowText(strContent);

	m_MotionList.ClientToScreen(&pt);
	ScreenToClient(&pt);
	m_pEdit->MoveWindow(pt.x,pt.y,cx,cy,FALSE);
	m_pEdit->ShowWindow(SW_SHOW);

	m_editStaticTuning.EnableWindow();
	m_sliderTuningAngle.EnableWindow();
	m_sliderTuningAngle.SetFocus();

	m_editStaticTuning.SetWindowText(strContent);
	if(m_MotionList.GetCol()==1)
	{
		m_sliderTuningAngle.SetRange(1,30);
		m_sliderTuningAngle.SetTicFreq(1);
		m_sliderTuningAngle.SetPos(atoi(strContent));
	}else
	{
		m_sliderTuningAngle.SetRange(0,1023);
		m_sliderTuningAngle.SetTicFreq(32);
		m_sliderTuningAngle.SetPos(StrToServo(strContent,m_MotionList.GetCol()-1));
	}
	
	strContent=m_MotionList.GetTextMatrix(0,m_MotionList.GetCol());
	m_editJointID=strContent;
	UpdateData(FALSE);

	unsigned int index=0;
	for(index=0;index<robotView.GetJointNumber();index++)
		pJoint[index].SetCheck(BST_UNCHECKED);
	if((index=robotView.FindJointID(m_MotionList.GetCol()-1))!=-1)
		pJoint[index].SetCheck(BST_CHECKED);

	this->Invalidate();
}

void CMotionDebug40View::OnLeaveCellMsflexgrid() 
{
	// TODO: Add your control notification handler code here
	if (m_pEdit->IsWindowVisible())
	{
		int nCol;	
		int nRow;
		
		CString strContent;
		CString preContent;
		nCol = m_MotionList.GetCol();
		nRow = m_MotionList.GetRow();
		preContent=m_MotionList.GetTextMatrix(nRow,nCol);
		m_pEdit->GetWindowText(strContent);
		if(nRow==nGaitPointer&&nCol>1&&actionEnable)
		{
			int value=StrToServo(strContent,nCol-1);
			PacketTransformer packet;
			
			packet.dspInst->id=ID_DSP;
			packet.dspInst->length=5;
			packet.dspInst->instruction=INST_SINGLE_ACTION;
			packet.dspInst->parameter[0]=nCol-2;
			packet.dspInst->parameter[1]=value&0x00ff;
			packet.dspInst->parameter[2]=(value&0xff00)>>8;
			packet.ConstructPacket();
			
			if(
				!SendAndRecv(packet,2,100)||
				!packet.DestructPacket()||
				packet.dspInst->instruction!=(INST_SINGLE_ACTION|PACKET_TYPE_MASK)
				)
				AfxMessageBox(IDS_STRING_NO_ECHO);
		}
		if(strContent!=preContent)
		{
			CMotionDebug40Doc *doc=GetDocument();
			doc->SetModifiedFlag();
		}
		m_MotionList.SetTextMatrix(nRow, nCol, strContent);
		m_pEdit->ShowWindow(SW_HIDE);

		m_editStaticTuning.EnableWindow(false);
		m_sliderTuningAngle.EnableWindow(false);
	}
}

void CMotionDebug40View::OnScrollMsflexgrid() 
{
	// TODO: Add your control notification handler code here
	if ( !m_pEdit->IsWindowVisible ( ) ) 
		 return;
	else
		OnLeaveCellMsflexgrid();
	this->Invalidate();
}

void CMotionDebug40View::OnCloseupComboSelectView() 
{
	// TODO: Add your control notification handler code here
	switch(m_comboSelectView.GetCurSel())
	{
	case 0:
		UpdateButtons(IDB_BITMAP_MAIN_VIEW);
		break;
	case 1:
		UpdateButtons(IDB_BITMAP_SIDE_VIEW);
		break;
	default:
		break;
	}
	this->Invalidate();
}

void CMotionDebug40View::UpdateButtons(UINT newImage)
{
	int jn=robotView.GetJointNumber();
	CPoint pt(0,0);
	CRect rect;

	if(newImage==robotView.GetImageID())
		return;

	if(pJoint!=NULL)
	{
		for(unsigned int i=0;i<robotView.GetJointNumber();i++)
		{
			pJoint[i].DestroyWindow();
		}
		delete []pJoint;
		pJoint=NULL;
	}

	robotView.LoadView(newImage);
	jn=robotView.GetJointNumber();
	if(jn==0)
	{
		pJoint=NULL;
		return;
	}
	pJoint=new CButton[jn];
	for(int i=0;i<jn;i++)
	{
		pt=robotView.GetAbsolutePoint(i,&m_staticRobotImage,this);
		rect.left=pt.x;
		rect.top=pt.y;
		rect.right=pt.x+70;
		rect.bottom=pt.y+20;
		pJoint[i].Create(robotView.GetJointName(i),WS_CHILD|WS_VISIBLE|BS_AUTORADIOBUTTON,rect,this,USER_CBUTTON_JOINT_BASE+i);
	}
}

void CMotionDebug40View::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default

	if(pScrollBar==GetDlgItem(IDC_SLIDER_TUNING_ANGLE)&&m_pEdit->IsWindowVisible())
	{
		if(m_MotionList.GetCol()==1)
		{
			CString value;
			value.Format("%d",m_sliderTuningAngle.GetPos());
			m_editStaticTuning.SetWindowText(value);
		}else
		{
			CString value;
			if(m_MotionList.GetRow()==nGaitPointer&&actionEnable)
			{
				PacketTransformer packet;
				int value=m_sliderTuningAngle.GetPos();
				
				packet.dspInst->id=ID_DSP;
				packet.dspInst->length=5;
				packet.dspInst->instruction=INST_SINGLE_ACTION;
				packet.dspInst->parameter[0]=m_MotionList.GetCol()-2;
				packet.dspInst->parameter[1]=value&0x00ff;
				packet.dspInst->parameter[2]=(value&0xff00)>>8;
				packet.ConstructPacket();
				
				if(
					!SendAndRecv(packet,2,100)||
					!packet.DestructPacket()||
					packet.dspInst->instruction!=(INST_SINGLE_ACTION|PACKET_TYPE_MASK)
					)
					AfxMessageBox(IDS_STRING_NO_ECHO);
			}
			value.Format("%.1f",ServoTof(m_sliderTuningAngle.GetPos(),m_MotionList.GetCol()-1));
			m_editStaticTuning.SetWindowText(value);
		}
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CMotionDebug40View::OnChangeEditStaticTunning() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	if(!interLock)
	{
		interLock=true;
		CString value;
		m_editStaticTuning.GetWindowText(value);
		m_pEdit->SetWindowText(value);
	}else
		interLock=false;
}

void CMotionDebug40View::OnEditGridID()
{
	if(!interLock)
	{
		interLock=true;
		CString value;
		m_pEdit->GetWindowText(value);
		m_pEdit->GetFocus();
		m_editStaticTuning.SetWindowText(value);
	}else
		interLock=false;
}

void CMotionDebug40View::OnEditCopy() 
{
	// TODO: Add your command handler code here
	long top=m_MotionList.GetRow();
	long bottom=m_MotionList.GetRowSel();

	if(bottom>=m_MotionList.GetRows()-1)
		bottom=m_MotionList.GetRows()-2;
	if(bottom<top)
	{
		AfxMessageBox(IDS_STRING_UNABLE_COPY);
		return;
	}
	m_MotionList.SetRowSel(bottom);
	clip=m_MotionList.GetClip();
}



void CMotionDebug40View::OnEditPaste() 
{
	// TODO: Add your command handler code here
	long top=m_MotionList.GetRow();
	long bottom=m_MotionList.GetRowSel();

	if(bottom>=m_MotionList.GetRows()-1)
		bottom=m_MotionList.GetRows()-2;
	if(bottom<top)
	{
		AfxMessageBox(IDS_STRING_UNABLE_PASTE);
		return;
	}
	m_MotionList.SetRowSel(bottom);
	m_MotionList.SetClip(clip);
	GetDocument()->SetModifiedFlag();
}

void CMotionDebug40View::OnCbuttonJoint(UINT uID)
{
	int jn=robotView.GetJointNumber();
	for(int i=0;i<jn;i++)
	{
		if(pJoint[i].GetCheck())
		{
			unsigned int jid;
			jid=robotView.GetJointID(i);
			OnLeaveCellMsflexgrid();
			m_MotionList.SetRow(nGaitPointer);
			m_MotionList.SetRowSel(nGaitPointer);
			m_MotionList.SetCol(jid+1);
			m_MotionList.SetColSel(jid+1);
			OnClickMsflexgrid();
		}
	}
	return;
}

void CMotionDebug40View::OnButtonWakeUp() 
{
	// TODO: Add your control notification handler code here
	PacketTransformer packet;
	CString name;
	CString tgt;
	
	CWnd *cwnd=GetDlgItem(IDC_BUTTON_WAKE_UP);
	cwnd->GetWindowText(name);
	tgt.LoadString(IDS_STRING_WAKE_UP);
	
	packet.dspInst->id=ID_DSP;
	if(name==tgt)
		packet.dspInst->instruction=INST_TORQUE_ON;
	else
		packet.dspInst->instruction=INST_TORQUE_OFF;
	packet.dspInst->length=2;
	packet.ConstructPacket();
	
	if(
		!SendAndRecv(packet,2,100)||
		!packet.DestructPacket()
		)
	{
		AfxMessageBox(IDS_STRING_NO_ECHO);
		return;
	}

	if(name==tgt)
	{
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_INITIAL_STATE;
		ConstructFrameData(packet.dspInst->parameter,nGaitPointer);
		packet.dspInst->length=2+1+(m_MotionList.GetCols()-2)*2;
		packet.ConstructPacket();
		if(!SendUntilWait(packet,INFO_GAIT_EXECUTED,500))
			AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
		name.LoadString(IDS_STRING_FALL_ASLEEP);
		EnableMachineOperation();
	}else
	{
		name.LoadString(IDS_STRING_WAKE_UP);
		EnableMachineOperation(false);
	}
	cwnd->SetWindowText(name);
}

void CMotionDebug40View::EnableMachineOperation(bool enable)
{
	CWnd *cwnd=NULL;
	if(enable)
	{
		cwnd=GetDlgItem(IDC_BUTTON_RESET);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_BACK_STEP);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD_STEP);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_BACKWARD);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_STOP);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD);
		cwnd->EnableWindow();
		actionEnable=true;
	}else
	{
		cwnd=GetDlgItem(IDC_BUTTON_RESET);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_BACK_STEP);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD_STEP);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_BACKWARD);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_STOP);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD);
		cwnd->EnableWindow(FALSE);
		actionEnable=false;
	}
}

bool CMotionDebug40View::SendUntilWait(PacketTransformer &rpacket,unsigned char inst,int timeout)
{
	int state=0;
	CByteArray array;
	DWORD initTime;
	unsigned char initInst=0;
	
	if(!GetPortOpen())
		return false;

	if(isUsingCom)
	{
		initInst=rpacket.dspInst->instruction;
		m_Comm.SetOutput(COleVariant(rpacket.GetByteArray()));
		rpacket.Reset();
		initTime=GetTickCount();
		do
		{
			if(m_Comm.GetInBufferCount() != 0)
			{
				array.RemoveAll();
				GetCommData(array);
				rpacket.AppandArray(array);
				while(state!=2&&rpacket.TryDestructOnePacket())
				{
					switch(state)
					{
					case 0:
						if(rpacket.dspInst->instruction==(initInst|PACKET_TYPE_MASK))
							state=1;
						break;
					case 1:
						if(rpacket.dspInst->instruction==inst)
							state=2;
						break;
					}
				}
			}
		}while(state!=2&&GetTickCount()-initTime<timeout);
	}else
	{
		initInst=rpacket.dspInst->instruction;
		wirelessConnect.SetOutput(rpacket.GetByteArray());
		rpacket.Reset();

		do
		{
			array.RemoveAll();
			if(0!=wirelessConnect.GetInput(array,timeout))
			{
				rpacket.AppandArray(array);
				while(state!=2&&rpacket.TryDestructOnePacket())
				{
					switch(state)
					{
					case 0:
						if(rpacket.dspInst->instruction==(initInst|PACKET_TYPE_MASK))
							state=1;
						break;
					case 1:
						if(rpacket.dspInst->instruction==inst)
							state=2;
						break;
					}
				}
			}else
				break;
		}while(state!=2);
	}

	if(state!=2)
		return false;
	return true;
}

bool CMotionDebug40View::TryRecvPacket(PacketTransformer &rpacket)
{
	CByteArray array;
	if(isUsingCom)
	{
		if(m_Comm.GetInBufferCount() != 0)
		{
			array.RemoveAll();
			GetCommData(array);
			rpacket.AppandArray(array);
			if(rpacket.TryDestructOnePacket())
				return true;
		}
	}else
	{
		array.RemoveAll();
		if(0!=wirelessConnect.GetInput(array,0))
		{
			rpacket.AppandArray(array);
			if(rpacket.TryDestructOnePacket())
				return true;
		}
	}
	return false;
}

bool CMotionDebug40View::SendSinglePacket(PacketTransformer &rpacket)
{
	if(!GetPortOpen())
		return false;
	//clear everything in buffer
	if(isUsingCom)
		m_Comm.SetOutput(COleVariant(rpacket.GetByteArray()));
	else
		wirelessConnect.SetOutput(rpacket.GetByteArray());
	return true;
}

DWORD CMotionDebug40View::GetGaitPeriod()
{
	UINT i=0;
	UINT rows=0;
	DWORD ret=0;
	CString temp;

	rows=m_MotionList.GetRows();
	
	for(i=1;i<rows-2;i++)
	{
		temp=m_MotionList.GetTextMatrix(i,1);
		ret+=(DWORD)atoi(temp);
	}
	ret++;
	return ret;
}

bool CMotionDebug40View::ConstructFrameData(PBYTE buffer,unsigned int frame)
{
	CString temp;
	UINT nValue=0;
	UINT i;
	PBYTE pNext=buffer;
	
	temp=m_MotionList.GetTextMatrix(frame,1);
	*pNext=(BYTE)atoi(temp);
	pNext++;
	
	for(i=2;i<m_MotionList.GetCols();i++)
	{
		temp=m_MotionList.GetTextMatrix(frame,i);
		nValue=StrToServo(temp,i-1);
		*pNext=nValue&0x00ff;
		pNext++;
		*pNext=(nValue&0xff00)>>8;
		pNext++;
	}
	return true;
}

bool CMotionDebug40View::SendAndRecv(PacketTransformer &rpacket,int times,int msec)
{
	int cntr=0;
	CByteArray array;
	
	if(!GetPortOpen())
		return false;
	//clear everything in buffer

	if(isUsingCom)
	{
		while(cntr<times)
		{
			m_Comm.SetOutput(COleVariant(rpacket.GetByteArray()));
			cntr++;
			Sleep(msec);
			if(m_Comm.GetInBufferCount() != 0)
			{
				array.RemoveAll();
				GetCommData(array);
				rpacket.SetRawPacket(array);
				return true;
			}
		}
	}else
	{
		while(cntr<times)
		{
			wirelessConnect.SetOutput(rpacket.GetByteArray());
			cntr++;
			Sleep(msec);
			if(0!=wirelessConnect.GetInput(array,0))
			{
				rpacket.SetRawPacket(array);
				return true;
			}
		}
	}

	return false;
}

int CMotionDebug40View::GetCommData(CByteArray& byteArray)
{			
	VARIANT variant_inp;
    COleSafeArray safearray_inp;
    LONG len,k;
    TBYTE temp;

	variant_inp=m_Comm.GetInput();
	safearray_inp=variant_inp;
	len=safearray_inp.GetOneDimSize();
	byteArray.SetSize(len);
	for(k=0;k<len;k++)
	{
		safearray_inp.GetElement(&k,&temp);//ת��ΪBYTE������
		byteArray.SetAt(k,temp);
	}
	return len;
}

void CMotionDebug40View::OnButtonReset() 
{
	// TODO: Add your control notification handler code here
	SetUninterruptOn();
	PacketTransformer packet;
	packet.dspInst->id=ID_DSP;
	packet.dspInst->instruction=INST_INITIAL_STATE;
	ConstructFrameData(packet.dspInst->parameter,1);
	packet.dspInst->length=2+1+(m_MotionList.GetCols()-2)*2;
	packet.ConstructPacket();
	if(!SendUntilWait(packet,INFO_GAIT_EXECUTED,500))
	{
		AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
		SetUninterruptOn(false);
		return;
	}
	SetGaitPointer(1);
	SetUninterruptOn(false);
}

void CMotionDebug40View::SetUninterruptOn(bool enable)
{
	CWnd *cwnd=NULL;
	if(enable)
	{
		cwnd=GetDlgItem(IDC_BUTTON_RESET);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_BACK_STEP);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD_STEP);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_BACKWARD);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD);
		cwnd->EnableWindow(FALSE);
		actionEnable=false;

		cwnd=GetDlgItem(IDC_BUTTON_CONNECT_ESTABLISH);
		cwnd->EnableWindow(FALSE);
		cwnd=GetDlgItem(IDC_BUTTON_WAKE_UP);
		cwnd->EnableWindow(FALSE);
	}else
	{
		cwnd=GetDlgItem(IDC_BUTTON_RESET);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_BACK_STEP);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD_STEP);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_BACKWARD);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_FORWARD);
		cwnd->EnableWindow();
		actionEnable=true;

		cwnd=GetDlgItem(IDC_BUTTON_CONNECT_ESTABLISH);
		cwnd->EnableWindow();
		cwnd=GetDlgItem(IDC_BUTTON_WAKE_UP);
		cwnd->EnableWindow();
	}
}

bool CMotionDebug40View::SetGaitPointer(unsigned int pos)
{
	if(nGaitPointer<m_MotionList.GetRows()-1&&nGaitPointer>0)
	{
		m_MotionList.SetRow(nGaitPointer);
		m_MotionList.SetCol(0);
		m_MotionList.SetCellBackColor(0x0000);
	}
	
	if(pos==0||pos>=m_MotionList.GetRows()-1)
		return false;
	
	m_MotionList.SetRow(pos);
	m_MotionList.SetCol(0);
	m_MotionList.SetCellBackColor(0xff00);
	nGaitPointer=pos;
	return true;
}

UINT CMotionDebug40View::StrToServo(const char *str,unsigned int joint)
{
	int zero=0;
	CMotionDebug40Doc *doc=GetDocument();
	CSingleGait *pGait=doc->GetSingleGait();

	if(joint==0)
		//zero=512;
		zero=2048;
	else
		//zero=512+pGait->GetJointZeroPoint(joint-1)*1024/3000;
		zero=2048+pGait->GetJointZeroPoint(joint-1)*4096/3600;
	//return FtoI(atof(str)/300*1024+zero);
	return FtoI(atof(str)/360*4096+zero);
}

float CMotionDebug40View::ServoTof(UINT ser,unsigned int joint)
{
	int zero=0;
	CMotionDebug40Doc *doc=GetDocument();
	CSingleGait *pGait=doc->GetSingleGait();

	if(joint==0)
		//zero=512;
		zero=2048;
	else
		//zero=512+pGait->GetJointZeroPoint(joint-1)*1024/3000;
		zero=2048+pGait->GetJointZeroPoint(joint-1)*4096/3600;
	return (float(ser)-zero)*360/4096;
}

void CMotionDebug40View::OnButtonForwardStep() 
{
	// TODO: Add your control notification handler code here
	SetUninterruptOn();
	if(nGaitPointer<m_MotionList.GetRows()-2)
	{
		PacketTransformer packet;
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_MULTIPLE_ACTION;
		ConstructFrameData(packet.dspInst->parameter,nGaitPointer+1);
		packet.dspInst->length=2+1+(m_MotionList.GetCols()-2)*2;
		packet.ConstructPacket();
		
		if(!SendUntilWait(packet,INFO_GAIT_EXECUTED,1000))
		{
			AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
			SetUninterruptOn(false);
			return;
		}
		SetGaitPointer(nGaitPointer+1);
	}else
		AfxMessageBox(IDS_STRING_TAILED_FRAME);
	SetUninterruptOn(false);
	return;
}

void CMotionDebug40View::OnButtonBackStep() 
{
	// TODO: Add your control notification handler code here
	SetUninterruptOn();
	if(nGaitPointer>1)
	{
		PacketTransformer packet;
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_MULTIPLE_ACTION;
		ConstructFrameData(packet.dspInst->parameter,nGaitPointer-1);
		packet.dspInst->length=2+1+(m_MotionList.GetCols()-2)*2;
		packet.ConstructPacket();
		
		if(!SendUntilWait(packet,INFO_GAIT_EXECUTED,1000))
		{
			AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
			SetUninterruptOn(false);
			return;
		}
		SetGaitPointer(nGaitPointer-1);
	}else
		AfxMessageBox(IDS_STRING_HEAD_FRAME);
	SetUninterruptOn(false);
	return;
}

void CMotionDebug40View::OnButtonForward() 
{
	// TODO: Add your control notification handler code here
	SetUninterruptOn();
	DWORD nThreadId1;
	if(nGaitPointer>=m_MotionList.GetRows()-2)
	{
		AfxMessageBox(IDS_STRING_TAILED_FRAME);
		SetUninterruptOn(false);
		return;
	}
	stepDirection=1;
	::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(StepThread),
		this,
		0,
		&nThreadId1
		);
	return;
}

DWORD CMotionDebug40View::StepThread(LPVOID lpThreadParameter)
{
	CMotionDebug40View *view=(CMotionDebug40View *)lpThreadParameter;
	int dir=0;
	dir=view->stepDirection;

	while(
		(dir>0&&(view->nGaitPointer<view->m_MotionList.GetRows()-2))||
		(dir<0&&view->nGaitPointer>1)
		)
	{
		PacketTransformer packet;
		packet.dspInst->id=ID_DSP;
		packet.dspInst->instruction=INST_MULTIPLE_ACTION;
		view->ConstructFrameData(packet.dspInst->parameter,view->nGaitPointer+dir);
		packet.dspInst->length=2+1+(view->m_MotionList.GetCols()-2)*2;
		packet.ConstructPacket();
		
		if(!view->SendUntilWait(packet,INFO_GAIT_EXECUTED,1000))
		{
			AfxMessageBox(IDS_STRING_EXECUTE_FAILED);
			view->stepDirection=0;
			view->SetUninterruptOn(false);
			return 0;
		}
		view->SetGaitPointer(view->nGaitPointer+dir);
		dir=view->stepDirection;
	}
	view->stepDirection=0;
	view->SetUninterruptOn(false);
	return 0;
}

void CMotionDebug40View::OnButtonStop() 
{
	// TODO: Add your control notification handler code here
	stepDirection=0;
}

void CMotionDebug40View::OnButtonBackward() 
{
	// TODO: Add your control notification handler code here
	SetUninterruptOn();
	DWORD nThreadId1;
	if(nGaitPointer<=1)
	{
		AfxMessageBox(IDS_STRING_HEAD_FRAME);
		SetUninterruptOn(false);
		return;
	}
	stepDirection=-1;
	::CreateThread(
		(LPSECURITY_ATTRIBUTES)NULL,
		0,
		(LPTHREAD_START_ROUTINE)(StepThread),
		this,
		0,
		&nThreadId1
		);
	return;
}

void CMotionDebug40View::OnToolsStateCmdSwap() 
{
	// TODO: Add your command handler code here
	CDlgStateSwap dlg;
	dlg.SetOwner(this);
	dlg.DoModal();
}

void CMotionDebug40View::OnToolsRunningDebug() 
{
	// TODO: Add your command handler code here
	CRunningDebug dlg;
	dlg.SetOwner(this);
	dlg.DoModal();
}

void CMotionDebug40View::OnToolsNetworkDebug() 
{
	// TODO: Add your command handler code here
	CDlgSelectConnection dlg;
	dlg.SetOwner(this);
	
	dlg.isUsingCom=isUsingCom;
	dlg.ipAddress=ipAddress;
	dlg.port=port;
	
	dlg.DoModal();

	if(
		isUsingCom!=dlg.isUsingCom||
		ipAddress!=dlg.ipAddress||
		port!=dlg.port
		)
	{
		if(GetPortOpen())
		{
			//settings are changed while port is open
			OnButtonConnectEstablish();
		}

		isUsingCom=dlg.isUsingCom;
		ipAddress=dlg.ipAddress;
		port=dlg.port;

		EnablePortSetting(TRUE);
	}

	/*
	isUsingCom=dlg.isUsingCom;
	ipAddress=dlg.ipAddress;
	port=dlg.port;


	if(!isUsingCom)
	{
		wirelessConnect.SetConnectionOpen(FALSE);
		wirelessConnect.SetConnectionPort(ipAddress,port);
		wirelessConnect.SetConnectionOpen(TRUE);
	}
	*/

	return;
}

BOOL CMotionDebug40View::GetPortOpen()
{
	BOOL ret=FALSE;
	if(isUsingCom)
	{
		ret=m_Comm.GetPortOpen();
		return ret;
	}
	else
		return wirelessConnect.GetConnectionOpen();
}

void CMotionDebug40View::SetPortOpen(BOOL bNewValue)
{
	if(isUsingCom)
		m_Comm.SetPortOpen(bNewValue);
	else
		wirelessConnect.SetConnectionOpen(bNewValue);
}

void CMotionDebug40View::OpenPortWithSettings()
{
	if(isUsingCom)
	{
		char p[2];
		CString pport;
		m_comboComPort.GetWindowText(pport);
		strcpy((PCHAR)&p, pport.Mid(pport.GetLength()-1));
		m_Comm.SetCommPort(atoi(p));
		
		m_comboComBaudrate.GetWindowText(pport);
		pport=pport+",N,8,1";
		m_Comm.SetSettings(pport);
		
		m_Comm.SetPortOpen(TRUE);
	}else
	{
		wirelessConnect.SetConnectionPort(ipAddress,port);
		wirelessConnect.SetConnectionOpen(TRUE);
	}
}

void CMotionDebug40View::EnablePortSetting(BOOL bNewValue)
{
	if(isUsingCom&&bNewValue)
	{
		m_comboComPort.EnableWindow(TRUE);
		m_comboComBaudrate.EnableWindow(TRUE);
	}else
	{
		m_comboComPort.EnableWindow(FALSE);
		m_comboComBaudrate.EnableWindow(FALSE);
	}
}



