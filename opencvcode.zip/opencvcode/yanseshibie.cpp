#include <cv.h>  
#include <highgui.h>  
#include <vector>  
using namespace std;  
#define MINAREA 600  
  
  
int main()  
{  
    IplImage* srcRGB =  cvLoadImage("33333.bmp");  
    IplImage* src= cvCreateImage(cvGetSize(srcRGB), 8, 1);    
  
    cvCvtColor(srcRGB, src,CV_RGB2GRAY);  
    cvNamedWindow("srcRGB", 0);  
    if(srcRGB!=NULL)  
    {  
        cvShowImage("srcRGB",srcRGB);  
    }  
      
    /**********************************תHSV����ͨ��**********************************/  
    IplImage* hsv = cvCreateImage(cvGetSize(srcRGB), 8, 3);  
    cvCvtColor( srcRGB, hsv, CV_BGR2HSV );  
  
    IplImage* img_h = cvCreateImage(cvGetSize(src), 8, 1);  
    IplImage* img_s = cvCreateImage(cvGetSize(src), 8, 1);  
    IplImage* img_v = cvCreateImage(cvGetSize(src), 8, 1);  
  
    cvSplit(hsv, img_h, img_s, img_v, NULL);  
      
    cvNamedWindow("img_h", 0);  
    cvShowImage("img_h", img_h);  
    cvNamedWindow("img_s", 0);  
    cvShowImage("img_s", img_s);  
    cvNamedWindow("img_v", 0);  
    cvShowImage("img_v", img_v);  
  
    cvNamedWindow("Thresh", 0);  
      
    IplImage* Thresh_img2 = cvCreateImage(cvGetSize(src), 8, 1);  
    IplImage* Thresh_img1 = cvCreateImage(cvGetSize(src), 8, 1);  
    IplImage* Thresh_img = cvCreateImage(cvGetSize(src), 8, 1);  
  
    cvThreshold(img_s, Thresh_img1, 90, 255, CV_THRESH_BINARY);  
    cvErode( Thresh_img1, Thresh_img1, NULL, 2 );  
    cvDilate(Thresh_img1, Thresh_img1, NULL, 2);  
  
    cvNamedWindow("img_ED", 0);  
    cvShowImage("img_ED", Thresh_img1);  
  
    cvShowImage("Thresh", Thresh_img1);  
    cvWaitKey(0);  
    cvThreshold(img_v, Thresh_img2, 248, 255, CV_THRESH_BINARY);  
    cvAdd(Thresh_img1,Thresh_img2, Thresh_img);  
      
    cvNamedWindow("img_ADD", 0);  
    cvShowImage("img_ADD", Thresh_img);  
  
    /***********************************��ȡĿ��*************************************/  
    IplImage* temp = cvCreateImage(cvGetSize(src), 8, 1);  
    IplImage* dst = cvCreateImage(cvGetSize(src), 8, 1);  
    IplImage* dstRGB = cvCreateImage(cvGetSize(src), 8, 3);  
    cvZero(dstRGB);  
    cvZero(temp);  
    cvZero(dst);  
  
    CvMemStorage* storage = cvCreateMemStorage(0);    
    CvSeq* contour = 0;  
      
    CvPoint center[20] = {cvPoint(0,0)};  
      
    int contour_num = cvFindContours(Thresh_img1, storage, &contour, sizeof(CvContour),   
       CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);   
      
    for(int i = 0; contour != 0; contour = contour->h_next, i++ )      
    {    
        double length = cvArcLength(contour);    
        if(length < MINAREA)       
        {  
           cvSeqRemove(contour, 0);           // ɾ�����С���趨ֵ������    
           continue;  
        }    
        int count = 0;  
        if(length >= MINAREA)  
        {  
         count++;  
         cvDrawContours(temp, contour, cvScalar(255,255,255), cvScalar(255,255,255), -1,CV_FILLED); //��Ϊ����                             
         cvCopy(img_h, dst, temp);  
        // cvSeqRemove(contour->h_prev, 0);   
          
         ///////////////////////////////Ŀ������hueͨ����ƽ���Ҷ�ֵ////////////////////////////////////  
         int pix_count=0;  
         int  gray_value = 0;  
         for(int x=0; x<dst->height; x++)  
         {  
             uchar* ptr = (uchar*) dst->imageData+x*dst->widthStep;  
             for(int y=0; y<dst->width; y++)  
             {                
                if(ptr[y])  
                    {  
                        gray_value += ptr[y];  
                        pix_count++;  
                    }  
             }  
         }  
         gray_value/=pix_count;  
  
         /////////////////////////////////////��Ŀ������//////////////////////////////////////  
          
         CvSeqReader reader;  
         CvPoint pt = cvPoint(0,0);  
         cvStartReadSeq(contour, &reader);  
           
         int point_count = 0;  
  
         for(int i=0; i<contour->total; i++)  
            {                 
                CV_READ_SEQ_ELEM(pt, reader);  
                center[count].x+=pt.x;  
                center[count].y+=pt.y;  
                point_count++;  
            }  
          
         center[count].x=center[count].x/point_count;     //��������  
         center[count].y=center[count].y/point_count;  
         cout<<"X:"<<center[count].x << " Y:" << center[count].y<<endl;  
                   
         /////////////////////////////////////////////////////////////////////  
         cvCopy(srcRGB, dstRGB, temp);        
        // char* Gray_Value = "hello";  
        // itoa(gray_value, Gray_Value , 20);  
        // sprintf(Gray_Value,"%d",gray_value);  
        // cout<<Gray_Value<<endl;  
        // CvFont font;  
        // cvInitFont(&font, CV_FONT_HERSHEY_DUPLEX, 0.8f, 0.8f, 1, 1);  
        // cvPutText(dstRGB,  Gray_Value, center,   &font, CV_RGB(255,255,255) );  
         cvCircle(dstRGB, center[count], 6, CV_RGB(0,255,0), 2);  
         cout<<gray_value<<endl;  
         cvNamedWindow("dstRGB", 0);  
         cvShowImage("dstRGB", dstRGB);       
        }  
        //cvWaitKey(0);  
    }   
    cvWaitKey(0);     
              
    cvReleaseImage(&img_h);  
    cvReleaseImage(&img_s);  
    cvReleaseImage(&img_v);   
    cvReleaseImage(&hsv);  
    cvReleaseImage(&src);  
    cvDestroyAllWindows();  
}   